import React from 'react';
import { 
  Activity, 
  Search, 
  PlusCircle, 
  FileText, 
  BookOpen, 
  UserCheck, 
  Clock,
  ShieldCheck
} from 'lucide-react';
import { Patient } from '../types/medical';

interface NavbarProps {
  activePatient: Patient | null;
  onOpenSearch: () => void;
  onOpenNewPatient: () => void;
  onOpenSpec: () => void;
  onGoToDashboard: () => void;
  currentView: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  activePatient,
  onOpenSearch,
  onOpenNewPatient,
  onOpenSpec,
  onGoToDashboard,
  currentView
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3">
            <button 
              onClick={onGoToDashboard}
              className="flex items-center space-x-2 text-left group focus:outline-none"
            >
              <div className="w-10 h-10 rounded-xl bg-teal-600 flex items-center justify-center text-white shadow-md shadow-teal-500/20 group-hover:bg-teal-700 transition">
                <Activity className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center space-x-1.5">
                  <span className="font-bold text-lg tracking-tight text-slate-900">MedRecord</span>
                  <span className="text-xs font-bold px-1.5 py-0.5 rounded bg-teal-50 text-teal-700 border border-teal-200">PRO</span>
                </div>
                <p className="text-[11px] text-slate-500 font-medium">Historia Clínica Electrónica</p>
              </div>
            </button>

            {/* View Breadcrumb badge */}
            <div className="hidden md:flex items-center space-x-2 ml-4 pl-4 border-l border-slate-200">
              <button 
                onClick={onGoToDashboard}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition ${
                  currentView === 'dashboard' 
                    ? 'bg-slate-900 text-white' 
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Dashboard Clínico
              </button>
              {activePatient && (
                <span className="text-xs text-slate-400">/</span>
              )}
              {activePatient && (
                <span className="text-xs font-medium text-slate-700 bg-slate-100 px-2 py-0.5 rounded-md truncate max-w-[200px]">
                  {activePatient.filiation.fullName}
                </span>
              )}
            </div>
          </div>

          {/* Quick Search and Shortcuts */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            
            {/* Quick Search Button */}
            <button
              onClick={onOpenSearch}
              className="flex items-center space-x-2 px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-600 text-xs sm:text-sm font-medium transition shadow-2xs group"
              title="Buscar paciente (Ctrl+K)"
            >
              <Search className="w-4 h-4 text-slate-400 group-hover:text-teal-600 transition" />
              <span className="hidden sm:inline">Buscar Paciente...</span>
              <kbd className="hidden md:inline-block px-1.5 py-0.5 text-[10px] font-mono font-semibold text-slate-400 bg-white border border-slate-200 rounded">
                ⌘K
              </kbd>
            </button>

            {/* New Patient Button */}
            <button
              onClick={onOpenNewPatient}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs sm:text-sm font-medium transition shadow-xs"
            >
              <PlusCircle className="w-4 h-4" />
              <span className="hidden sm:inline">Nuevo Paciente</span>
            </button>

            {/* Technical Specification Button */}
            <button
              onClick={onOpenSpec}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border border-indigo-200 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs sm:text-sm font-semibold transition"
              title="Ver Especificación Técnica Completa de la Plataforma"
            >
              <BookOpen className="w-4 h-4 text-indigo-600" />
              <span className="hidden lg:inline">Especificación Técnica</span>
              <span className="lg:hidden text-xs">Especificación</span>
            </button>

            {/* Doctor Profile Pill */}
            <div className="hidden xl:flex items-center space-x-2.5 pl-3 border-l border-slate-200">
              <div className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-700 font-bold text-xs">
                ES
              </div>
              <div className="text-left">
                <div className="text-xs font-semibold text-slate-900 leading-tight">Dra. Elena Santillán</div>
                <div className="text-[10px] text-slate-500 font-mono">MN 114.892 · Internista</div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </header>
  );
};
