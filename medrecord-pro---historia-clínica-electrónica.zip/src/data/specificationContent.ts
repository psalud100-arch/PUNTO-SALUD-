export interface SpecSection {
  id: string;
  title: string;
  subtitle: string;
  iconName: string;
  contentMarkdown: string;
}

export const SPECIFICATION_DOCUMENT: SpecSection[] = [
  {
    id: 'arquitectura',
    title: '1. Arquitectura de la Plataforma',
    subtitle: 'Diseño de sistemas, componentes de software, flujo de datos y escalabilidad en nube',
    iconName: 'Server',
    contentMarkdown: `### 1.1 Visión General de la Arquitectura

La plataforma está diseñada bajo un modelo **Modular Monolith orientado a Microservicios** (Clean Architecture / Onion Architecture), optimizado para ofrecer una latencia sub-100ms en el consultorio médico, con capacidades **Offline-First** en clientes web/móvil para evitar que una interrupción de internet detenga la atención médica.

\`\`\`
+-----------------------------------------------------------------------------------+
|                            CAPA CLIENTE (FRONTEND / PWA)                         |
|   +------------------------------------+   +------------------------------------+ |
|   |   React 19 SPA (Vite + TypeScript) |   |   PWA Mobile / Tablet (iOS/Android)| |
|   |   Tailwind CSS v4 + Lucide Icons   |   |   IndexedDB Local Cache (Offline)  | |
|   +------------------------------------+   +------------------------------------+ |
+------------------------------------------+----------------------------------------+
                                           | HTTPS / TLS 1.3 (mTLS opcional)
                                           v
+-----------------------------------------------------------------------------------+
|                        API GATEWAY & SEGURIDAD PERIMETRAL                         |
|   - Cloudflare WAF / Enterprise DDoS Shield                                       |
|   - Rate Limiting estricto por IP y Token JWT                                     |
|   - Terminación TLS & Encabezados HSTS / CSP estricto                             |
+------------------------------------------+----------------------------------------+
                                           |
                                           v
+-----------------------------------------------------------------------------------+
|                         CAPA DE APLICACIÓN (BACKEND CORE)                         |
|   +---------------------------------------------------------------------------+   |
|   |   Node.js (TypeScript) / NestJS RESTful API & tRPC                        |   |
|   |   - Auth & RBAC Service (Roles: Médico, Asistente, Auditor, Admin)        |   |
|   |   - Clinical Records Service (Filiación, Primera Consulta, SOAP, CIE-10) |   |
|   |   - Prescription & PDF Generator Service (Motor headless Chromium)        |   |
|   |   - Realtime WebSocket Server (Notificaciones de turno y signos vitales)  |   |
|   |   - Audit Log Service (Pistas inmutables de auditoría WORM)               |   |
|   +---------------------------------------------------------------------------+   |
+-------------------------+-------------------------------+-------------------------+
                          |                               |
                          v                               v
+---------------------------------------+   +---------------------------------------+
|        BASE DE DATOS RELACIONAL       |   |        ALMACENAMIENTO DE ARCHIVOS     |
|   PostgreSQL 16 Enterprise (ACID)     |   |   AWS S3 / Google Cloud Storage /     |
|   - Cifrado en reposo AES-256         |   |   MinIO On-Premise                    |
|   - Extensiones: pgcrypto, pg_trgm   |   |   - Cifrado SSE-KMS en reposo         |
|   - Réplicas de solo lectura          |   |   - PDFs de estudios, RX, DICOM       |
|   - Particionamiento por clínicas     |   |   - Firmas y consentimientos digitales|
+---------------------------------------+   +---------------------------------------+
                          ^                               ^
                          |                               |
+-----------------------------------------------------------------------------------+
|                              SERVICIOS DE SOPORTE                                 |
|   - Redis Cluster (Sesiones de alta velocidad, caché de CIE-10 y colas BullMQ)    |
|   - Meilisearch / Elasticsearch (Motor de indexación clínica ultrarrápida)        |
+-----------------------------------------------------------------------------------+
\`\`\`

### 1.2 Componentes del Frontend (Interfaz del Médico)
- **Framework Core**: React 19 + TypeScript en modo estricto.
- **Bundler y Compilador**: Vite 6 con soporte para Tree-Shaking agresivo y carga diferida (lazy loading).
- **Diseño & UI**: Tailwind CSS v4 con enfoque mobile-first y soporte para pantallas táctiles de tablets (iPad Pro, Surface, Galaxy Tab).
- **Gestión de Estado**: Zustand para estado global reactivo de paciente activo, complementado con TanStack Query (React Query) para sincronización de datos clínicos con caché optimista.
- **Modo Desconectado (Offline-First)**: Service Worker inteligente con Workbox y almacenamiento en \`IndexedDB\` vía \`idb-keyval\` para retener borradores de consulta en caso de caída temporal de conectividad.

### 1.3 Componentes del Backend
- **Core Runtime**: Node.js v22 LTS con TypeScript (o Go/Golang para microservicios de criptografía y firma digital).
- **Patrón Arquitectural**: Clean Architecture (Domain-Driven Design), separando Entidades, Casos de Uso, Controladores y Adaptadores de Repositorio.
- **Validación Estricta**: Zod para tipado y validación de esquemas en tiempo de ejecución de cada payload de signos vitales y datos clínicos.
- **Generación de Documentos**: Chromium Headless / Puppeteer para renderizado de recetas médicas de alta fidelidad tipográfica listas para impresión o firma digital.`
  },
  {
    id: 'modelo-datos',
    title: '2. Modelo de Base de Datos',
    subtitle: 'Entidades principales, relaciones relacionales, integridad referencial y esquema SQL',
    iconName: 'Database',
    contentMarkdown: `### 2.1 Diagrama Entidad-Relación y Tablas Principales

El modelo de datos se basa en PostgreSQL con integridad referencial estricta. **Regla Médica Vital**: Los registros de historia clínica nunca se eliminan físicamente (\`ON DELETE RESTRICT\` / soft-delete con bitácora), preservando la cadena de custodia legal.

\`\`\`
 [doctors] 1 ------ * [patients] (médico de cabecera / asignado)
    |                     |
    |                     +---- 1 : 1 ---- [patient_filiations]
    |                     |
    |                     +---- 1 : * ---- [patient_allergies]
    |                     |
    |                     +---- 1 : * ---- [consultations]
    |                                            |
    +---- 1 : * ---------------------------------+ (médico tratante)
                                                 |
                                                 +---- 1 : 1 ---- [vital_signs]
                                                 +---- 1 : * ---- [consultation_diagnoses] (CIE-10)
                                                 +---- 1 : * ---- [prescriptions] ---- * [prescription_items]
                                                 +---- 1 : * ---- [clinical_attachments]
\`\`\`

### 2.2 Esquema DDL en SQL (PostgreSQL Production Ready)

\`\`\`sql
-- Extensiones requeridas
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "citext";

-- 1. Tabla de Médicos / Usuarios Clínicos
CREATE TABLE doctors (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email CITEXT UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    specialty VARCHAR(100) NOT NULL,
    medical_license VARCHAR(50) NOT NULL, -- Matrícula / Cédula profesional
    phone VARCHAR(30),
    digital_stamp_url TEXT,
    signature_image_url TEXT,
    role VARCHAR(30) DEFAULT 'DOCTOR', -- DOCTOR, ADMIN, NURSE, AUDITOR
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Tabla de Pacientes (Entidad Maestra)
CREATE TABLE patients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    record_number VARCHAR(30) UNIQUE NOT NULL, -- ej: HC-2026-0042
    primary_doctor_id UUID REFERENCES doctors(id) ON DELETE RESTRICT,
    status VARCHAR(20) DEFAULT 'ACTIVE', -- ACTIVE, IN_CONSULTATION, WAITING, INACTIVE
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_patients_record_number ON patients(record_number);

-- 3. Tabla de Filiación (Ficha de Identificación Única)
CREATE TABLE patient_filiations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id UUID UNIQUE NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
    
    -- Datos personales
    full_name VARCHAR(150) NOT NULL,
    birth_date DATE NOT NULL,
    gender VARCHAR(20) NOT NULL,
    civil_status VARCHAR(30),
    occupation VARCHAR(100),
    education_level VARCHAR(50),
    
    -- Identificación
    document_type VARCHAR(30) NOT NULL,
    document_number VARCHAR(50) NOT NULL,
    
    -- Contacto & Domicilio
    address TEXT,
    city VARCHAR(80),
    state_province VARCHAR(80),
    phone VARCHAR(30),
    mobile VARCHAR(30),
    email CITEXT,
    
    -- Contacto de emergencia
    emergency_contact_name VARCHAR(120),
    emergency_contact_relation VARCHAR(50),
    emergency_contact_phone VARCHAR(30),
    
    -- Seguro / Afiliación
    insurance_type VARCHAR(50),
    insurance_name VARCHAR(100),
    policy_number VARCHAR(60),
    payer_responsible VARCHAR(100),
    
    -- Fijos clínicos
    blood_type VARCHAR(5) NOT NULL, -- A+, O+, etc.
    organ_donor BOOLEAN DEFAULT FALSE,
    
    -- Antecedentes en JSONB estructurado para máxima flexibilidad y consulta
    hereditary_background JSONB NOT NULL DEFAULT '{}'::jsonb,
    pathological_background JSONB NOT NULL DEFAULT '{}'::jsonb,
    non_pathological_background JSONB NOT NULL DEFAULT '{}'::jsonb,
    surgical_background JSONB NOT NULL DEFAULT '{}'::jsonb,
    gynecological_background JSONB DEFAULT '{}'::jsonb,
    habits_lifestyle JSONB NOT NULL DEFAULT '{}'::jsonb,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_filiations_doc_num ON patient_filiations(document_number);
CREATE INDEX idx_filiations_full_name_trgm ON patient_filiations USING gin(full_name gin_trgm_ops);

-- 4. Alergias Críticas (Normalizadas para Búsqueda y Alerta Rápida)
CREATE TABLE patient_allergies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    allergen VARCHAR(100) NOT NULL,
    category VARCHAR(40) NOT NULL, -- Medicamento, Alimento, Látex, etc.
    severity VARCHAR(30) NOT NULL, -- Leve, Moderada, Severa / Anafilaxia
    reaction TEXT,
    recorded_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_allergies_patient ON patient_allergies(patient_id);

-- 5. Consultas Médicas (Primera Consulta y Evoluciones Subsecuentes)
CREATE TABLE consultations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
    doctor_id UUID NOT NULL REFERENCES doctors(id) ON DELETE RESTRICT,
    consultation_type VARCHAR(30) NOT NULL, -- 'FIRST_CONSULTATION', 'SUBSEQUENT'
    consultation_date TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Campos Primera Consulta
    reason_for_consultation TEXT,
    present_illness_history TEXT,
    systems_review JSONB,
    physical_examination JSONB,
    prior_studies TEXT,
    prognosis VARCHAR(50),
    
    -- Campos Consulta Subsecuente
    evolution_mode VARCHAR(20), -- 'SOAP', 'FREE'
    soap_subjective TEXT,
    soap_objective TEXT,
    soap_assessment TEXT,
    soap_plan TEXT,
    free_evolution_note TEXT,
    
    -- Plan e Indicaciones
    general_indications TEXT,
    next_appointment_date DATE,
    doctor_signature_stamp TEXT NOT NULL,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_consultations_patient_date ON consultations(patient_id, consultation_date DESC);

-- 6. Signos Vitales (Asociados a la Consulta)
CREATE TABLE vital_signs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    consultation_id UUID UNIQUE NOT NULL REFERENCES consultations(id) ON DELETE CASCADE,
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
    systolic_bp INT NOT NULL,
    diastolic_bp INT NOT NULL,
    heart_rate INT NOT NULL,
    respiratory_rate INT NOT NULL,
    temperature NUMERIC(4, 1) NOT NULL,
    oxygen_saturation INT NOT NULL,
    weight_kg NUMERIC(5, 2) NOT NULL,
    height_cm NUMERIC(5, 1) NOT NULL,
    calculated_bmi NUMERIC(4, 1) NOT NULL,
    capillary_blood_glucose INT,
    recorded_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Diagnósticos CIE-10 Asociados a Consulta
CREATE TABLE consultation_diagnoses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    consultation_id UUID NOT NULL REFERENCES consultations(id) ON DELETE CASCADE,
    cie10_code VARCHAR(10) NOT NULL,
    cie10_name VARCHAR(255) NOT NULL,
    diagnosis_type VARCHAR(20) DEFAULT 'PRINCIPAL', -- PRINCIPAL, SECUNDARIO
    clinical_condition VARCHAR(20) DEFAULT 'DEFINITIVO', -- PRESUNTIVO, DEFINITIVO
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Prescripciones Médicas (Recetas)
CREATE TABLE prescriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    consultation_id UUID NOT NULL REFERENCES consultations(id) ON DELETE CASCADE,
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
    doctor_id UUID NOT NULL REFERENCES doctors(id) ON DELETE RESTRICT,
    issue_date TIMESTAMPTZ DEFAULT NOW(),
    verification_qr_code VARCHAR(255),
    digital_signature_hash TEXT
);

CREATE TABLE prescription_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    prescription_id UUID NOT NULL REFERENCES prescriptions(id) ON DELETE CASCADE,
    medication_name VARCHAR(150) NOT NULL,
    presentation VARCHAR(100) NOT NULL,
    dosage VARCHAR(100) NOT NULL,
    route VARCHAR(30) NOT NULL,
    frequency VARCHAR(100) NOT NULL,
    duration VARCHAR(60) NOT NULL,
    indications TEXT
);

-- 9. Pistas de Auditoría Inmutables (Cumplimiento Legal y Forense)
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES doctors(id),
    action VARCHAR(50) NOT NULL, -- VIEW_PATIENT, CREATE_CONSULTATION, PRINT_RECIPE
    entity_name VARCHAR(50) NOT NULL,
    entity_id UUID NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    user_agent TEXT,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    diff_payload JSONB
);
CREATE INDEX idx_audit_timestamp ON audit_logs(timestamp DESC);
\`\`\``
  },
  {
    id: 'wireframes-pantallas',
    title: '3. Wireframes & Flujos de Pantallas',
    subtitle: 'Diseño UX, optimización de clics, atajos de teclado y distribución ergonómica',
    iconName: 'Layout',
    contentMarkdown: `### 3.1 Principios de Interacción del Médico (Zero Clutter)
1. **Regla de los 3 clics**: Cualquier acción crítica (comenzar consulta, recetar, ver alergias, imprimir receta) debe poder ejecutarse en un máximo de 3 clics.
2. **Atajos de Teclado Globales**:
   - \`Ctrl + K\` o \`Cmd + K\`: Buscador global instantáneo de pacientes.
   - \`Ctrl + N\` o \`Cmd + N\`: Nueva consulta rápida.
   - \`Ctrl + P\` o \`Cmd + P\`: Imprimir receta actual o resumen.
   - \`Ctrl + S\` o \`Cmd + S\`: Guardar nota clínica con feedback visual inmediato.
3. **Banner de Seguridad Permanente**: La cabecera del paciente permanece fija con su nombre, edad exacta, grupo sanguíneo y **alergias en badge rojo brillante** siempre a la vista para prevenir errores de prescripción.

### 3.2 Desglose de Pantallas Principales

#### 1. Dashboard del Médico (Centro de Mando)
- **Cabecera**: Saludo al médico, fecha actual, selector de consultorio.
- **Tarjetas KPI**: Pacientes citados hoy, atendidos, en sala de espera, alertas de signos vitales fuera de rango.
- **Agenda del Día**: Lista interactiva con botón "Llamar a consulta", estado visual (En espera / En consulta / Atendido).
- **Acceso rápido**: Pacientes recientes y atajo a creación de paciente en 1 paso.

#### 2. Búsqueda y Creación de Pacientes
- Input de búsqueda omnipresente con autocompletado en tiempo real (\`debounce: 150ms\`).
- Coincidencias simultáneas por Nombre, DNI/Documento, Teléfono o N° de Historia Clínica.
- Botón "Nuevo Paciente" que abre modal asistido con cálculo en tiempo real de edad conforme se digita la fecha de nacimiento.

#### 3. Ficha de Filiación (Ficha de Identificación)
- **Organización por Acordeones / Pestañas Temáticas**:
  - *Identificación y Contacto*: Nombre, DNI, Teléfono, Dirección, Contacto de Emergencia.
  - *Cobertura*: Seguro médico, número de póliza, responsable de pago.
  - *Antecedentes Heredofamiliares*: Checkboxes rápidos con campo de detalle (Diabetes, HTA, Cardiopatía, Cáncer).
  - *Antecedentes Patológicos & Quirúrgicos*: Cuadros de texto con sugerencias frecuentes.
  - *Alergias Críticas*: Selector de alérgeno, categoría y nivel de severidad (Leve, Moderada, Anafilaxia).
  - *Gineco-Obstétricos*: Visibles condicionalmente con cálculo de fórmula gestacional (G P A C).
  - *Hábitos*: Fumador (con cálculo de paquetes/año), Alcohol, Dieta y Ejercicio.

#### 4. Primera Consulta (Hoja de Consulta Externa Integral)
- **Sección 1**: Motivo de consulta y cronología de Enfermedad Actual.
- **Sección 2**: Interrogatorio por aparatos y sistemas con botón "Marcar Todos Normales" y desglose individual si existe patología.
- **Sección 3**: Exploración física estructurada (Cabeza/Cuello, Tórax/Pulmones, Abdomen, Miembros, Neurológico) con botón de inserción de plantilla normal.
- **Sección 4**: Signos vitales en cuadrícula compacta: ingreso de peso y talla calcula **IMC automático al instante** con etiqueta cromática según la OMS.
- **Sección 5**: Diagnósticos CIE-10 con selector predictivo, tipo (Principal/Secundario) y condición (Presuntivo/Definitivo).
- **Sección 6**: Plan de tratamiento farmacológico estructurado e indicaciones generales.
- **Sección 7**: Pronóstico médico y firma digital.

#### 5. Consultas Subsecuentes (Evoluciones)
- **Selector de Modo en 1 Clic**:
  - *Modo SOAP*: 4 áreas de texto claramente delimitadas (Subjetivo, Objetivo, Análisis, Plan) con botones para insertar plantillas preconfiguradas.
  - *Modo Libre*: Hoja de evolución clásica estilo nota médica continua.
- **Arrastre de Diagnósticos Anteriores**: Botón "Arrastrar diagnósticos previos" que importa los códigos CIE-10 de la última cita para no tener que tipear de nuevo.
- **Registro rápido de Signos Vitales** con comparador (ej. "↓ 1.4 kg vs última cita").
- **Agendamiento de próxima cita** con selector de 1 clic (+7 días, +15 días, +1 mes, +3 meses).

#### 6. Línea de Tiempo del Paciente (Timeline)
- Eje cronológico vertical con tarjetas colapsables.
- Marcadores visuales distintivos para Primera Consulta, Evolución SOAP, Evolución Libre y Estudios Adjuntos.
- Tabla/Gráfico interactivo de evolución de signos vitales (Presión arterial, Peso e IMC a lo largo del tiempo).`
  },
  {
    id: 'funcionalidades-mvp',
    title: '4. Matriz de Funcionalidades (MVP vs Enterprise)',
    subtitle: 'Alcance funcional dividido en fases estratégicas de lanzamiento y escalabilidad',
    iconName: 'CheckSquare',
    contentMarkdown: `### 4.1 Matriz Comparativa de Capacidades

| Módulo / Característica | Fase 1 (MVP de Lanzamiento) | Fase 2 (Versión Enterprise / Hospitales) |
| :--- | :---: | :---: |
| **Gestión de Pacientes** | Creación, edición y búsqueda multicriterio (Nombre, DNI, Teléfono) | Importación masiva Excel/CSV, fusión de historias duplicadas |
| **Ficha de Filiación** | Completa con todos los antecedentes, cálculo de edad, alergias | Validación automática de DNI/Cédula con padrones estatales |
| **Primera Consulta** | Hoja completa: interrogatorio, examen físico, CIE-10, plan, pronóstico | Flujos personalizados por especialidad médica (Pediatría, Ginecología, etc.) |
| **Evoluciones** | Conmutador SOAP vs Libre, arrastre de diagnósticos, signos vitales | Reconocimiento y dictado por voz médica con IA |
| **Signos Vitales & IMC** | Cálculo automático de IMC, categorías OMS y semáforo tensional | Integración bluetooth con tensiómetros y básculas digitales (IoT) |
| **Recetas Médicas** | Generador de prescripciones estructuradas e impresión con QR | Firma electrónica avanzada PKI / Token criptográfico oficial |
| **Catálogo CIE-10** | Buscador predictivo con >60 patologías frecuentes preinstaladas | Catálogo CIE-10 / CIE-11 completo oficial y mapeo SNOMED CT |
| **Plantillas Clínicas** | Banco de frases rápidas y plantillas médicas en 1 clic | Editor personalizado de plantillas por cada médico y especialidad |
| **Archivos Adjuntos** | Subida y visualización de PDFs de laboratorio e imágenes | Visor DICOM web con manipulación de contrastes y reconstrucción 3D |
| **Seguridad & Acceso** | Login con contraseña robusta, control de roles (Médico/Admin) | Autenticación biométrica WebAuthn, 2FA con TOTP, Single Sign-On (SAML/Okta) |
| **Pistas de Auditoría** | Log de creación y modificaciones clínicas | Trazabilidad forense inmutable WORM con sellado de tiempo RFC 3161 |
| **Agenda y Turnos** | Vista de agenda del día y pacientes en espera | Recordatorios automáticos por WhatsApp y portal de turnos online |
| **Modo Desconectado** | Caché en navegador y guardado de borradores | Sincronización bidireccional PWA con resolución de conflictos de red |`
  },
  {
    id: 'stack-tecnologico',
    title: '5. Stack Tecnológico Sugerido',
    subtitle: 'Tecnologías modernas, seguras, de alto rendimiento y bajo costo de mantenimiento',
    iconName: 'Cpu',
    contentMarkdown: `### 5.1 Selección y Justificación del Stack Tecnológico

#### Frontend (Capa de Presentación y Experiencia del Médico)
- **React 19 + TypeScript**: Garantiza tipado estricto en cada objeto clínico, evitando errores de cálculo de dosis o unidades de signos vitales.
- **Vite**: Velocidad extrema de compilación y bundling optimizado.
- **Tailwind CSS v4**: Permite una interfaz clínica limpia, de alto contraste visual y con cero sobrecarga de CSS runtime.
- **Lucide Icons**: Iconografía médica y funcional sobria, sin distracciones visuales.
- **PWA (Progressive Web App)**: Posibilidad de instalar la aplicación como app nativa en iPad, tablets Android y escritorios Windows/macOS.

#### Backend (Capa de Lógica de Negocio y Seguridad)
- **Node.js (TypeScript) con NestJS / Fastify**:
  - *Justificación*: Ecosistema maduro, soporte nativo de TypeScript compartido con el frontend, arquitectura modular orientada a inyección de dependencias.
  - *Alternativa de Alto Rendimiento*: Go (Golang) para microservicios de criptografía, firma de recetas y streaming de telemetría médica.
- **ORM / Query Builder**: Drizzle ORM o Prisma ORM con migraciones deterministas y soporte estricto de tipos SQL.

#### Almacenamiento y Base de Datos
- **PostgreSQL 16**:
  - Motor relacional líder indiscutible para salud. Cumple con transaccionalidad ACID absoluta.
  - Soporte de columnas \`JSONB\` para antecedentes variables y plantillas médicas complejas sin penalización de rendimiento.
  - Cifrado en reposo transparente (TDE) o cifrado de columnas mediante \`pgcrypto\`.
- **Redis 7**:
  - Caché de sesiones de usuario médicas con expiración forzada por inactividad (requisito HIPAA).
  - Almacenamiento volátil del catálogo CIE-10 para búsquedas de < 5 milisegundos.
- **MinIO / AWS S3 / Cloud Storage**:
  - Almacenamiento de objetos compatible con S3, con políticas de retención inmutables (Object Lock) para consentimientos informados y análisis clínicos.

#### Infraestructura y Despliegue
- **Contenedores**: Docker multi-etapa para generar imágenes ligeras (< 60MB).
- **Orquestación**: Google Cloud Run o Kubernetes (GKE / EKS) con autoescalado elástico a cero en horas no laborables para optimizar costos.
- **Monitoreo y Métricas**: OpenTelemetry + Prometheus + Grafana (sin registrar datos personales de pacientes en logs de métricas).`
  },
  {
    id: 'seguridad-normativas',
    title: '6. Seguridad, Privacidad y Normativas',
    subtitle: 'Cumplimiento exhaustivo de HIPAA, RGPD, NOM-004-SSA3, cifrado y firma médica',
    iconName: 'ShieldCheck',
    contentMarkdown: `### 6.1 Marco Legal y Normativo de Salud

La plataforma está diseñada para cumplir simultáneamente con los estándares internacionales más rigurosos y las normativas locales de salud hispanohablantes:

1. **HIPAA (Health Insurance Portability and Accountability Act - EE.UU.)**:
   - *Security Rule*: Salvaguardas administrativas, físicas y técnicas obligatorias.
   - *Privacy Rule*: Prohibición estricta de divulgar Información de Salud Protegida (PHI).
   - *Business Associate Agreement (BAA)*: Infraestructura alojada exclusivamente en proveedores con BAA firmado (AWS, GCP, Azure).
2. **RGPD / GDPR (Reglamento General de Protección de Datos - UE)**:
   - Los datos de salud son considerados de **Categoría Especial (Art. 9)**. Se requiere consentimiento explícito o legitimación por tratamiento médico asistencial.
   - *Principio de Minimización de Datos*: Solo se recopilan los campos estrictamente necesarios para el acto médico.
3. **Normativas Locales de Historia Clínica**:
   - **México**: *NOM-004-SSA3-2012* (Del expediente clínico) y *NOM-024-SSA3-2012* (Sistemas de información de registro electrónico para la salud).
   - **Argentina**: *Ley 26.529* (Derechos del Paciente, Historia Clínica y Consentimiento Informado) y *Ley 25.326* (Protección de Datos Personales).
   - **Chile**: *Ley 20.584* (Derechos y Deberes de las Personas en Salud) y *Ley 19.628*.
   - **Colombia**: *Ley 1581 de 2012* y *Resolución 1995 de 1999* (Manejo de la Historia Clínica).

### 6.2 Pilares de Ciberseguridad Médica

\`\`\`
                               +-----------------------------+
                               |     SEGURIDAD EN CAPAS      |
                               +-----------------------------+
                                             |
            +--------------------------------+--------------------------------+
            |                                |                                |
            v                                v                                v
  [CIFRADO DE EXTREMO A EXTREMO]  [CONTROL DE ACCESO RBAC]      [TRAZABILIDAD FORENSE]
  - En tránsito: TLS 1.3 + HSTS   - Roles médicos estrictos     - Log inmutable WORM
  - En reposo: AES-256-GCM        - Cierre de sesión por ocio   - Registro de accesos
  - PHI a nivel de columna        - Autenticación MFA / TOTP    - Sellado de tiempo RFC 3161
\`\`\`

#### Cifrado en Reposo y en Tránsito
- **En Tránsito**: Comunicaciones 100% cifradas bajo protocolo **TLS 1.3**, con suites criptográficas modernas y encabezados \`Strict-Transport-Security\` (HSTS).
- **En Reposo**: Todo el almacenamiento de base de datos y archivos está cifrado con **AES-256**.
- **Cifrado de Campos Críticos (Envelope Encryption)**: Campos extremadamente sensibles (como notas de salud mental o datos de contacto) cifrados con claves administradas mediante KMS con rotación automática anual.

#### Control de Acceso y Gestión de Sesiones
- **Autenticación multifactor obligatoria (MFA)** para todos los profesionales médicos.
- **Cierre de sesión automático por inactividad**: Tras 15 minutos sin interacción del médico, la pantalla se bloquea automáticamente con PIN rápido de desbloqueo para evitar que miradas no autorizadas lean la pantalla si el médico abandona el consultorio.
- **Modelo de Privilegios Basado en Roles (RBAC)**:
  - *Médico*: Lectura y escritura completa en sus pacientes; acceso solo a expedientes asignados.
  - *Asistente / Recepcionista*: Solo lectura de filiación básica y gestión de turnos; **bloqueo total de antecedentes clínicos, SOAP y diagnósticos**.
  - *Auditor Médico*: Lectura de expedientes para control de calidad sin capacidad de edición.

#### Firma Electrónica Avanzada y No Repudio
- Integración de **Firma Digital con Certificado X.509** y Sellado de Tiempo (Timestamping RFC 3161).
- Cada receta emitida cuenta con un **código QR único con hash criptográfico SHA-256**, permitiendo a las farmacias verificar la autenticidad e integridad de la receta en línea sin alterar el documento.`
  },
  {
    id: 'funciones-premium',
    title: '7. Ideas de Funciones Premium de Alto Valor',
    subtitle: 'Innovaciones tecnológicas que ahorran horas al médico y monetizan la plataforma',
    iconName: 'Sparkles',
    contentMarkdown: `### 7.1 Módulos Premium para Médicos y Clínicas

#### 1. Copiloto de Dictado por Voz Clínico (Ambient Scribe)
- El médico puede hablar naturalmente durante la consulta (o presionar un botón de micrófono) y un modelo acústico clínico especializado transcribe y **auto-estructura la información en los 4 campos del modelo SOAP** en tiempo real.
- *Impacto*: Ahorra de 1.5 a 2 horas diarias de tipeo al profesional.

#### 2. Asistente Farmacológico de Interacciones en Tiempo Real
- Motor inteligente que cruza las alergias registradas del paciente con los fármacos prescritos.
- Alerta al médico instantáneamente si intenta prescribir un antibiótico betalactámico a un paciente con alergia a la penicilina, o advierte sobre interacciones medicamentosas graves (ej. Macrólidos + Antiarrítmicos con prolongación de QT).

#### 3. Portal del Paciente con Telemedicina WebRTC
- Espacio seguro donde el paciente puede:
  - Ver sus recetas médicas descargables en PDF con código QR.
  - Revisar indicaciones y fechas de próximas citas.
  - Sala de videoconsulta HD cifrada de extremo a extremo integrada directamente en la pantalla de la evolución médica.

#### 4. Interoperabilidad HL7 FHIR & RIPS / Facturación Automática
- Exportación e importación de resúmenes de atención en estándar internacional **HL7 FHIR (Fast Healthcare Interoperability Resources)**.
- Vinculación directa con nomencladores de obras sociales y aseguradoras para generar presupuestos y cobros de honorarios médicos con 1 clic.

#### 5. Asistente de Turnos y Recordatorios por WhatsApp
- Sistema automatizado que envía recordatorios de cita 24h y 2h antes por WhatsApp oficial con botones interactivos de "Confirmar", "Reprogramar" o "Cancelar".
- Reduce el ausentismo (No-Show) del consultorio en más del 65%.

#### 6. Tablero Analítico y Epidemiológico de la Consulta
- Gráficos y reportes automáticos: patologías más frecuentes atendidas, rango de edad de la población atendida, adherencia a controles crónicos (HTA, DM2) y métricas de ingresos del consultorio.`
  }
];
