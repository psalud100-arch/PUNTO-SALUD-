import React, { useState } from 'react';
import { 
  Printer, 
  FileText, 
  Download, 
  ShieldCheck, 
  QrCode, 
  User, 
  Calendar, 
  Stethoscope, 
  Heart,
  Droplet
} from 'lucide-react';
import { Patient, PrescriptionItem, CIE10Diagnosis } from '../types/medical';
import { calculateAge, formatDate } from '../utils/medicalCalculators';

interface PrintableDocumentsProps {
  patient: Patient;
}

export const PrintableDocuments: React.FC<PrintableDocumentsProps> = ({
  patient
}) => {
  const [docType, setDocType] = useState<'prescription' | 'summary' | 'labOrder'>('prescription');
  
  // Custom lab order items
  const [labTests, setLabTests] = useState('1. Hemograma completo automatizado\n2. Glucemia en ayunas\n3. Hemoglobina Glicosilada (HbA1c)\n4. Perfil lipídico completo (Colesterol total, HDL, LDL, Triglicéridos)\n5. Creatinina plasmática y Uremia\n6. Orina completa con sedimento urinario');
  const [labDiagnosis, setLabDiagnosis] = useState('Control periódico de Hipertensión Arterial y Diabetes Mellitus Tipo 2');

  const age = calculateAge(patient.filiation.birthDate);

  // Latest prescription items
  let currentRxList: PrescriptionItem[] = [];
  let currentDiagnoses: CIE10Diagnosis[] = [];

  if (patient.subsequentConsultations.length > 0) {
    const lastSub = patient.subsequentConsultations[patient.subsequentConsultations.length - 1];
    currentRxList = lastSub.treatmentPlan;
    currentDiagnoses = lastSub.diagnoses;
  } else if (patient.firstConsultation) {
    currentRxList = patient.firstConsultation.treatmentPlan;
    currentDiagnoses = patient.firstConsultation.diagnoses;
  }

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Controls Bar (no-print) */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 no-print">
        
        {/* Document Switcher */}
        <div>
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">
            Tipo de Documento Oficial:
          </span>
          <div className="inline-flex rounded-xl bg-slate-100 p-1 border border-slate-200">
            <button
              onClick={() => setDocType('prescription')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                docType === 'prescription' ? 'bg-teal-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Receta Médica Oficial
            </button>
            <button
              onClick={() => setDocType('summary')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                docType === 'summary' ? 'bg-teal-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Resumen de Historia Clínica
            </button>
            <button
              onClick={() => setDocType('labOrder')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                docType === 'labOrder' ? 'bg-teal-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Orden de Laboratorio / Estudios
            </button>
          </div>
        </div>

        {/* Print / Download Button */}
        <div className="flex items-center space-x-2">
          <button
            onClick={handlePrint}
            className="flex items-center space-x-2 px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs sm:text-sm rounded-lg shadow-sm transition cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Imprimir / Guardar en PDF</span>
          </button>
        </div>
      </div>

      {/* PAPER CANVAS / PRINTABLE DOCUMENT CONTAINER */}
      <div 
        id="printable-document" 
        className="max-w-3xl mx-auto bg-white rounded-2xl border border-slate-300 shadow-xl p-8 sm:p-12 text-slate-900 font-sans print:shadow-none print:border-none print:p-0 print:max-w-none"
      >
        
        {/* DOCTOR OFFICIAL LETTERHEAD */}
        <div className="border-b-2 border-slate-900 pb-5 mb-6 flex items-start justify-between">
          <div className="flex items-start space-x-4">
            <div className="w-12 h-12 rounded-xl bg-teal-800 text-white flex items-center justify-center font-bold text-2xl shadow-xs print:border print:border-black">
              +
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-slate-900">
                Dra. Elena Santillán
              </h1>
              <p className="text-xs font-semibold text-teal-800 uppercase tracking-wider">
                Especialista en Medicina Interna y Cardiología Clínica
              </p>
              <p className="text-[11px] text-slate-600 font-mono mt-0.5">
                Matrícula Nacional: 114.892 · Matrícula Provincial: 45.210
              </p>
              <p className="text-[11px] text-slate-500">
                Centro Médico Metropolitano · Av. Libertador 4800, Consultorio 602 · Tel: (011) 4782-9900
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="inline-block px-2.5 py-1 text-[10px] uppercase font-bold tracking-widest bg-slate-100 text-slate-700 rounded border border-slate-200">
              {docType === 'prescription' ? 'RECETA MÉDICA' : docType === 'summary' ? 'RESUMEN CLÍNICO' : 'ORDEN MÉDICA'}
            </span>
            <div className="text-xs text-slate-500 font-mono mt-2">
              Fecha: {formatDate(new Date().toISOString())}
            </div>
            <div className="text-[10px] text-slate-400 font-mono">
              Folio: #{patient.recordNumber}-2026
            </div>
          </div>
        </div>

        {/* PATIENT DEMOGRAPHIC STRIP */}
        <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 mb-6 text-xs grid grid-cols-2 sm:grid-cols-4 gap-3 print:bg-slate-100">
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold">Paciente:</span>
            <strong className="text-slate-900 font-semibold">{patient.filiation.fullName}</strong>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold">Documento:</span>
            <span className="font-mono">{patient.filiation.documentType}: {patient.filiation.documentNumber}</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold">Edad / Sexo:</span>
            <span>{age.text} · {patient.filiation.gender}</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold">Cobertura / Seguro:</span>
            <span>{patient.filiation.insuranceName || 'Particular'} ({patient.filiation.policyNumber || 'S/N'})</span>
          </div>
        </div>

        {/* DOCUMENT BODY: 1. RECETA MÉDICA */}
        {docType === 'prescription' && (
          <div className="space-y-6">
            
            {/* Diagnóstico CIE-10 */}
            {currentDiagnoses.length > 0 && (
              <div className="text-xs text-slate-600 border-b border-slate-100 pb-3">
                <span className="font-bold text-slate-800 uppercase tracking-wide text-[11px] mr-2">Diagnóstico:</span>
                {currentDiagnoses.map(d => `${d.code} - ${d.name}`).join('; ')}
              </div>
            )}

            {/* Rp / Simbolo Médico */}
            <div className="flex items-center space-x-2 text-teal-900 font-serif text-2xl font-bold italic">
              <span>Rp /</span>
            </div>

            {/* Prescribed Items */}
            <div className="space-y-4 pl-4 border-l-2 border-teal-700">
              {currentRxList.length > 0 ? (
                currentRxList.map((item, idx) => (
                  <div key={item.id || idx} className="text-xs sm:text-sm">
                    <div className="flex items-baseline space-x-2">
                      <span className="font-bold text-slate-900 text-sm">
                        {idx + 1}. {item.medication}
                      </span>
                      <span className="text-slate-600 font-mono text-xs">
                        {item.presentation}
                      </span>
                    </div>

                    <div className="text-slate-700 mt-1 pl-4 space-x-3 text-xs">
                      <span>• Dosis: <strong>{item.dosage}</strong></span>
                      <span>• Vía: {item.route}</span>
                      <span>• Frecuencia: <strong>{item.frequency}</strong></span>
                      <span>• Duración: {item.duration}</span>
                    </div>

                    {item.indications && (
                      <div className="text-slate-500 italic mt-0.5 pl-4 text-[11px]">
                        Indicación: {item.indications}
                      </div>
                    )}
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-500 italic">
                  No hay medicamentos prescritos en este momento. Registre una receta en la sección de Primera Consulta o Evolución.
                </p>
              )}
            </div>

            {/* Indications & Advice */}
            <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-3.5 text-xs text-amber-950 mt-6 print:bg-white print:border-slate-300">
              <span className="font-bold uppercase tracking-wide text-[10px] block mb-1">
                Indicaciones Higiénico-Dietéticas y Pautas de Alarma:
              </span>
              <p className="leading-relaxed">
                {patient.firstConsultation?.recommendations || 
                 'Dieta balanceada, reducción estricta de sodio. Consumo abundante de agua. En caso de presentar cefalea intensa súbita, mareo, opresión precordial o dificultad respiratoria, concurrir inmediatamente al centro de emergencias.'}
              </p>
            </div>

          </div>
        )}

        {/* DOCUMENT BODY: 2. RESUMEN DE HISTORIA CLÍNICA */}
        {docType === 'summary' && (
          <div className="space-y-5 text-xs">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-2">
              Resumen Clínico Integral y Epicrisis Ambulatoria
            </h2>

            {/* Antecedentes */}
            <div className="space-y-2">
              <div className="font-bold text-slate-800 uppercase text-[11px]">Antecedentes Relevantes:</div>
              <p className="text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-200">
                <strong>Patológicos:</strong> {patient.filiation.pathological.chronicDiseases || 'Sin enfermedades crónicas'}.<br />
                <strong>Alergias:</strong> {patient.filiation.allergies.length > 0 ? patient.filiation.allergies.map(a => `${a.allergen} (${a.severity})`).join(', ') : 'No refiere alergias'}.<br />
                <strong>Quirúrgicos:</strong> {patient.filiation.surgical.surgeries || 'Sin cirugías'}.<br />
                <strong>Heredofamiliares:</strong> {patient.filiation.hereditary.hypertension ? 'HTA familiar. ' : ''}{patient.filiation.hereditary.diabetes ? 'Diabetes familiar.' : ''}
              </p>
            </div>

            {/* Motivo de Primera Consulta y Evolución */}
            <div className="space-y-1">
              <div className="font-bold text-slate-800 uppercase text-[11px]">Historia Clínica y Diagnósticos:</div>
              <p className="text-slate-700 leading-relaxed">
                {patient.firstConsultation?.presentIllnessHistory || 'Paciente en seguimiento ambulatorio periódico.'}
              </p>
              <div className="mt-2">
                <strong>Diagnósticos Vigentes:</strong>{' '}
                {currentDiagnoses.map(d => `${d.code} (${d.name})`).join(', ')}
              </div>
            </div>

            {/* Últimos Signos Vitales */}
            {patient.firstConsultation && (
              <div className="border border-slate-200 p-3 rounded-lg">
                <div className="font-bold text-slate-800 text-[11px] uppercase mb-1">Últimos Signos Vitales Registrados:</div>
                <div className="grid grid-cols-4 gap-2 text-slate-700 font-mono text-xs">
                  <div>TA: {patient.firstConsultation.vitalSigns.systolicBP}/{patient.firstConsultation.vitalSigns.diastolicBP} mmHg</div>
                  <div>FC: {patient.firstConsultation.vitalSigns.heartRate} lpm</div>
                  <div>Peso: {patient.firstConsultation.vitalSigns.weightKg} kg</div>
                  <div>IMC: {patient.firstConsultation.vitalSigns.calculatedBMI} kg/m² ({patient.firstConsultation.vitalSigns.bmiCategory})</div>
                </div>
              </div>
            )}

            {/* Tratamiento Actual */}
            <div className="space-y-1">
              <div className="font-bold text-slate-800 uppercase text-[11px]">Esquema Terapéutico Actual:</div>
              <ul className="list-disc pl-5 text-slate-700 space-y-1">
                {currentRxList.map((item, i) => (
                  <li key={i}>
                    <strong>{item.medication}</strong> {item.presentation} - {item.dosage} cada {item.frequency}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {/* DOCUMENT BODY: 3. ORDEN DE LABORATORIO */}
        {docType === 'labOrder' && (
          <div className="space-y-5 text-xs">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-2">
              Solicitud de Pruebas Diagnósticas y Laboratorio Clínico
            </h2>

            <div className="no-print">
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Diagnóstico o Motivo del Estudio:</label>
              <input
                type="text"
                value={labDiagnosis}
                onChange={e => setLabDiagnosis(e.target.value)}
                className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg mb-3"
              />

              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Estudios Solicitados (Editable):</label>
              <textarea
                rows={6}
                value={labTests}
                onChange={e => setLabTests(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg font-mono"
              />
            </div>

            {/* Printable View */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 print:bg-white">
              <div>
                <strong className="text-slate-900">Diagnóstico de Presunción / Justificación:</strong>
                <p className="text-slate-700 mt-0.5">{labDiagnosis}</p>
              </div>

              <div>
                <strong className="text-slate-900">Determinaciones Solicitadas:</strong>
                <pre className="text-slate-800 font-sans whitespace-pre-line mt-1.5 leading-relaxed">
                  {labTests}
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* FOOTER: QR VERIFICATION & DOCTOR SIGNATURE */}
        <div className="mt-12 pt-6 border-t-2 border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-6">
          
          {/* QR Code Validation */}
          <div className="flex items-center space-x-3">
            <div className="w-16 h-16 bg-slate-100 border border-slate-300 rounded-lg p-1.5 flex flex-col items-center justify-center text-center">
              <QrCode className="w-10 h-10 text-slate-800" />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase text-slate-800 flex items-center space-x-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Verificación Digital Segura</span>
              </div>
              <p className="text-[9px] text-slate-500 font-mono mt-0.5">
                Hash: SHA256-7a8e...44b1
              </p>
              <p className="text-[9px] text-slate-400">
                Válido en farmacias y laboratorios acreditados
              </p>
            </div>
          </div>

          {/* Doctor Signature Stamp */}
          <div className="text-center sm:text-right">
            <div className="h-10 border-b border-slate-400 w-52 mb-1.5 mx-auto sm:ml-auto">
              <div className="text-teal-900 font-serif italic text-sm text-center pt-2">
                Dra. Elena Santillán
              </div>
            </div>
            <div className="text-xs font-bold text-slate-900">Dra. Elena Santillán</div>
            <div className="text-[11px] text-slate-600 font-mono">MN 114.892 · Especialista en Medicina Interna</div>
            <div className="text-[10px] text-slate-400">Firma y Sello Digital del Profesional</div>
          </div>

        </div>

      </div>

    </div>
  );
};
