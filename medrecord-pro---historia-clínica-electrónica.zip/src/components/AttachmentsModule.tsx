import React, { useState } from 'react';
import { 
  Paperclip, 
  Upload, 
  FileText, 
  Image as ImageIcon, 
  Trash2, 
  Eye, 
  Download, 
  CheckCircle,
  FileCheck,
  Plus
} from 'lucide-react';
import { Patient, ClinicalAttachment } from '../types/medical';
import { formatDate } from '../utils/medicalCalculators';

interface AttachmentsModuleProps {
  patient: Patient;
  onAddAttachment: (attachment: ClinicalAttachment) => void;
  onDeleteAttachment: (id: string) => void;
}

export const AttachmentsModule: React.FC<AttachmentsModuleProps> = ({
  patient,
  onAddAttachment,
  onDeleteAttachment
}) => {
  const [newFileName, setNewFileName] = useState('');
  const [newFileType, setNewFileType] = useState<ClinicalAttachment['fileType']>('Laboratorio');
  const [newFileNotes, setNewFileNotes] = useState('');
  const [previewItem, setPreviewItem] = useState<ClinicalAttachment | null>(null);

  const handleUploadSimulated = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFileName.trim()) return;

    const attachment: ClinicalAttachment = {
      id: `att-${Date.now()}`,
      patientId: patient.id,
      fileName: newFileName.endsWith('.pdf') ? newFileName : `${newFileName}.pdf`,
      fileType: newFileType,
      uploadDate: new Date().toISOString(),
      fileSize: `${(Math.random() * 2 + 0.5).toFixed(1)} MB`,
      notes: newFileNotes.trim() || undefined
    };

    onAddAttachment(attachment);
    setNewFileName('');
    setNewFileNotes('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
            <Paperclip className="w-5 h-5 text-teal-600" />
            <span>Estudios de Laboratorio, Imágenes y Consentimientos</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Almacenamiento seguro cifrado de informes analíticos, radiografías, ecografías y consentimientos legales informados.
          </p>
        </div>

        <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-slate-100 text-slate-700">
          {patient.attachments.length} archivos vinculados
        </span>
      </div>

      {/* Upload Box */}
      <form onSubmit={handleUploadSimulated} className="bg-white rounded-xl border border-dashed border-teal-300 p-5 shadow-2xs bg-teal-50/20">
        <h3 className="text-xs font-bold uppercase tracking-wider text-teal-900 mb-3 flex items-center space-x-1.5">
          <Upload className="w-4 h-4 text-teal-600" />
          <span>Adjuntar Nuevo Documento Clínico</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Nombre del Archivo / Estudio *</label>
            <input
              type="text"
              required
              placeholder="ej. Analítica_Bioquímica_Mayo_2026"
              value={newFileName}
              onChange={e => setNewFileName(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Categoría del Estudio</label>
            <select
              value={newFileType}
              onChange={e => setNewFileType(e.target.value as any)}
              className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            >
              <option value="Laboratorio">Laboratorio Bioquímico</option>
              <option value="Imagen / RX / ECO">Diagnóstico por Imagen (RX, ECO, RMN)</option>
              <option value="Consentimiento">Consentimiento Informado Firmado</option>
              <option value="Informe externo">Informe de Interconsulta Externa</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Notas / Hallazgos Clave</label>
            <input
              type="text"
              placeholder="ej. HbA1c 6.4%, Glucosa 108 mg/dL"
              value={newFileNotes}
              onChange={e => setNewFileNotes(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
          </div>
        </div>

        <div className="mt-3 flex justify-end">
          <button
            type="submit"
            className="flex items-center space-x-1.5 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-semibold shadow-xs transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Subir y Vincular a Historia Clínica</span>
          </button>
        </div>
      </form>

      {/* Files List */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-3">
        <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
          Expediente Digital de Archivos
        </h3>

        {patient.attachments.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {patient.attachments.map(file => (
              <div key={file.id} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-slate-50 transition flex items-start justify-between gap-3">
                <div className="flex items-start space-x-3">
                  <div className="w-10 h-10 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center shrink-0">
                    {file.fileType.includes('Imagen') ? (
                      <ImageIcon className="w-5 h-5" />
                    ) : (
                      <FileText className="w-5 h-5" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">{file.fileName}</h4>
                    <div className="flex items-center space-x-2 text-[11px] text-slate-500 mt-0.5">
                      <span className="font-semibold text-teal-700">{file.fileType}</span>
                      <span>•</span>
                      <span>{file.fileSize}</span>
                      <span>•</span>
                      <span>{formatDate(file.uploadDate)}</span>
                    </div>
                    {file.notes && (
                      <p className="text-xs text-slate-600 mt-1 italic">
                        {file.notes}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex items-center space-x-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => setPreviewItem(file)}
                    className="p-1.5 text-slate-500 hover:text-teal-700 hover:bg-white rounded-lg transition"
                    title="Ver detalle"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteAttachment(file.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-white rounded-lg transition"
                    title="Eliminar"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-slate-500 italic p-6 text-center bg-slate-50 rounded-xl">
            No hay estudios ni archivos adjuntos vinculados a este paciente.
          </p>
        )}
      </div>

      {/* Preview Modal */}
      {previewItem && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2">
                <FileCheck className="w-5 h-5 text-teal-600" />
                <h3 className="text-base font-bold text-slate-900">Visor de Documento Clínico</h3>
              </div>
              <button
                type="button"
                onClick={() => setPreviewItem(null)}
                className="text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl space-y-2 text-xs">
              <div><strong>Archivo:</strong> {previewItem.fileName}</div>
              <div><strong>Tipo:</strong> {previewItem.fileType}</div>
              <div><strong>Tamaño:</strong> {previewItem.fileSize}</div>
              <div><strong>Fecha de carga:</strong> {formatDate(previewItem.uploadDate)}</div>
              <div><strong>Observaciones médicas:</strong> {previewItem.notes || 'Sin notas'}</div>
            </div>

            <div className="p-8 border-2 border-dashed border-slate-200 rounded-xl text-center text-xs text-slate-500">
              <FileText className="w-10 h-10 text-slate-400 mx-auto mb-2" />
              <span>Vista previa simulada del documento PDF/Imagen médica. Integrado con almacenamiento seguro S3 cifrado en reposo.</span>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setPreviewItem(null)}
                className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold"
              >
                Cerrar Visor
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
