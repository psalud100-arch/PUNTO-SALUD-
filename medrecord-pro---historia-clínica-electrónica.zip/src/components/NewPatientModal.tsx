import React, { useState } from 'react';
import { X, UserPlus, Droplet, ShieldAlert, Check } from 'lucide-react';
import { Patient, BloodType, Gender, DocumentType } from '../types/medical';
import { calculateAge } from '../utils/medicalCalculators';

interface NewPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSavePatient: (newPatient: Patient) => void;
}

export const NewPatientModal: React.FC<NewPatientModalProps> = ({
  isOpen,
  onClose,
  onSavePatient
}) => {
  const [fullName, setFullName] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [gender, setGender] = useState<Gender>('Femenino');
  const [documentType, setDocumentType] = useState<DocumentType>('DNI');
  const [documentNumber, setDocumentNumber] = useState('');
  const [phone, setPhone] = useState('');
  const [mobile, setMobile] = useState('');
  const [bloodType, setBloodType] = useState<BloodType>('O+');
  const [insuranceName, setInsuranceName] = useState('');
  const [policyNumber, setPolicyNumber] = useState('');
  const [allergyText, setAllergyText] = useState('');

  if (!isOpen) return null;

  const age = calculateAge(birthDate);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !birthDate || !documentNumber.trim()) return;

    const newId = `pat-${Date.now()}`;
    const newRecordNum = `HC-2026-00${Math.floor(Math.random() * 900) + 100}`;

    const allergiesList = allergyText.trim() ? [
      {
        id: `alg-${Date.now()}`,
        allergen: allergyText.trim(),
        category: 'Medicamento' as const,
        severity: 'Severa / Anafilaxia' as const,
        reaction: 'Reportada en ingreso'
      }
    ] : [];

    const newPatient: Patient = {
      id: newId,
      recordNumber: newRecordNum,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: 'En espera',
      filiation: {
        fullName: fullName.trim(),
        birthDate,
        gender,
        civilStatus: 'Soltero/a',
        occupation: 'No especificada',
        educationLevel: 'Secundaria',
        documentType,
        documentNumber: documentNumber.trim(),
        address: '',
        city: '',
        stateProvince: '',
        phone: phone.trim(),
        mobile: mobile.trim() || phone.trim(),
        email: '',
        emergencyContactName: '',
        emergencyContactRelation: '',
        emergencyContactPhone: '',
        insuranceType: insuranceName ? 'Obra Social / Seguro Privado' : 'Particular',
        insuranceName: insuranceName.trim() || 'Particular',
        policyNumber: policyNumber.trim(),
        payerResponsible: 'Titular directo',
        bloodType,
        organDonor: true,
        allergies: allergiesList,
        hereditary: {
          diabetes: false,
          hypertension: false,
          cardiopathy: false,
          cancer: false,
          nephropathy: false,
          stroke: false
        },
        pathological: {
          chronicDiseases: '',
          infectiousDiseases: '',
          previousHospitalizations: '',
          currentMedications: ''
        },
        nonPathological: {
          immunizationsComplete: true,
          housingType: 'Urbana con servicios',
          petsZoonosis: 'Ninguna'
        },
        surgical: {
          surgeries: '',
          traumaFractures: '',
          transfusions: false
        },
        habits: {
          smoking: 'No fumador',
          alcoholConsumption: 'Ocasional / Social',
          drugsRecreational: 'Niega',
          physicalActivity: 'Sedentario',
          dietQuality: 'Estándar'
        }
      },
      firstConsultation: undefined,
      subsequentConsultations: [],
      attachments: []
    };

    onSavePatient(newPatient);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Alta de Nuevo Paciente</h3>
              <p className="text-xs text-slate-500">Apertura inmediata de Historia Clínica Electrónica</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nombre y Apellidos Completos *
            </label>
            <input
              type="text"
              required
              value={fullName}
              onChange={e => setFullName(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
              placeholder="ej. Mariana Victoria Pérez López"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Fecha de Nacimiento *
              </label>
              <input
                type="date"
                required
                value={birthDate}
                onChange={e => setBirthDate(e.target.value)}
                className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              {birthDate && (
                <div className="text-[11px] text-teal-700 font-semibold mt-1">
                  Edad calculada: {age.text}
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Sexo Biológico *
              </label>
              <select
                value={gender}
                onChange={e => setGender(e.target.value as Gender)}
                className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 bg-white"
              >
                <option value="Femenino">Femenino</option>
                <option value="Masculino">Masculino</option>
                <option value="Otro">Otro</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Tipo Doc.</label>
              <select
                value={documentType}
                onChange={e => setDocumentType(e.target.value as DocumentType)}
                className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg bg-white"
              >
                <option value="DNI">DNI</option>
                <option value="Cédula de Identidad">Cédula</option>
                <option value="Pasaporte">Pasaporte</option>
                <option value="CURP">CURP / RFC</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">Número de Documento *</label>
              <input
                type="text"
                required
                value={documentNumber}
                onChange={e => setDocumentNumber(e.target.value)}
                className="w-full px-3 py-1.5 text-xs font-mono border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
                placeholder="Número oficial"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Teléfono Móvil / WhatsApp</label>
              <input
                type="tel"
                value={mobile}
                onChange={e => setMobile(e.target.value)}
                className="w-full px-3 py-1.5 text-xs font-mono border border-slate-200 rounded-lg"
                placeholder="+54 9 11 ..."
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Grupo Sanguíneo y Rh</label>
              <select
                value={bloodType}
                onChange={e => setBloodType(e.target.value as BloodType)}
                className="w-full px-3 py-1.5 text-xs font-bold text-rose-800 bg-rose-50 border border-rose-200 rounded-lg"
              >
                <option value="O+">O Positivo (O+)</option>
                <option value="O-">O Negativo (O-)</option>
                <option value="A+">A Positivo (A+)</option>
                <option value="A-">A Negativo (A-)</option>
                <option value="B+">B Positivo (B+)</option>
                <option value="B-">B Negativo (B-)</option>
                <option value="AB+">AB Positivo (AB+)</option>
                <option value="AB-">AB Negativo (AB-)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Seguro / Obra Social</label>
              <input
                type="text"
                value={insuranceName}
                onChange={e => setInsuranceName(e.target.value)}
                className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg"
                placeholder="ej. OSDE / Particular"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">N° de Póliza / Afiliado</label>
              <input
                type="text"
                value={policyNumber}
                onChange={e => setPolicyNumber(e.target.value)}
                className="w-full px-3 py-1.5 text-xs font-mono border border-slate-200 rounded-lg"
              />
            </div>
          </div>

          {/* Critical Allergy alert input */}
          <div className="p-3 bg-rose-50/70 border border-rose-200 rounded-xl">
            <label className="block text-xs font-bold text-rose-900 mb-1 flex items-center space-x-1.5">
              <ShieldAlert className="w-4 h-4 text-rose-600" />
              <span>Alergias Críticas Conocidas (Opcional en ingreso)</span>
            </label>
            <input
              type="text"
              value={allergyText}
              onChange={e => setAllergyText(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-white border border-rose-300 rounded-lg focus:ring-2 focus:ring-rose-500"
              placeholder="ej. Alergia a Penicilina, AINEs, Látex..."
            />
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex items-center space-x-1.5 px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold shadow-xs transition"
            >
              <Check className="w-4 h-4" />
              <span>Crear e Iniciar Consulta</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
