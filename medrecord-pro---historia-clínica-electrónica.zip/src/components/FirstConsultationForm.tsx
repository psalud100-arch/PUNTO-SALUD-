import React, { useState, useEffect } from 'react';
import { 
  Stethoscope, 
  Save, 
  Check, 
  Sparkles, 
  Plus, 
  Trash2, 
  AlertCircle, 
  Heart, 
  Search, 
  FileText, 
  Printer, 
  CheckCircle2,
  HelpCircle,
  Activity
} from 'lucide-react';
import { 
  FirstConsultation, 
  SystemsReview, 
  PhysicalExamination, 
  VitalSigns, 
  CIE10Diagnosis, 
  PrescriptionItem,
  PrognosisType,
  Patient
} from '../types/medical';
import { calculateBMI, evaluateBloodPressure } from '../utils/medicalCalculators';
import { searchCIE10, CIE10Item } from '../data/cie10Catalog';
import { CLINICAL_TEMPLATES } from '../data/clinicalTemplates';

interface FirstConsultationFormProps {
  patient: Patient;
  existingConsultation?: FirstConsultation;
  onSave: (consultation: FirstConsultation) => void;
  onPrintPreview?: (consultation: FirstConsultation) => void;
}

const defaultSystemsReview: SystemsReview = {
  cardiovascular: { normal: true, notes: 'Sin palpitaciones, disnea ni dolor precordial.' },
  respiratory: { normal: true, notes: 'Sin tos, expectoración ni sibilancias.' },
  digestive: { normal: true, notes: 'Apetito conservado, ritmo evacuatorio regular sin pirosis.' },
  genitourinary: { normal: true, notes: 'Diuresis conservada, sin disuria ni hematuria.' },
  nervous: { normal: true, notes: 'Sin cefalea, mareos ni alteraciones sensitivo-motoras.' },
  musculoskeletal: { normal: true, notes: 'Sin artralgias ni limitaciones de movilidad articular.' },
  endocrine: { normal: true, notes: 'Sin intolerancia al frío/calor, poliuria ni polidipsia.' },
  integumentary: { normal: true, notes: 'Piel y faneras sin lesiones dérmicas activas.' }
};

const defaultPhysicalExam: PhysicalExamination = {
  generalState: 'Paciente vigil, orientado en tiempo, espacio y persona. Buen estado nutricional e hidratación. Facies compuesta, marcha sin alteraciones.',
  headAndNeck: 'Normocéfalo, sin puntos dolorosos. Faringe limpia sin exudados. Cuello simétrico, sin adenopatías palpables ni ingurgitación yugular. Tiroides no palpable.',
  thoraxAndLungs: 'Tórax simétrico y normoexpansible. Murmullo vesicular conservado en ambos campos pulmonares sin estertores ni ruidos agregados. Ruidos cardíacos rítmicos normofonéticos en 4 focos, sin soplos.',
  abdomen: 'Blando, depresible, no doloroso a la palpación superficial ni profunda. Sin visceromegalias palpables. Ruidos hidroaéreos normales.',
  extremities: 'Simétricas, con pulsos periféricos palpables y simétricos. Sin edemas maleolares. Llenado capilar menor a 2 segundos.',
  neurological: 'Sin signos de focalidad neurológica. Pares craneales conservados. Reflejos osteotendinosos simétricos ++/++++.'
};

const defaultVitalSigns: VitalSigns = {
  systolicBP: 120,
  diastolicBP: 80,
  heartRate: 72,
  respiratoryRate: 16,
  temperature: 36.5,
  oxygenSaturation: 98,
  weightKg: 70,
  heightCm: 170,
  calculatedBMI: 24.2,
  bmiCategory: 'Peso normal (Eutrófico)',
  capillaryBloodGlucose: 95
};

export const FirstConsultationForm: React.FC<FirstConsultationFormProps> = ({
  patient,
  existingConsultation,
  onSave,
  onPrintPreview
}) => {
  const [reason, setReason] = useState(existingConsultation?.reasonForConsultation || '');
  const [presentIllness, setPresentIllness] = useState(existingConsultation?.presentIllnessHistory || '');
  const [systems, setSystems] = useState<SystemsReview>(existingConsultation?.systemsReview || defaultSystemsReview);
  const [physicalExam, setPhysicalExam] = useState<PhysicalExamination>(existingConsultation?.physicalExamination || defaultPhysicalExam);
  const [vitals, setVitals] = useState<VitalSigns>(existingConsultation?.vitalSigns || defaultVitalSigns);
  const [priorStudies, setPriorStudies] = useState(existingConsultation?.priorStudies || '');
  const [diagnoses, setDiagnoses] = useState<CIE10Diagnosis[]>(existingConsultation?.diagnoses || []);
  const [treatmentPlan, setTreatmentPlan] = useState<PrescriptionItem[]>(existingConsultation?.treatmentPlan || []);
  const [recommendations, setRecommendations] = useState(existingConsultation?.recommendations || '');
  const [prognosis, setPrognosis] = useState<PrognosisType>(existingConsultation?.prognosis || 'Favorable');
  const [doctorStamp, setDoctorStamp] = useState(
    existingConsultation?.doctorSignatureStamp || 'Dra. Elena Santillán - MN 114.892 - Especialista en Medicina Interna'
  );
  const [saveSuccess, setSaveSuccess] = useState(false);

  // CIE-10 Search modal/dropdown state
  const [cieSearch, setCieSearch] = useState('');
  const [cieResults, setCieResults] = useState<CIE10Item[]>([]);
  const [showCieDropdown, setShowCieDropdown] = useState(false);

  // New Rx item temporary state
  const [newMedName, setNewMedName] = useState('');
  const [newMedPresentation, setNewMedPresentation] = useState('');
  const [newMedDosage, setNewMedDosage] = useState('');
  const [newMedRoute, setNewMedRoute] = useState<PrescriptionItem['route']>('Oral');
  const [newMedFreq, setNewMedFreq] = useState('');
  const [newMedDuration, setNewMedDuration] = useState('');
  const [newMedIndications, setNewMedIndications] = useState('');

  // Live BMI recalculation
  useEffect(() => {
    if (vitals.weightKg > 0 && vitals.heightCm > 0) {
      const { bmi, category } = calculateBMI(vitals.weightKg, vitals.heightCm);
      setVitals(prev => ({
        ...prev,
        calculatedBMI: bmi,
        bmiCategory: category
      }));
    }
  }, [vitals.weightKg, vitals.heightCm]);

  // Handle CIE-10 search
  useEffect(() => {
    if (cieSearch.trim().length > 0) {
      setCieResults(searchCIE10(cieSearch));
      setShowCieDropdown(true);
    } else {
      setCieResults([]);
      setShowCieDropdown(false);
    }
  }, [cieSearch]);

  const addCieDiagnosis = (item: CIE10Item) => {
    if (diagnoses.some(d => d.code === item.code)) return;
    const isFirst = diagnoses.length === 0;
    const newDiag: CIE10Diagnosis = {
      code: item.code,
      name: item.name,
      type: isFirst ? 'Principal' : 'Secundario',
      condition: 'Definitivo'
    };
    setDiagnoses(prev => [...prev, newDiag]);
    setCieSearch('');
    setShowCieDropdown(false);
  };

  const removeCieDiagnosis = (code: string) => {
    setDiagnoses(prev => prev.filter(d => d.code !== code));
  };

  const toggleDiagnosisType = (code: string) => {
    setDiagnoses(prev =>
      prev.map(d => (d.code === code ? { ...d, type: d.type === 'Principal' ? 'Secundario' : 'Principal' } : d))
    );
  };

  const toggleDiagnosisCondition = (code: string) => {
    setDiagnoses(prev =>
      prev.map(d => (d.code === code ? { ...d, condition: d.condition === 'Definitivo' ? 'Presuntivo' : 'Definitivo' } : d))
    );
  };

  const addMedication = () => {
    if (!newMedName.trim()) return;
    const item: PrescriptionItem = {
      id: `rx-${Date.now()}`,
      medication: newMedName.trim(),
      presentation: newMedPresentation.trim() || 'Comprimidos',
      dosage: newMedDosage.trim() || '1 toma',
      route: newMedRoute,
      frequency: newMedFreq.trim() || 'Cada 8 horas',
      duration: newMedDuration.trim() || 'Por 7 días',
      indications: newMedIndications.trim() || undefined
    };
    setTreatmentPlan(prev => [...prev, item]);
    setNewMedName('');
    setNewMedPresentation('');
    setNewMedDosage('');
    setNewMedFreq('');
    setNewMedDuration('');
    setNewMedIndications('');
  };

  const removeMedication = (id: string) => {
    setTreatmentPlan(prev => prev.filter(m => m.id !== id));
  };

  const markAllSystemsNormal = () => {
    setSystems({ ...defaultSystemsReview });
  };

  const loadNormalPhysicalExam = () => {
    setPhysicalExam({ ...defaultPhysicalExam });
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const payload: FirstConsultation = {
      id: existingConsultation?.id || `cons-first-${Date.now()}`,
      patientId: patient.id,
      date: existingConsultation?.date || new Date().toISOString(),
      doctorName: 'Dra. Elena Santillán',
      doctorSpecialty: 'Medicina Interna',
      doctorLicense: 'MN 114.892',
      reasonForConsultation: reason,
      presentIllnessHistory: presentIllness,
      systemsReview: systems,
      physicalExamination: physicalExam,
      vitalSigns: vitals,
      priorStudies,
      diagnoses,
      treatmentPlan,
      recommendations,
      prognosis,
      doctorSignatureStamp: doctorStamp
    };

    onSave(payload);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const bpStatus = evaluateBloodPressure(vitals.systolicBP, vitals.diastolicBP);

  return (
    <form onSubmit={handleSave} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Banner Notice */}
      <div className="bg-gradient-to-r from-blue-50 to-teal-50 border border-blue-200 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold shadow-xs">
            <Stethoscope className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Hoja de Consulta Externa Integral (Primera Vez)
            </h2>
            <p className="text-xs text-slate-600">
              Expediente clínico completo reglamentario: anamnesis, sistemas, examen físico, signos con IMC automático, CIE-10 y prescripción.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <button
            type="submit"
            className="flex items-center space-x-1.5 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs sm:text-sm rounded-lg shadow-xs transition"
          >
            {saveSuccess ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
            <span>{saveSuccess ? 'Guardado Exitoso' : 'Guardar Primera Consulta'}</span>
          </button>
        </div>
      </div>

      {/* MOTIVO DE CONSULTA Y ENFERMEDAD ACTUAL */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6 space-y-4">
        <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2 flex items-center space-x-2">
          <FileText className="w-4 h-4 text-teal-600" />
          <span>Motivo de Consulta & Enfermedad Actual (Anamnesis)</span>
        </h3>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Motivo de Consulta (Frase principal o queja del paciente) <span className="text-rose-500">*</span>
          </label>
          <input
            type="text"
            required
            value={reason}
            onChange={e => setReason(e.target.value)}
            className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
            placeholder="ej. Cefalea intensa de 2 semanas de evolución y cifras tensionales elevadas..."
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Historia de la Enfermedad Actual (Cronología, evolución, síntomas asociados, factores agravantes/atenuantes) <span className="text-rose-500">*</span>
          </label>
          <textarea
            rows={4}
            required
            value={presentIllness}
            onChange={e => setPresentIllness(e.target.value)}
            className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
            placeholder="Describa el inicio del cuadro clínico, tiempo de evolución, localización, irradiación, intensidad, tratamientos previos..."
          />
        </div>
      </div>

      {/* SIGNOS VITALES COMPLETOS CON CÁLCULO AUTOMÁTICO DE IMC */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
          <div className="flex items-center space-x-2">
            <Activity className="w-5 h-5 text-rose-600" />
            <h3 className="text-sm font-bold text-slate-900">Signos Vitales y Somatometría (IMC Automático)</h3>
          </div>
          <span className="text-xs text-slate-500">Cálculo de IMC en tiempo real según OMS</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          
          {/* Presión Sistólica */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">TA Sistólica</label>
            <div className="relative">
              <input
                type="number"
                value={vitals.systolicBP || ''}
                onChange={e => setVitals(prev => ({ ...prev, systolicBP: parseInt(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono font-bold text-slate-800 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-slate-400">mmHg</span>
            </div>
          </div>

          {/* Presión Diastólica */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">TA Diastólica</label>
            <div className="relative">
              <input
                type="number"
                value={vitals.diastolicBP || ''}
                onChange={e => setVitals(prev => ({ ...prev, diastolicBP: parseInt(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono font-bold text-slate-800 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-slate-400">mmHg</span>
            </div>
          </div>

          {/* Frecuencia Cardíaca */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Frec. Cardíaca</label>
            <div className="relative">
              <input
                type="number"
                value={vitals.heartRate || ''}
                onChange={e => setVitals(prev => ({ ...prev, heartRate: parseInt(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-slate-400">lpm</span>
            </div>
          </div>

          {/* Frecuencia Respiratoria */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Frec. Respiratoria</label>
            <div className="relative">
              <input
                type="number"
                value={vitals.respiratoryRate || ''}
                onChange={e => setVitals(prev => ({ ...prev, respiratoryRate: parseInt(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-slate-400">rpm</span>
            </div>
          </div>

          {/* Temperatura */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Temperatura</label>
            <div className="relative">
              <input
                type="number"
                step="0.1"
                value={vitals.temperature || ''}
                onChange={e => setVitals(prev => ({ ...prev, temperature: parseFloat(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-slate-400">°C</span>
            </div>
          </div>

          {/* SatO2 */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Sat. Oxígeno</label>
            <div className="relative">
              <input
                type="number"
                value={vitals.oxygenSaturation || ''}
                onChange={e => setVitals(prev => ({ ...prev, oxygenSaturation: parseInt(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-slate-400">%</span>
            </div>
          </div>

          {/* Peso (kg) */}
          <div>
            <label className="block text-[11px] font-semibold text-teal-800 mb-1">Peso (kg) *</label>
            <div className="relative">
              <input
                type="number"
                step="0.1"
                required
                value={vitals.weightKg || ''}
                onChange={e => setVitals(prev => ({ ...prev, weightKg: parseFloat(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono font-bold text-teal-900 bg-teal-50/50 border border-teal-300 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-teal-600 font-semibold">kg</span>
            </div>
          </div>

          {/* Talla (cm) */}
          <div>
            <label className="block text-[11px] font-semibold text-teal-800 mb-1">Talla (cm) *</label>
            <div className="relative">
              <input
                type="number"
                step="0.5"
                required
                value={vitals.heightCm || ''}
                onChange={e => setVitals(prev => ({ ...prev, heightCm: parseFloat(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono font-bold text-teal-900 bg-teal-50/50 border border-teal-300 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-teal-600 font-semibold">cm</span>
            </div>
          </div>

        </div>

        {/* Live calculated IMC bar & Blood pressure warning */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
          
          {/* IMC Live result */}
          <div className="flex items-center space-x-2 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
            <span className="text-slate-500 font-medium">Índice de Masa Corporal (IMC):</span>
            <span className="font-mono font-extrabold text-sm text-slate-900">
              {vitals.calculatedBMI} kg/m²
            </span>
            <span className={`px-2 py-0.5 rounded-full font-bold text-[11px] border ${
              vitals.calculatedBMI >= 30 
                ? 'bg-rose-50 text-rose-700 border-rose-200' 
                : vitals.calculatedBMI >= 25 
                ? 'bg-orange-50 text-orange-700 border-orange-200' 
                : 'bg-emerald-50 text-emerald-700 border-emerald-200'
            }`}>
              {vitals.bmiCategory}
            </span>
          </div>

          {/* TA Status */}
          <div className="flex items-center space-x-2">
            <span className="text-slate-500">Evaluación Tensional:</span>
            <span className={`px-2 py-0.5 rounded text-xs ${bpStatus.badgeClass}`}>
              {bpStatus.label} ({vitals.systolicBP}/{vitals.diastolicBP} mmHg)
            </span>
          </div>

          {/* Glucosa capilar */}
          <div className="flex items-center space-x-1.5 text-slate-600">
            <span>Glucemia Capilar:</span>
            <input
              type="number"
              placeholder="mg/dL"
              value={vitals.capillaryBloodGlucose || ''}
              onChange={e => setVitals(prev => ({ ...prev, capillaryBloodGlucose: parseInt(e.target.value) || undefined }))}
              className="w-20 px-2 py-1 text-xs border border-slate-200 rounded font-mono"
            />
            <span className="text-[10px] text-slate-400">mg/dL</span>
          </div>
        </div>
      </div>

      {/* INTERROGATORIO POR APARATOS Y SISTEMAS */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2">
            <Heart className="w-5 h-5 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900">Interrogatorio por Aparatos y Sistemas</h3>
          </div>
          <button
            type="button"
            onClick={markAllSystemsNormal}
            className="flex items-center space-x-1 px-3 py-1 text-xs font-semibold rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200 hover:bg-indigo-100 transition"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Marcar Todos Sin Hallazgos Patológicos</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {(Object.keys(systems) as (keyof SystemsReview)[]).map(key => {
            const labels: Record<keyof SystemsReview, string> = {
              cardiovascular: 'Cardiovascular',
              respiratory: 'Respiratorio',
              digestive: 'Digestivo',
              genitourinary: 'Genitourinario',
              nervous: 'Neurológico',
              musculoskeletal: 'Osteomuscular',
              endocrine: 'Endocrino',
              integumentary: 'Piel y Faneras'
            };
            const item = systems[key];

            return (
              <div key={key} className={`p-3 rounded-lg border transition ${item.normal ? 'bg-slate-50/60 border-slate-200' : 'bg-amber-50/70 border-amber-300'}`}>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-slate-800">{labels[key]}</span>
                  <button
                    type="button"
                    onClick={() => setSystems(prev => ({
                      ...prev,
                      [key]: { ...prev[key], normal: !prev[key].normal }
                    }))}
                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded cursor-pointer ${item.normal ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-200 text-amber-900'}`}
                  >
                    {item.normal ? 'Normal' : 'Patológico'}
                  </button>
                </div>
                <input
                  type="text"
                  value={item.notes}
                  onChange={e => setSystems(prev => ({
                    ...prev,
                    [key]: { ...prev[key], notes: e.target.value }
                  }))}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded focus:ring-1 focus:ring-teal-500 focus:outline-none"
                  placeholder="Detalles..."
                />
              </div>
            );
          })}
        </div>
      </div>

      {/* EXPLORACIÓN FÍSICA COMPLETA */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2">
            <Stethoscope className="w-5 h-5 text-teal-600" />
            <h3 className="text-sm font-bold text-slate-900">Exploración Física Completa por Regiones</h3>
          </div>
          <button
            type="button"
            onClick={loadNormalPhysicalExam}
            className="flex items-center space-x-1 px-3 py-1 text-xs font-semibold rounded-lg bg-teal-50 text-teal-700 border border-teal-200 hover:bg-teal-100 transition"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Insertar Examen Físico Normal</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Estado General, Habitus Exterior y Facies</label>
            <textarea
              rows={2}
              value={physicalExam.generalState}
              onChange={e => setPhysicalExam(prev => ({ ...prev, generalState: e.target.value }))}
              className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Cabeza, Ojos, Nariz, Oído, Orofaringe y Cuello</label>
            <textarea
              rows={2}
              value={physicalExam.headAndNeck}
              onChange={e => setPhysicalExam(prev => ({ ...prev, headAndNeck: e.target.value }))}
              className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Tórax, Campos Pulmonares y Ruidos Cardíacos</label>
            <textarea
              rows={2}
              value={physicalExam.thoraxAndLungs}
              onChange={e => setPhysicalExam(prev => ({ ...prev, thoraxAndLungs: e.target.value }))}
              className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Abdomen, Peristalsis y Visceromegalias</label>
            <textarea
              rows={2}
              value={physicalExam.abdomen}
              onChange={e => setPhysicalExam(prev => ({ ...prev, abdomen: e.target.value }))}
              className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Extremidades, Pulsos Periféricos y Edemas</label>
            <textarea
              rows={2}
              value={physicalExam.extremities}
              onChange={e => setPhysicalExam(prev => ({ ...prev, extremities: e.target.value }))}
              className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Examen Neurológico, Pares Craneales y Reflejos</label>
            <textarea
              rows={2}
              value={physicalExam.neurological}
              onChange={e => setPhysicalExam(prev => ({ ...prev, neurological: e.target.value }))}
              className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Estudios de Laboratorio / Gabinete Previos Traídos por el Paciente</label>
          <input
            type="text"
            value={priorStudies}
            onChange={e => setPriorStudies(e.target.value)}
            className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            placeholder="ej. Analítica de hace 1 mes: Glucemia 110, HbA1c 6.5%, RX de tórax normal..."
          />
        </div>
      </div>

      {/* DIAGNÓSTICOS CIE-10 (Búsqueda predictiva) */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900">Diagnósticos Codificados (CIE-10)</h3>
          </div>
          <span className="text-xs text-slate-500">Seleccione Principal / Secundario y Definitivo / Presuntivo</span>
        </div>

        {/* Existing Diagnoses List */}
        <div className="space-y-2">
          {diagnoses.length > 0 ? (
            diagnoses.map(diag => (
              <div key={diag.code} className="flex flex-wrap items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl gap-2">
                <div className="flex items-center space-x-2">
                  <span className="font-mono font-bold text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded border border-blue-200">
                    {diag.code}
                  </span>
                  <span className="text-sm font-semibold text-slate-900">{diag.name}</span>
                </div>

                <div className="flex items-center space-x-2">
                  {/* Principal vs Secundario */}
                  <button
                    type="button"
                    onClick={() => toggleDiagnosisType(diag.code)}
                    className={`text-xs px-2.5 py-1 rounded-md font-semibold transition cursor-pointer ${
                      diag.type === 'Principal'
                        ? 'bg-teal-600 text-white'
                        : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                    }`}
                  >
                    {diag.type}
                  </button>

                  {/* Definitivo vs Presuntivo */}
                  <button
                    type="button"
                    onClick={() => toggleDiagnosisCondition(diag.code)}
                    className={`text-xs px-2.5 py-1 rounded-md font-semibold transition cursor-pointer ${
                      diag.condition === 'Definitivo'
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : 'bg-amber-100 text-amber-800 border border-amber-300'
                    }`}
                  >
                    {diag.condition}
                  </button>

                  <button
                    type="button"
                    onClick={() => removeCieDiagnosis(diag.code)}
                    className="p-1 text-slate-400 hover:text-rose-600 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          ) : (
            <p className="text-xs text-slate-500 italic p-3 bg-slate-50 rounded-lg border border-dashed border-slate-200">
              No se han agregado diagnósticos CIE-10 aún. Utilice el buscador inferior.
            </p>
          )}
        </div>

        {/* Search CIE-10 Input */}
        <div className="relative">
          <div className="flex items-center space-x-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={cieSearch}
                onChange={e => setCieSearch(e.target.value)}
                placeholder="Buscar por código o nombre (ej. 'I10', 'hipertensión', 'diabetes', 'asma')..."
                className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              />
            </div>
          </div>

          {/* CIE-10 Dropdown search results */}
          {showCieDropdown && cieResults.length > 0 && (
            <div className="absolute z-20 w-full mt-1 bg-white border border-slate-200 rounded-xl shadow-lg max-h-60 overflow-y-auto divide-y divide-slate-100">
              {cieResults.map(item => (
                <button
                  key={item.code}
                  type="button"
                  onClick={() => addCieDiagnosis(item)}
                  className="w-full text-left px-4 py-2.5 hover:bg-teal-50 flex items-center justify-between transition group"
                >
                  <div className="flex items-center space-x-2.5">
                    <span className="font-mono font-bold text-xs bg-slate-100 group-hover:bg-teal-100 text-slate-800 group-hover:text-teal-900 px-2 py-0.5 rounded">
                      {item.code}
                    </span>
                    <span className="text-xs font-medium text-slate-900">{item.name}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-medium">{item.category}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* PLAN DE TRATAMIENTO FARMACOLÓGICO */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2">
            <Heart className="w-5 h-5 text-emerald-600" />
            <h3 className="text-sm font-bold text-slate-900">Plan de Tratamiento Farmacológico (Prescripción)</h3>
          </div>
          <span className="text-xs text-slate-500">Se generará la receta médica oficial automáticamente</span>
        </div>

        {/* Existing Prescriptions */}
        <div className="space-y-2">
          {treatmentPlan.length > 0 ? (
            treatmentPlan.map((rx, idx) => (
              <div key={rx.id} className="flex items-start justify-between p-3 bg-emerald-50/50 border border-emerald-200 rounded-xl">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold">
                      {idx + 1}
                    </span>
                    <span className="font-bold text-sm text-slate-900">{rx.medication}</span>
                    <span className="text-xs text-slate-600 font-mono">({rx.presentation})</span>
                  </div>
                  <div className="text-xs text-slate-700 mt-1 pl-7 space-x-3">
                    <span><strong>Dosis:</strong> {rx.dosage}</span>
                    <span><strong>Vía:</strong> {rx.route}</span>
                    <span><strong>Frecuencia:</strong> {rx.frequency}</span>
                    <span><strong>Duración:</strong> {rx.duration}</span>
                  </div>
                  {rx.indications && (
                    <div className="text-[11px] text-slate-500 mt-0.5 pl-7 italic">
                      Indicación adicional: {rx.indications}
                    </div>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => removeMedication(rx.id)}
                  className="p-1 text-slate-400 hover:text-rose-600 transition"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          ) : (
            <p className="text-xs text-slate-500 italic p-3 bg-slate-50 rounded-lg border border-dashed border-slate-200">
              No hay fármacos prescritos aún. Agregue medicamentos usando el formulario rápido inferior.
            </p>
          )}
        </div>

        {/* Add Medication Box */}
        <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
          <div className="text-xs font-bold text-slate-800">Agregar Medicamento a la Receta:</div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <input
              type="text"
              placeholder="Fármaco (ej. Losartán Potásico)"
              value={newMedName}
              onChange={e => setNewMedName(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
            <input
              type="text"
              placeholder="Presentación (ej. Comp. 50mg)"
              value={newMedPresentation}
              onChange={e => setNewMedPresentation(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
            <input
              type="text"
              placeholder="Dosis (ej. 1 comprimido)"
              value={newMedDosage}
              onChange={e => setNewMedDosage(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
            <select
              value={newMedRoute}
              onChange={e => setNewMedRoute(e.target.value as any)}
              className="px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            >
              <option value="Oral">Vía Oral</option>
              <option value="Sublingual">Vía Sublingual</option>
              <option value="Intravenosa">Vía Intravenosa</option>
              <option value="Intramuscular">Vía Intramuscular</option>
              <option value="Inhalatoria">Vía Inhalatoria</option>
              <option value="Tópica">Vía Tópica</option>
              <option value="Oftálmica">Vía Oftálmica</option>
            </select>
            <input
              type="text"
              placeholder="Frecuencia (ej. Cada 12 horas)"
              value={newMedFreq}
              onChange={e => setNewMedFreq(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
            <input
              type="text"
              placeholder="Duración (ej. Por 30 días)"
              value={newMedDuration}
              onChange={e => setNewMedDuration(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
            <button
              type="button"
              onClick={addMedication}
              className="flex items-center justify-center space-x-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Añadir a Receta</span>
            </button>
          </div>

          <input
            type="text"
            placeholder="Indicaciones para el paciente (ej. Tomar con abundante agua en ayunas)"
            value={newMedIndications}
            onChange={e => setNewMedIndications(e.target.value)}
            className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
          />
        </div>
      </div>

      {/* INDICACIONES GENERALES, PRONÓSTICO Y FIRMA MÉDICA */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6 space-y-4">
        <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
          Recomendaciones Higiénico-Dietéticas, Pronóstico & Firma
        </h3>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Indicaciones No Farmacológicas, Estilo de Vida y Pautas de Alarma
          </label>
          <textarea
            rows={2}
            value={recommendations}
            onChange={e => setRecommendations(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            placeholder="ej. Dieta baja en sodio, actividad física de 30 minutos al día, control de glucemia, pautas de alarma..."
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Pronóstico Médico</label>
            <select
              value={prognosis}
              onChange={e => setPrognosis(e.target.value as PrognosisType)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 bg-white"
            >
              <option value="Favorable">Favorable</option>
              <option value="Reservado a evolución">Reservado a evolución</option>
              <option value="Bueno">Bueno</option>
              <option value="Grave">Grave / Crítico</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Firma / Sello del Médico Responsable</label>
            <input
              type="text"
              value={doctorStamp}
              onChange={e => setDoctorStamp(e.target.value)}
              className="w-full px-3 py-2 text-xs font-mono border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
          </div>
        </div>
      </div>

      {/* Action Footer */}
      <div className="flex items-center justify-between p-4 bg-white rounded-xl border border-slate-200 shadow-md">
        <div className="text-xs text-slate-500">
          Documento médico legal conforme a normativas de historia clínica.
        </div>
        <button
          type="submit"
          className="flex items-center space-x-2 px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-sm rounded-lg shadow-sm transition"
        >
          {saveSuccess ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          <span>{saveSuccess ? '¡Primera Consulta Guardada!' : 'Finalizar y Guardar Consulta'}</span>
        </button>
      </div>

    </form>
  );
};
