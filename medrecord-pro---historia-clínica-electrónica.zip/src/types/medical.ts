export type BloodType = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
export type Gender = 'Masculino' | 'Femenino' | 'Otro';
export type CivilStatus = 'Soltero/a' | 'Casado/a' | 'Unión libre' | 'Divorciado/a' | 'Viudo/a';
export type DocumentType = 'DNI' | 'Cédula de Identidad' | 'Pasaporte' | 'Cédula de Extranjería' | 'CURP' | 'Otro';
export type PrognosisType = 'Favorable' | 'Reservado a evolución' | 'Grave' | 'Bueno';
export type EvolutionMode = 'soap' | 'free';

export interface AllergyItem {
  id: string;
  allergen: string;
  category: 'Medicamento' | 'Alimento' | 'Ambiental' | 'Látex' | 'Otro';
  severity: 'Leve' | 'Moderada' | 'Severa / Anafilaxia';
  reaction?: string;
}

export interface HereditaryBackground {
  diabetes: boolean;
  diabetesDetail?: string;
  hypertension: boolean;
  hypertensionDetail?: string;
  cardiopathy: boolean;
  cardiopathyDetail?: string;
  cancer: boolean;
  cancerDetail?: string;
  nephropathy: boolean;
  nephropathyDetail?: string;
  stroke: boolean;
  strokeDetail?: string;
  others?: string;
}

export interface PathologicalBackground {
  chronicDiseases: string;
  infectiousDiseases: string;
  previousHospitalizations: string;
  currentMedications: string;
}

export interface NonPathologicalBackground {
  immunizationsComplete: boolean;
  immunizationsDetail?: string;
  housingType: string;
  petsZoonosis: string;
}

export interface SurgicalBackground {
  surgeries: string;
  traumaFractures: string;
  transfusions: boolean;
  transfusionsDetail?: string;
}

export interface GynecologicalBackground {
  menarcheAge?: number;
  lastMenstrualPeriod?: string; // FUM
  cycleRhythm?: string;
  pregnancies?: number; // G
  births?: number; // P
  abortions?: number; // A
  cesareans?: number; // C
  contraceptiveMethod?: string;
  lastPapSmearDate?: string;
  lastMammogramDate?: string;
}

export interface HabitsLifestyle {
  smoking: 'No fumador' | 'Fumador activo' | 'Ex-fumador';
  smokingPacksPerYear?: number;
  alcoholConsumption: 'Nunca' | 'Ocasional / Social' | 'Frecuente / Moderado' | 'Alto';
  drugsRecreational: string;
  physicalActivity: 'Sedentario' | '1-2 días/semana' | '3-5 días/semana' | 'Atleta / Diario';
  dietQuality: string;
}

export interface PatientFiliation {
  // Datos personales
  fullName: string;
  birthDate: string; // YYYY-MM-DD
  gender: Gender;
  civilStatus: CivilStatus;
  occupation: string;
  educationLevel: 'Primaria' | 'Secundaria' | 'Técnico' | 'Universitario' | 'Posgrado' | 'Ninguno';
  
  // Documento
  documentType: DocumentType;
  documentNumber: string;

  // Contacto & Domicilio
  address: string;
  city: string;
  stateProvince: string;
  phone: string;
  mobile: string;
  email: string;

  // Contacto de emergencia
  emergencyContactName: string;
  emergencyContactRelation: string;
  emergencyContactPhone: string;

  // Seguro / Afiliación
  insuranceType: 'Pública / Sin cobertura' | 'Obra Social / Seguro Privado' | 'Particular';
  insuranceName: string;
  policyNumber: string;
  payerResponsible: string;

  // Datos clínicos fijos
  bloodType: BloodType;
  organDonor: boolean;

  // Antecedentes integrales
  allergies: AllergyItem[];
  hereditary: HereditaryBackground;
  pathological: PathologicalBackground;
  nonPathological: NonPathologicalBackground;
  surgical: SurgicalBackground;
  gynecological?: GynecologicalBackground;
  habits: HabitsLifestyle;
}

export interface VitalSigns {
  systolicBP: number; // mmHg (Tensión arterial sistólica)
  diastolicBP: number; // mmHg (Tensión arterial diastólica)
  heartRate: number; // lpm (Frecuencia cardíaca)
  respiratoryRate: number; // rpm (Frecuencia respiratoria)
  temperature: number; // °C
  oxygenSaturation: number; // % SatO2
  weightKg: number; // kg
  heightCm: number; // cm
  calculatedBMI: number; // kg/m^2 (calculado)
  bmiCategory: string; // 'Bajo peso' | 'Normal' | 'Sobrepeso' | 'Obesidad I' | 'Obesidad II' | 'Obesidad III'
  capillaryBloodGlucose?: number; // mg/dL opcional
}

export interface CIE10Diagnosis {
  code: string;
  name: string;
  type: 'Principal' | 'Secundario';
  condition: 'Presuntivo' | 'Definitivo';
}

export interface PrescriptionItem {
  id: string;
  medication: string;
  presentation: string; // ej: Comprimidos 500mg
  dosage: string; // ej: 1 comprimido
  route: 'Oral' | 'Sublingual' | 'Intravenosa' | 'Intramuscular' | 'Tópica' | 'Inhalatoria' | 'Oftálmica' | 'Ótica';
  frequency: string; // ej: Cada 8 horas
  duration: string; // ej: Por 7 días
  indications?: string; // ej: Tomar después de alimentos
}

export interface SystemsReview {
  cardiovascular: { normal: boolean; notes: string };
  respiratory: { normal: boolean; notes: string };
  digestive: { normal: boolean; notes: string };
  genitourinary: { normal: boolean; notes: string };
  nervous: { normal: boolean; notes: string };
  musculoskeletal: { normal: boolean; notes: string };
  endocrine: { normal: boolean; notes: string };
  integumentary: { normal: boolean; notes: string }; // piel y anexos
}

export interface PhysicalExamination {
  generalState: string;
  headAndNeck: string;
  thoraxAndLungs: string;
  abdomen: string;
  extremities: string;
  neurological: string;
}

// 1. Primera Consulta (Hoja de Consulta Externa completa)
export interface FirstConsultation {
  id: string;
  patientId: string;
  date: string; // ISO String
  doctorName: string;
  doctorSpecialty: string;
  doctorLicense: string;

  reasonForConsultation: string; // Motivo de consulta
  presentIllnessHistory: string; // Enfermedad actual (historia completa)
  systemsReview: SystemsReview; // Interrogatorio por aparatos y sistemas
  physicalExamination: PhysicalExamination; // Exploración física completa
  vitalSigns: VitalSigns; // Signos vitales
  priorStudies: string; // Estudios de laboratorio / gabinete previos
  diagnoses: CIE10Diagnosis[]; // Diagnósticos (CIE-10)
  treatmentPlan: PrescriptionItem[]; // Plan de tratamiento farmacológico
  recommendations: string; // Indicaciones y recomendaciones higiénico-dietéticas
  prognosis: PrognosisType; // Pronóstico
  doctorSignatureStamp: string; // Firma/sello del médico
}

// 2. Consulta Subsecuente (Evolución)
export interface SubsequentConsultation {
  id: string;
  patientId: string;
  date: string; // ISO String
  doctorName: string;
  doctorSpecialty: string;
  doctorLicense: string;
  mode: EvolutionMode; // 'soap' | 'free'

  // Si mode == 'soap'
  soap?: {
    subjective: string; // S: Lo que el paciente refiere, síntomas, evolución
    objective: string; // O: Hallazgos clínicos, exploración dirigida
    assessment: string; // A: Análisis, juicio clínico, evolución de la patología
    plan: string; // P: Plan diagnóstico y terapéutico
  };

  // Si mode == 'free'
  freeEvolutionNote?: string; // Estilo clásico de nota de evolución médica

  vitalSigns: VitalSigns;
  diagnoses: CIE10Diagnosis[];
  treatmentPlan: PrescriptionItem[];
  generalIndications?: string;
  nextAppointmentDate?: string; // Próxima cita (opcional)
  doctorSignatureStamp: string;
}

export interface ClinicalAttachment {
  id: string;
  patientId: string;
  consultationId?: string;
  fileName: string;
  fileType: 'Laboratorio' | 'Imagen / RX / ECO' | 'Consentimiento' | 'Informe externo';
  uploadDate: string;
  fileSize: string;
  url?: string;
  notes?: string;
}

export interface Patient {
  id: string;
  recordNumber: string; // HC-2026-0012
  createdAt: string;
  updatedAt: string;
  status: 'Activo' | 'En consulta' | 'En espera' | 'Inactivo';
  filiation: PatientFiliation;
  firstConsultation?: FirstConsultation;
  subsequentConsultations: SubsequentConsultation[];
  attachments: ClinicalAttachment[];
}
