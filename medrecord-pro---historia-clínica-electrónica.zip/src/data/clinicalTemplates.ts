export interface ClinicalTemplate {
  id: string;
  title: string;
  category: 'Examen Físico' | 'Control HTA' | 'Control Diabetes' | 'Infección Respiratoria' | 'Control General' | 'Postquirúrgico';
  soap?: {
    s: string;
    o: string;
    a: string;
    p: string;
  };
  freeText?: string;
  physicalExam?: {
    generalState: string;
    headAndNeck: string;
    thoraxAndLungs: string;
    abdomen: string;
    extremities: string;
    neurological: string;
  };
  recommendations?: string;
}

export const CLINICAL_TEMPLATES: ClinicalTemplate[] = [
  {
    id: 'exam-normal',
    title: 'Examen Físico Completo Normal',
    category: 'Examen Físico',
    physicalExam: {
      generalState: 'Paciente lúcido, orientado en tiempo, espacio y persona. Buen estado nutricional e hidratación. Facies compuesta, marcha eutrófica sin claudicación.',
      headAndNeck: 'Normocéfalo, sin puntos dolorosos ni deformidades. Pupilas isocóricas reactivas a la luz. Faringe sin congestión ni exudados. Cuello cilíndrico, móvil, sin adenopatías ni ingurgitación yugular. Tiroides no palpable.',
      thoraxAndLungs: 'Tórax simétrico, normoexpansible. Murmullo vesicular conservado bilateralmente sin ruidos agregados ni estertores. Ruidos cardíacos rítmicos y regulares, sin soplos audibles.',
      abdomen: 'Blando, depresible, no doloroso a la palpación superficial ni profunda. Sin visceromegalias (hígado y bazo no palpables). Ruidos hidroaéreos presentes y normales. Signos peritoneales negativos.',
      extremities: 'Simétricas, con tono y trofismo conservados. Pulsos periféricos pedios y tibiales posteriores palpables y simétricos. Sin edemas periféricos. Llenado capilar < 2 segundos.',
      neurological: 'Sin focalidad neurológica. Pares craneales conservados. Reflejos osteotendinosos simétricos ++/++++. Sensibilidad superficial y profunda conservada.'
    }
  },
  {
    id: 'control-hta-estable',
    title: 'Control HTA Esencial Compensada',
    category: 'Control HTA',
    soap: {
      s: 'Paciente acude a control periódico de hipertensión arterial. Refiere encontrarse asintomático, sin cefalea, acúfenos, fosfenos ni dolor precordial. Manifiesta buena adherencia terapéutica diaria sin olvidos ni efectos adversos.',
      o: 'Paciente en buen estado general, vigil y eupneico. Ruidos cardíacos rítmicos sin soplos. Campos pulmonares limpios. Extremidades sin edemas periféricos. Registro de presión arterial dentro de metas terapéuticas.',
      a: 'Hipertensión arterial esencial estadio 1, actualmente controlada y compensada con esquema farmacológico actual. Bajo riesgo cardiovascular a corto plazo.',
      p: '1. Mantener tratamiento antihipertensivo habitual.\n2. Continuar dieta hiposódica (< 2g Na/día) y actividad física aeróbica 150 min/semana.\n3. Registro ambulatorio de presión arterial (MAPA/AMPA) 2 veces por semana.\n4. Cita de control con analítica básica (creatinina, electrolitos, lipidograma) en 3 meses.'
    },
    freeText: 'Paciente acude a control de HTA esencial. Refiere adherencia estricta al tratamiento farmacológico, sin síntomas de alarma cardiológica ni cefalea. Al examen físico: vigil, normohidratado, ruidos cardíacos normofonéticos sin soplos, murmullo vesicular conservado, pulsos periféricos presentes sin edemas. Cifras tensionales en rango meta. Impresión diagnóstica: HTA esencial compensada. Plan: Se mantiene esquema actual, refuerzo de medidas higiénico-dietéticas y control en 3 meses.',
    recommendations: 'Dieta baja en sodio, evitar ultraprocesados, consumir al menos 2 litros de agua al día, realizar caminatas diarias de 30 a 45 minutos.'
  },
  {
    id: 'control-dm2-compensada',
    title: 'Control Diabetes Mellitus Tipo 2',
    category: 'Control Diabetes',
    soap: {
      s: 'Paciente en control por DM2. Niega poliuria, polidipsia o pérdida de peso involuntaria. Sin parestesias en calcetín ni lesiones en miembros inferiores. Refiere cumplimiento de plan nutricional y medicación.',
      o: 'Buen estado general. Fondo de ojo sin alteraciones groseras. Pulsos periféricos simétricos. Inspección de pies: piel íntegra, sin úlceras, hiperqueratosis leve sin signos de infección. Sensibilidad monofilamento 10g conservada en ambos pies.',
      a: 'Diabetes Mellitus tipo 2 en seguimiento, sin complicaciones agudas aparentes. Buen control metabólico aparente.',
      p: '1. Continuar régimen hipoglucemiante actual.\n2. Solicitar HbA1c, glucemia basal, perfil lipídico y microalbuminuria en orina de 24h.\n3. Revisión diaria de pies por parte del paciente.\n4. Control en 3 meses con resultados de laboratorio.'
    },
    freeText: 'Consulta de seguimiento DM2. Paciente asintomático sin síndrome de las 4P. Pies sin lesiones tróficas, pulsos pedios palpables, sensibilidad conservada. Plan: Mantener medicación, solicitar perfil metabólico y hemoglobina glicada, control trimestral.',
    recommendations: 'Plan de alimentación con bajo índice glucémico, calzado adecuado cómodo sin costuras internas, no caminar descalzo.'
  },
  {
    id: 'infeccion-respiratoria-alta',
    title: 'Infección Respiratoria Aguda Alta (IRA)',
    category: 'Infección Respiratoria',
    soap: {
      s: 'Cuadro de 3 días de evolución caracterizado por odinofagia, rinorrea hialina, estornudos frecuentes y febrícula no cuantificada. Niega disnea, dolor torácico o expectoración mucopurulenta.',
      o: 'Facies febril leve. Fosas nasales con mucosa eritematosa y secreción seromucosa. Orofaringe: eritema difuso de pilares y pared posterior, amígdalas eutróficas sin placas exudativas purulentas. Cuello con microadenopatías submandibulares móviles no dolorosas. Pulmones con murmullo vesicular conservado sin ruidos sobreagregados. SatO2 98% al aire ambiente.',
      a: 'Rinofaringitis aguda catarral de probable etiología viral.',
      p: '1. Manejo sintomático: Paracetamol 500mg - 1g c/8h si dolor o fiebre.\n2. Lavados nasales con solución salina fisiológica al 0.9% c/6h.\n3. Abundante hidratación oral (2-3 L/día).\n4. Reposo relativo por 48 horas.\n5. Pautas de alarma (fiebre persistente > 38.5°C por más de 72h, disnea, dolor torácico) acudir a urgencias.'
    },
    freeText: 'Paciente consulta por cuadro catarral de 3 días con rinorrea, congestión y odinofagia. Orofaringe congestiva sin exudados, auscultación pulmonar sin compromiso de vía aérea inferior. Diagnóstico: Rinofaringitis aguda viral. Tratamiento sintomático, hidratación y pautas de alarma.',
    recommendations: 'Reposo en casa, uso de cubrebocas si convive con personas vulnerables, lavados nasales frecuentes y adecuada ingesta de líquidos tibios.'
  }
];
