export interface CIE10Item {
  code: string;
  name: string;
  category: string;
}

export const CIE10_DATABASE: CIE10Item[] = [
  // Cardiovascular
  { code: 'I10', name: 'Hipertensión esencial (primaria)', category: 'Cardiovascular' },
  { code: 'I11.9', name: 'Enfermedad cardíaca hipertensiva sin insuficiencia cardíaca', category: 'Cardiovascular' },
  { code: 'I20.9', name: 'Angina de pecho, no especificada', category: 'Cardiovascular' },
  { code: 'I25.1', name: 'Enfermedad aterosclerótica del corazón', category: 'Cardiovascular' },
  { code: 'I48.0', name: 'Fibrilación auricular paroxística', category: 'Cardiovascular' },
  { code: 'I50.9', name: 'Insuficiencia cardíaca, no especificada', category: 'Cardiovascular' },
  { code: 'I83.9', name: 'Venas varicosas de las extremidades inferiores', category: 'Cardiovascular' },

  // Endocrino y Metabólico
  { code: 'E11.9', name: 'Diabetes mellitus tipo 2 sin mención de complicación', category: 'Endocrino' },
  { code: 'E11.2', name: 'Diabetes mellitus tipo 2 con complicaciones renales', category: 'Endocrino' },
  { code: 'E10.9', name: 'Diabetes mellitus tipo 1 sin mención de complicación', category: 'Endocrino' },
  { code: 'E03.9', name: 'Hipotiroidismo, no especificado', category: 'Endocrino' },
  { code: 'E05.9', name: 'Tirotoxicosis [hipertiroidismo], no especificada', category: 'Endocrino' },
  { code: 'E66.0', name: 'Obesidad debida a exceso de calorías', category: 'Endocrino' },
  { code: 'E78.0', name: 'Hipercolesterolemia pura', category: 'Endocrino' },
  { code: 'E78.2', name: 'Hiperlipidemia mixta', category: 'Endocrino' },
  { code: 'E79.0', name: 'Hiperuricemia sin signos de artritis inflamatoria', category: 'Endocrino' },

  // Respiratorio
  { code: 'J00', name: 'Rinofaringitis aguda [resfriado común]', category: 'Respiratorio' },
  { code: 'J02.9', name: 'Faringitis aguda, no especificada', category: 'Respiratorio' },
  { code: 'J03.9', name: 'Amigdalitis aguda, no especificada', category: 'Respiratorio' },
  { code: 'J01.9', name: 'Sinusitis aguda, no especificada', category: 'Respiratorio' },
  { code: 'J20.9', name: 'Bronquitis aguda, no especificada', category: 'Respiratorio' },
  { code: 'J44.9', name: 'Enfermedad pulmonar obstructiva crónica (EPOC)', category: 'Respiratorio' },
  { code: 'J45.9', name: 'Asma, no especificada', category: 'Respiratorio' },
  { code: 'J18.9', name: 'Neumonía, no especificada', category: 'Respiratorio' },
  { code: 'J30.4', name: 'Rinitis alérgica, no especificada', category: 'Respiratorio' },

  // Gastrointestinal
  { code: 'K21.9', name: 'Enfermedad por reflujo gastroesofágico sin esofagitis', category: 'Gastrointestinal' },
  { code: 'K29.7', name: 'Gastritis, no especificada', category: 'Gastrointestinal' },
  { code: 'K25.9', name: 'Úlcera gástrica, no especificada', category: 'Gastrointestinal' },
  { code: 'K58.9', name: 'Síndrome del intestino irritable sin diarrea', category: 'Gastrointestinal' },
  { code: 'K58.0', name: 'Síndrome del intestino irritable con predominio de diarrea', category: 'Gastrointestinal' },
  { code: 'K59.0', name: 'Constipación / Estreñimiento', category: 'Gastrointestinal' },
  { code: 'K80.2', name: 'Cálculo de la vesícula biliar sin colecistitis (Litiasis vesicular)', category: 'Gastrointestinal' },
  { code: 'K76.0', name: 'Hígado graso (esteatosis hepática)', category: 'Gastrointestinal' },

  // Músculo-esquelético
  { code: 'M54.5', name: 'Lumbago no especificado / Lumbalgia mecánica', category: 'Osteomuscular' },
  { code: 'M54.2', name: 'Cervicalgia', category: 'Osteomuscular' },
  { code: 'M17.9', name: 'Gonartrosis, no especificada (Artrosis de rodilla)', category: 'Osteomuscular' },
  { code: 'M16.9', name: 'Coxartrosis, no especificada (Artrosis de cadera)', category: 'Osteomuscular' },
  { code: 'M75.1', name: 'Síndrome del manguito rotatorio', category: 'Osteomuscular' },
  { code: 'M79.7', name: 'Fibromialgia', category: 'Osteomuscular' },
  { code: 'M81.9', name: 'Osteoporosis, no especificada', category: 'Osteomuscular' },

  // Nefrourología
  { code: 'N39.0', name: 'Infección de vías urinarias, sitio no especificado', category: 'Nefrourología' },
  { code: 'N30.0', name: 'Cistitis aguda', category: 'Nefrourología' },
  { code: 'N20.0', name: 'Cálculo del riñón (Nefrolitiasis)', category: 'Nefrourología' },
  { code: 'N40', name: 'Hiperplasia de la próstata', category: 'Nefrourología' },
  { code: 'N18.9', name: 'Enfermedad renal crónica, no especificada', category: 'Nefrourología' },

  // Neurológico y Psiquiatría
  { code: 'G43.9', name: 'Migraña, no especificada', category: 'Neurología' },
  { code: 'G44.2', name: 'Cefalea debida a tensión', category: 'Neurología' },
  { code: 'F41.1', name: 'Trastorno de ansiedad generalizada', category: 'Salud Mental' },
  { code: 'F32.9', name: 'Episodio depresivo, no especificado', category: 'Salud Mental' },
  { code: 'F51.0', name: 'Insomnio no orgánico', category: 'Salud Mental' },

  // Dermatología
  { code: 'L20.9', name: 'Dermatitis atópica, no especificada', category: 'Dermatología' },
  { code: 'L70.0', name: 'Acné común', category: 'Dermatología' },
  { code: 'L50.9', name: 'Urticaria, no especificada', category: 'Dermatología' },
  { code: 'B35.9', name: 'Dermatofitosis, no especificada (Micosis)', category: 'Dermatología' },

  // Medicina General y Síntomas
  { code: 'R50.9', name: 'Fiebre, no especificada', category: 'Síntomas y Signos' },
  { code: 'R51', name: 'Cefalea', category: 'Síntomas y Signos' },
  { code: 'R53', name: 'Malestar general y fatiga / Astenia', category: 'Síntomas y Signos' },
  { code: 'R10.4', name: 'Dolor abdominal, no especificado', category: 'Síntomas y Signos' },
  { code: 'Z00.0', name: 'Examen médico general de rutina (Control preventivo)', category: 'Control de Salud' }
];

export function searchCIE10(query: string): CIE10Item[] {
  if (!query || query.trim().length === 0) return CIE10_DATABASE.slice(0, 15);
  const clean = query.toLowerCase().trim();
  return CIE10_DATABASE.filter(
    item =>
      item.code.toLowerCase().includes(clean) ||
      item.name.toLowerCase().includes(clean) ||
      item.category.toLowerCase().includes(clean)
  ).slice(0, 20);
}
