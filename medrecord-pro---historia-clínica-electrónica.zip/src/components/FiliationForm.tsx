import React, { useState } from 'react';
import { 
  Save, 
  User, 
  Calendar, 
  Phone, 
  Mail, 
  MapPin, 
  ShieldAlert, 
  Heart, 
  Activity, 
  Plus, 
  Trash2, 
  Check, 
  FileText, 
  Shield, 
  AlertCircle 
} from 'lucide-react';
import { PatientFiliation, BloodType, Gender, CivilStatus, DocumentType, AllergyItem } from '../types/medical';
import { calculateAge } from '../utils/medicalCalculators';

interface FiliationFormProps {
  initialFiliation: PatientFiliation;
  onSave: (updatedFiliation: PatientFiliation) => void;
}

export const FiliationForm: React.FC<FiliationFormProps> = ({
  initialFiliation,
  onSave
}) => {
  const [formData, setFormData] = useState<PatientFiliation>({ ...initialFiliation });
  const [saveSuccess, setSaveSuccess] = useState(false);

  // New allergy state for inline adding
  const [newAllergen, setNewAllergen] = useState('');
  const [newAllergyCategory, setNewAllergyCategory] = useState<AllergyItem['category']>('Medicamento');
  const [newAllergySeverity, setNewAllergySeverity] = useState<AllergyItem['severity']>('Severa / Anafilaxia');
  const [newAllergyReaction, setNewAllergyReaction] = useState('');

  const currentAge = calculateAge(formData.birthDate);

  const handleTextChange = (field: keyof PatientFiliation, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleHereditaryChange = (key: keyof PatientFiliation['hereditary'], val: any) => {
    setFormData(prev => ({
      ...prev,
      hereditary: {
        ...prev.hereditary,
        [key]: val
      }
    }));
  };

  const handlePathologicalChange = (key: keyof PatientFiliation['pathological'], val: string) => {
    setFormData(prev => ({
      ...prev,
      pathological: {
        ...prev.pathological,
        [key]: val
      }
    }));
  };

  const handleNonPathologicalChange = (key: keyof PatientFiliation['nonPathological'], val: any) => {
    setFormData(prev => ({
      ...prev,
      nonPathological: {
        ...prev.nonPathological,
        [key]: val
      }
    }));
  };

  const handleSurgicalChange = (key: keyof PatientFiliation['surgical'], val: any) => {
    setFormData(prev => ({
      ...prev,
      surgical: {
        ...prev.surgical,
        [key]: val
      }
    }));
  };

  const handleGynecologicalChange = (key: string, val: any) => {
    setFormData(prev => ({
      ...prev,
      gynecological: {
        ...(prev.gynecological || {}),
        [key]: val
      }
    }));
  };

  const handleHabitsChange = (key: keyof PatientFiliation['habits'], val: any) => {
    setFormData(prev => ({
      ...prev,
      habits: {
        ...prev.habits,
        [key]: val
      }
    }));
  };

  const addAllergy = () => {
    if (!newAllergen.trim()) return;
    const newItem: AllergyItem = {
      id: `alg-${Date.now()}`,
      allergen: newAllergen.trim(),
      category: newAllergyCategory,
      severity: newAllergySeverity,
      reaction: newAllergyReaction.trim() || undefined
    };
    setFormData(prev => ({
      ...prev,
      allergies: [...(prev.allergies || []), newItem]
    }));
    setNewAllergen('');
    setNewAllergyReaction('');
  };

  const removeAllergy = (id: string) => {
    setFormData(prev => ({
      ...prev,
      allergies: prev.allergies.filter(a => a.id !== id)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Banner Notice */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-start justify-between">
        <div className="flex items-start space-x-3">
          <FileText className="w-5 h-5 text-blue-600 mt-0.5 shrink-0" />
          <div>
            <h3 className="text-sm font-bold text-blue-900">Ficha de Identificación y Filiación Única</h3>
            <p className="text-xs text-blue-700 mt-0.5">
              Esta información se registra una sola vez en el ingreso del paciente y queda fijada como base clínica de todas las consultas futuras. Puede editarse en cualquier momento si los datos cambian.
            </p>
          </div>
        </div>

        <button
          type="submit"
          className="flex items-center space-x-1.5 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs sm:text-sm rounded-lg shadow-xs transition shrink-0"
        >
          {saveSuccess ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          <span>{saveSuccess ? 'Guardado' : 'Guardar Ficha'}</span>
        </button>
      </div>

      {/* SECTION 1: DATOS PERSONALES Y DOCUMENTACIÓN */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6">
        <div className="flex items-center space-x-2 border-b border-slate-100 pb-3 mb-5">
          <User className="w-5 h-5 text-teal-600" />
          <h2 className="text-base font-bold text-slate-900">1. Datos Personales y de Identificación</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          
          {/* Nombre Completo */}
          <div className="lg:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nombre Completo del Paciente <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={formData.fullName}
              onChange={e => handleTextChange('fullName', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              placeholder="Nombres y Apellidos"
            />
          </div>

          {/* Fecha de Nacimiento y Edad Calculada */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Fecha de Nacimiento <span className="text-rose-500">*</span>
            </label>
            <div className="flex items-center space-x-2">
              <input
                type="date"
                required
                value={formData.birthDate}
                onChange={e => handleTextChange('birthDate', e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              />
            </div>
            <div className="mt-1 flex items-center justify-between text-[11px]">
              <span className="text-slate-500">Edad calculada:</span>
              <span className="font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                {currentAge.text}
              </span>
            </div>
          </div>

          {/* Sexo */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Sexo Biológico <span className="text-rose-500">*</span>
            </label>
            <select
              value={formData.gender}
              onChange={e => handleTextChange('gender', e.target.value as Gender)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none bg-white"
            >
              <option value="Masculino">Masculino</option>
              <option value="Femenino">Femenino</option>
              <option value="Otro">Otro / Intersexual</option>
            </select>
          </div>

          {/* Estado Civil */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Estado Civil
            </label>
            <select
              value={formData.civilStatus}
              onChange={e => handleTextChange('civilStatus', e.target.value as CivilStatus)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none bg-white"
            >
              <option value="Soltero/a">Soltero/a</option>
              <option value="Casado/a">Casado/a</option>
              <option value="Unión libre">Unión libre / Conviviente</option>
              <option value="Divorciado/a">Divorciado/a</option>
              <option value="Viudo/a">Viudo/a</option>
            </select>
          </div>

          {/* Ocupación */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Ocupación Actual
            </label>
            <input
              type="text"
              value={formData.occupation}
              onChange={e => handleTextChange('occupation', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              placeholder="ej. Docente, Empleado administrativo"
            />
          </div>

          {/* Escolaridad */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Escolaridad / Nivel Educativo
            </label>
            <select
              value={formData.educationLevel}
              onChange={e => handleTextChange('educationLevel', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none bg-white"
            >
              <option value="Primaria">Primaria</option>
              <option value="Secundaria">Secundaria</option>
              <option value="Técnico">Técnico / Terciario</option>
              <option value="Universitario">Universitario</option>
              <option value="Posgrado">Posgrado / Maestría / Doctorado</option>
              <option value="Ninguno">Sin instrucción formal</option>
            </select>
          </div>

          {/* Tipo de Documento */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Tipo de Documento <span className="text-rose-500">*</span>
            </label>
            <select
              value={formData.documentType}
              onChange={e => handleTextChange('documentType', e.target.value as DocumentType)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none bg-white"
            >
              <option value="DNI">DNI</option>
              <option value="Cédula de Identidad">Cédula de Identidad</option>
              <option value="Pasaporte">Pasaporte</option>
              <option value="Cédula de Extranjería">Cédula de Extranjería</option>
              <option value="CURP">CURP / RFC</option>
              <option value="Otro">Otro</option>
            </select>
          </div>

          {/* Número de Documento */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Número de Documento <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={formData.documentNumber}
              onChange={e => handleTextChange('documentNumber', e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              placeholder="Número de identidad"
            />
          </div>

          {/* Grupo Sanguíneo y Factor Rh */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Grupo Sanguíneo y Factor Rh <span className="text-rose-500">*</span>
            </label>
            <select
              value={formData.bloodType}
              onChange={e => handleTextChange('bloodType', e.target.value as BloodType)}
              className="w-full px-3 py-2 text-sm font-bold text-rose-800 bg-rose-50 border border-rose-200 rounded-lg focus:ring-2 focus:ring-rose-500 focus:outline-none"
            >
              <option value="O+">O Positivo (O+)</option>
              <option value="O-">O Negativo (O-)</option>
              <option value="A+">A Positivo (A+)</option>
              <option value="A-">A Negativo (A-)</option>
              <option value="B+">B Positivo (B+)</option>
              <option value="B-">B Negativo (B-)</option>
              <option value="AB+">AB Positivo (AB+)</option>
              <option value="AB-">AB Negativo (AB-)</option>
            </select>
          </div>

          {/* Donante de Órganos */}
          <div className="flex items-center space-x-3 pt-6">
            <input
              type="checkbox"
              id="organDonor"
              checked={formData.organDonor}
              onChange={e => handleTextChange('organDonor', e.target.checked)}
              className="w-4 h-4 text-teal-600 rounded border-slate-300 focus:ring-teal-500"
            />
            <label htmlFor="organDonor" className="text-xs font-semibold text-slate-800 cursor-pointer">
              Donante expreso de órganos y tejidos
            </label>
          </div>

        </div>
      </div>

      {/* SECTION 2: CONTACTO, DOMICILIO Y SEGURO */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6">
        <div className="flex items-center space-x-2 border-b border-slate-100 pb-3 mb-5">
          <MapPin className="w-5 h-5 text-blue-600" />
          <h2 className="text-base font-bold text-slate-900">2. Contacto, Residencia y Aseguramiento</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          
          <div className="lg:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 mb-1">Dirección Completa</label>
            <input
              type="text"
              value={formData.address}
              onChange={e => handleTextChange('address', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              placeholder="Calle, número, piso/departamento, barrio"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Ciudad / Localidad</label>
            <input
              type="text"
              value={formData.city}
              onChange={e => handleTextChange('city', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Provincia / Estado</label>
            <input
              type="text"
              value={formData.stateProvince}
              onChange={e => handleTextChange('stateProvince', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Teléfono Móvil (Celular / WhatsApp)</label>
            <input
              type="tel"
              value={formData.mobile}
              onChange={e => handleTextChange('mobile', e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              placeholder="+54 9 11 ..."
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Correo Electrónico</label>
            <input
              type="email"
              value={formData.email}
              onChange={e => handleTextChange('email', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              placeholder="paciente@correo.com"
            />
          </div>

          {/* Contacto de Emergencia Subcard */}
          <div className="lg:col-span-3 bg-amber-50/70 border border-amber-200 rounded-xl p-4 mt-2">
            <h4 className="text-xs font-bold text-amber-900 mb-3 flex items-center space-x-1.5">
              <Phone className="w-4 h-4 text-amber-600" />
              <span>Contacto de Emergencia Familiar</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-amber-900 mb-1">Nombre Completo</label>
                <input
                  type="text"
                  value={formData.emergencyContactName}
                  onChange={e => handleTextChange('emergencyContactName', e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-amber-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-amber-900 mb-1">Parentesco</label>
                <input
                  type="text"
                  value={formData.emergencyContactRelation}
                  onChange={e => handleTextChange('emergencyContactRelation', e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-amber-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  placeholder="ej. Esposa, Madre, Hermano"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-amber-900 mb-1">Teléfono Directo</label>
                <input
                  type="tel"
                  value={formData.emergencyContactPhone}
                  onChange={e => handleTextChange('emergencyContactPhone', e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs font-mono bg-white border border-amber-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Seguro / Cobertura Médica */}
          <div className="lg:col-span-3 bg-slate-50 border border-slate-200 rounded-xl p-4 mt-2">
            <h4 className="text-xs font-bold text-slate-800 mb-3 flex items-center space-x-1.5">
              <Shield className="w-4 h-4 text-teal-600" />
              <span>Cobertura de Salud & Responsable de Pago</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">Tipo de Cobertura</label>
                <select
                  value={formData.insuranceType}
                  onChange={e => handleTextChange('insuranceType', e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                >
                  <option value="Obra Social / Seguro Privado">Obra Social / Prepaga / Seguro</option>
                  <option value="Pública / Sin cobertura">Pública / Estatal</option>
                  <option value="Particular">Particular / Privado</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">Aseguradora / Entidad</label>
                <input
                  type="text"
                  value={formData.insuranceName}
                  onChange={e => handleTextChange('insuranceName', e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  placeholder="ej. OSDE, Swiss Medical, Sanitas"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">N° de Afiliado / Póliza</label>
                <input
                  type="text"
                  value={formData.policyNumber}
                  onChange={e => handleTextChange('policyNumber', e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs font-mono bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">Titular / Responsable</label>
                <input
                  type="text"
                  value={formData.payerResponsible}
                  onChange={e => handleTextChange('payerResponsible', e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  placeholder="Titular directo"
                />
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* SECTION 3: ALERGIAS CRÍTICAS */}
      <div className="bg-rose-50/50 rounded-xl border border-rose-200 shadow-2xs p-5 sm:p-6">
        <div className="flex items-center justify-between border-b border-rose-200 pb-3 mb-4">
          <div className="flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-rose-600" />
            <h2 className="text-base font-bold text-rose-950">3. Alergias Críticas Registradas</h2>
          </div>
          <span className="text-xs text-rose-700 font-semibold bg-rose-100 px-2 py-0.5 rounded-full border border-rose-300">
            {formData.allergies?.length || 0} alergias activas
          </span>
        </div>

        {/* Existing allergies badges */}
        <div className="space-y-2 mb-4">
          {formData.allergies && formData.allergies.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {formData.allergies.map(alg => (
                <div key={alg.id} className="flex items-center justify-between p-2.5 bg-white border border-rose-200 rounded-lg shadow-2xs">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-sm text-rose-900">{alg.allergen}</span>
                      <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-rose-100 text-rose-800">
                        {alg.severity}
                      </span>
                      <span className="text-xs text-slate-500">({alg.category})</span>
                    </div>
                    {alg.reaction && (
                      <p className="text-xs text-slate-600 mt-0.5 italic">Reacción: {alg.reaction}</p>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => removeAllergy(alg.id)}
                    className="text-slate-400 hover:text-rose-600 p-1 rounded transition"
                    title="Eliminar alergia"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-500 italic bg-white p-3 rounded-lg border border-dashed border-rose-200">
              No hay alergias registradas para este paciente. (Si no presenta, dejar en blanco).
            </p>
          )}
        </div>

        {/* Add new allergy sub-box */}
        <div className="bg-white p-3 rounded-xl border border-rose-200">
          <div className="text-xs font-bold text-slate-700 mb-2">Agregar Nueva Alergia:</div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
            <input
              type="text"
              placeholder="Alérgeno (ej. Penicilina, Látex, Mariscos)"
              value={newAllergen}
              onChange={e => setNewAllergen(e.target.value)}
              className="px-2.5 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-rose-500 focus:outline-none"
            />
            <select
              value={newAllergyCategory}
              onChange={e => setNewAllergyCategory(e.target.value as any)}
              className="px-2.5 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-rose-500 focus:outline-none bg-white"
            >
              <option value="Medicamento">Medicamento</option>
              <option value="Alimento">Alimento</option>
              <option value="Ambiental">Ambiental</option>
              <option value="Látex">Látex</option>
              <option value="Otro">Otro</option>
            </select>
            <select
              value={newAllergySeverity}
              onChange={e => setNewAllergySeverity(e.target.value as any)}
              className="px-2.5 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-rose-500 focus:outline-none bg-white"
            >
              <option value="Leve">Leve</option>
              <option value="Moderada">Moderada</option>
              <option value="Severa / Anafilaxia">Severa / Anafilaxia</option>
            </select>
            <button
              type="button"
              onClick={addAllergy}
              className="flex items-center justify-center space-x-1 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Registrar Alergia</span>
            </button>
          </div>
          <input
            type="text"
            placeholder="Reacción observada (opcional, ej. Edema de glotis, urticaria aguda)"
            value={newAllergyReaction}
            onChange={e => setNewAllergyReaction(e.target.value)}
            className="w-full mt-2 px-2.5 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-rose-500 focus:outline-none"
          />
        </div>
      </div>

      {/* SECTION 4: ANTECEDENTES HEREDOFAMILIARES */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6">
        <div className="flex items-center space-x-2 border-b border-slate-100 pb-3 mb-4">
          <Heart className="w-5 h-5 text-rose-500" />
          <h2 className="text-base font-bold text-slate-900">4. Antecedentes Heredofamiliares</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Diabetes */}
          <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-800 flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.hereditary.diabetes}
                  onChange={e => handleHereditaryChange('diabetes', e.target.checked)}
                  className="rounded text-teal-600"
                />
                <span>Diabetes Mellitus (DM)</span>
              </label>
            </div>
            {formData.hereditary.diabetes && (
              <input
                type="text"
                placeholder="Parentesco y detalles (ej. Padre finado a los 70)"
                value={formData.hereditary.diabetesDetail || ''}
                onChange={e => handleHereditaryChange('diabetesDetail', e.target.value)}
                className="w-full mt-1 px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-white"
              />
            )}
          </div>

          {/* HTA */}
          <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-800 flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.hereditary.hypertension}
                  onChange={e => handleHereditaryChange('hypertension', e.target.checked)}
                  className="rounded text-teal-600"
                />
                <span>Hipertensión Arterial (HTA)</span>
              </label>
            </div>
            {formData.hereditary.hypertension && (
              <input
                type="text"
                placeholder="Parentesco y detalles (ej. Madre hipertensa)"
                value={formData.hereditary.hypertensionDetail || ''}
                onChange={e => handleHereditaryChange('hypertensionDetail', e.target.value)}
                className="w-full mt-1 px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-white"
              />
            )}
          </div>

          {/* Cardiopatías */}
          <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-800 flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.hereditary.cardiopathy}
                  onChange={e => handleHereditaryChange('cardiopathy', e.target.checked)}
                  className="rounded text-teal-600"
                />
                <span>Cardiopatías / Infarto Precoz</span>
              </label>
            </div>
            {formData.hereditary.cardiopathy && (
              <input
                type="text"
                placeholder="Parentesco y detalles (ej. Hermano con IAM a los 55)"
                value={formData.hereditary.cardiopathyDetail || ''}
                onChange={e => handleHereditaryChange('cardiopathyDetail', e.target.value)}
                className="w-full mt-1 px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-white"
              />
            )}
          </div>

          {/* Neoplasias / Cáncer */}
          <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-800 flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.hereditary.cancer}
                  onChange={e => handleHereditaryChange('cancer', e.target.checked)}
                  className="rounded text-teal-600"
                />
                <span>Neoplasias / Cáncer</span>
              </label>
            </div>
            {formData.hereditary.cancer && (
              <input
                type="text"
                placeholder="Tipo de tumor y parentesco (ej. Abuela materna cáncer de colon)"
                value={formData.hereditary.cancerDetail || ''}
                onChange={e => handleHereditaryChange('cancerDetail', e.target.value)}
                className="w-full mt-1 px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-white"
              />
            )}
          </div>

        </div>

        {/* Otros hereditarios */}
        <div className="mt-3">
          <label className="block text-xs font-semibold text-slate-700 mb-1">Otros Antecedentes Familiares (Nefropatías, ECV, Tiroides, etc.)</label>
          <input
            type="text"
            value={formData.hereditary.others || ''}
            onChange={e => handleHereditaryChange('others', e.target.value)}
            className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
            placeholder="Especificar cualquier otra carga genética relevante"
          />
        </div>
      </div>

      {/* SECTION 5: ANTECEDENTES PERSONALES PATOLÓGICOS, QUIRÚRGICOS Y NO PATOLÓGICOS */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6 space-y-4">
        <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
          <Activity className="w-5 h-5 text-indigo-600" />
          <h2 className="text-base font-bold text-slate-900">5. Antecedentes Personales (Patológicos, Quirúrgicos y No Patológicos)</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Enfermedades Crónicas Actuales
            </label>
            <textarea
              rows={2}
              value={formData.pathological.chronicDiseases}
              onChange={e => handlePathologicalChange('chronicDiseases', e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              placeholder="ej. HTA desde hace 5 años, Asma intermitente, Gastritis crónica..."
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Medicación Habitual Continua
            </label>
            <textarea
              rows={2}
              value={formData.pathological.currentMedications}
              onChange={e => handlePathologicalChange('currentMedications', e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              placeholder="ej. Losartán 50mg/12h, Metformina 850mg con cena..."
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Cirugías Previas (Procedimiento y Año)
            </label>
            <textarea
              rows={2}
              value={formData.surgical.surgeries}
              onChange={e => handleSurgicalChange('surgeries', e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              placeholder="ej. Apendicectomía en 2015 sin complicaciones..."
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Traumatismos, Fracturas e Internaciones Previas
            </label>
            <textarea
              rows={2}
              value={formData.surgical.traumaFractures}
              onChange={e => handleSurgicalChange('traumaFractures', e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              placeholder="ej. Fractura de tibia a los 20 años..."
            />
          </div>
        </div>

        {/* Transfusiones e Inmunizaciones */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              id="transfusions"
              checked={formData.surgical.transfusions}
              onChange={e => handleSurgicalChange('transfusions', e.target.checked)}
              className="w-4 h-4 text-teal-600 rounded"
            />
            <label htmlFor="transfusions" className="text-xs font-semibold text-slate-800">
              ¿Ha recibido transfusiones sanguíneas previas?
            </label>
          </div>

          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              id="immuno"
              checked={formData.nonPathological.immunizationsComplete}
              onChange={e => handleNonPathologicalChange('immunizationsComplete', e.target.checked)}
              className="w-4 h-4 text-teal-600 rounded"
            />
            <label htmlFor="immuno" className="text-xs font-semibold text-slate-800">
              Esquema de vacunación e inmunizaciones al día
            </label>
          </div>
        </div>
      </div>

      {/* SECTION 6: ANTECEDENTES GINECO-OBSTÉTRICOS (Condicional) */}
      {(formData.gender === 'Femenino' || formData.gynecological) && (
        <div className="bg-pink-50/50 rounded-xl border border-pink-200 shadow-2xs p-5 sm:p-6">
          <div className="flex items-center space-x-2 border-b border-pink-200 pb-3 mb-4">
            <Heart className="w-5 h-5 text-pink-600" />
            <h2 className="text-base font-bold text-pink-950">6. Antecedentes Gineco-Obstétricos (GO)</h2>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-pink-900 mb-1">Edad Menarca</label>
              <input
                type="number"
                value={formData.gynecological?.menarcheAge || ''}
                onChange={e => handleGynecologicalChange('menarcheAge', parseInt(e.target.value) || 0)}
                className="w-full px-2 py-1.5 text-xs bg-white border border-pink-300 rounded"
                placeholder="Años"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-pink-900 mb-1">FUM (Últ. Menstruación)</label>
              <input
                type="date"
                value={formData.gynecological?.lastMenstrualPeriod || ''}
                onChange={e => handleGynecologicalChange('lastMenstrualPeriod', e.target.value)}
                className="w-full px-2 py-1.5 text-xs bg-white border border-pink-300 rounded"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-pink-900 mb-1">Gestas (G)</label>
              <input
                type="number"
                value={formData.gynecological?.pregnancies ?? ''}
                onChange={e => handleGynecologicalChange('pregnancies', parseInt(e.target.value) || 0)}
                className="w-full px-2 py-1.5 text-xs bg-white border border-pink-300 rounded"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-pink-900 mb-1">Partos (P)</label>
              <input
                type="number"
                value={formData.gynecological?.births ?? ''}
                onChange={e => handleGynecologicalChange('births', parseInt(e.target.value) || 0)}
                className="w-full px-2 py-1.5 text-xs bg-white border border-pink-300 rounded"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-pink-900 mb-1">Cesáreas (C)</label>
              <input
                type="number"
                value={formData.gynecological?.cesareans ?? ''}
                onChange={e => handleGynecologicalChange('cesareans', parseInt(e.target.value) || 0)}
                className="w-full px-2 py-1.5 text-xs bg-white border border-pink-300 rounded"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-pink-900 mb-1">Abortos (A)</label>
              <input
                type="number"
                value={formData.gynecological?.abortions ?? ''}
                onChange={e => handleGynecologicalChange('abortions', parseInt(e.target.value) || 0)}
                className="w-full px-2 py-1.5 text-xs bg-white border border-pink-300 rounded"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3">
            <div>
              <label className="block text-[11px] font-semibold text-pink-900 mb-1">Método Anticonceptivo Actual</label>
              <input
                type="text"
                value={formData.gynecological?.contraceptiveMethod || ''}
                onChange={e => handleGynecologicalChange('contraceptiveMethod', e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs bg-white border border-pink-300 rounded"
                placeholder="ej. DIU cobre, ACO combinados, Preservativo"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-pink-900 mb-1">Último PAP (Fecha y resultado)</label>
              <input
                type="text"
                value={formData.gynecological?.lastPapSmearDate || ''}
                onChange={e => handleGynecologicalChange('lastPapSmearDate', e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs bg-white border border-pink-300 rounded"
                placeholder="ej. Septiembre 2025 (Normal)"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-pink-900 mb-1">Última Mamografía</label>
              <input
                type="text"
                value={formData.gynecological?.lastMammogramDate || ''}
                onChange={e => handleGynecologicalChange('lastMammogramDate', e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs bg-white border border-pink-300 rounded"
                placeholder="Fecha o BIRADS si aplica"
              />
            </div>
          </div>
        </div>
      )}

      {/* SECTION 7: HÁBITOS Y ESTILO DE VIDA */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6">
        <div className="flex items-center space-x-2 border-b border-slate-100 pb-3 mb-4">
          <Activity className="w-5 h-5 text-amber-600" />
          <h2 className="text-base font-bold text-slate-900">7. Hábitos y Estilo de Vida</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Tabaquismo */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Tabaquismo</label>
            <select
              value={formData.habits.smoking}
              onChange={e => handleHabitsChange('smoking', e.target.value as any)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 bg-white"
            >
              <option value="No fumador">No fumador</option>
              <option value="Fumador activo">Fumador activo</option>
              <option value="Ex-fumador">Ex-fumador</option>
            </select>
            {formData.habits.smoking !== 'No fumador' && (
              <input
                type="number"
                placeholder="Paquetes/año"
                value={formData.habits.smokingPacksPerYear || ''}
                onChange={e => handleHabitsChange('smokingPacksPerYear', parseFloat(e.target.value) || 0)}
                className="w-full mt-1.5 px-2 py-1 text-xs border border-slate-300 rounded"
              />
            )}
          </div>

          {/* Alcohol */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Consumo de Alcohol</label>
            <select
              value={formData.habits.alcoholConsumption}
              onChange={e => handleHabitsChange('alcoholConsumption', e.target.value as any)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 bg-white"
            >
              <option value="Nunca">Nunca / Abstemio</option>
              <option value="Ocasional / Social">Ocasional / Social</option>
              <option value="Frecuente / Moderado">Frecuente / Moderado</option>
              <option value="Alto">Alto / Problemático</option>
            </select>
          </div>

          {/* Actividad Física */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Actividad Física</label>
            <select
              value={formData.habits.physicalActivity}
              onChange={e => handleHabitsChange('physicalActivity', e.target.value as any)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 bg-white"
            >
              <option value="Sedentario">Sedentario</option>
              <option value="1-2 días/semana">1-2 días/semana</option>
              <option value="3-5 días/semana">3-5 días/semana</option>
              <option value="Atleta / Diario">Atleta / Diario</option>
            </select>
          </div>

          {/* Alimentación */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Alimentación y Dieta</label>
            <input
              type="text"
              value={formData.habits.dietQuality}
              onChange={e => handleHabitsChange('dietQuality', e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
              placeholder="ej. Equilibrada, alta ingesta de sodio..."
            />
          </div>

        </div>
      </div>

      {/* Floating Save Footer */}
      <div className="flex items-center justify-between p-4 bg-white rounded-xl border border-slate-200 shadow-md">
        <div className="text-xs text-slate-500">
          Última actualización de filiación guardada en base de datos clínica.
        </div>
        <button
          type="submit"
          className="flex items-center space-x-2 px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-sm rounded-lg shadow-sm transition"
        >
          {saveSuccess ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          <span>{saveSuccess ? '¡Ficha Guardada con Éxito!' : 'Guardar Datos de Filiación'}</span>
        </button>
      </div>

    </form>
  );
};
