import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Save, 
  Check, 
  Sparkles, 
  Plus, 
  Trash2, 
  ArrowDownCircle, 
  Calendar, 
  Activity, 
  Search, 
  Clock, 
  HelpCircle,
  Stethoscope,
  ChevronRight,
  Heart
} from 'lucide-react';
import { 
  SubsequentConsultation, 
  EvolutionMode, 
  VitalSigns, 
  CIE10Diagnosis, 
  PrescriptionItem,
  Patient
} from '../types/medical';
import { calculateBMI, evaluateBloodPressure } from '../utils/medicalCalculators';
import { searchCIE10, CIE10Item } from '../data/cie10Catalog';
import { CLINICAL_TEMPLATES, ClinicalTemplate } from '../data/clinicalTemplates';

interface SubsequentConsultationFormProps {
  patient: Patient;
  onSave: (consultation: SubsequentConsultation) => void;
  onViewHistory?: () => void;
}

export const SubsequentConsultationForm: React.FC<SubsequentConsultationFormProps> = ({
  patient,
  onSave,
  onViewHistory
}) => {
  const [mode, setMode] = useState<EvolutionMode>('soap');
  
  // SOAP state
  const [soapSubjective, setSoapSubjective] = useState('');
  const [soapObjective, setSoapObjective] = useState('');
  const [soapAssessment, setSoapAssessment] = useState('');
  const [soapPlan, setSoapPlan] = useState('');

  // Free evolution note state
  const [freeNote, setFreeNote] = useState('');

  // Previous vital signs reference for delta comparison
  const previousVitals = patient.subsequentConsultations.length > 0 
    ? patient.subsequentConsultations[patient.subsequentConsultations.length - 1].vitalSigns 
    : patient.firstConsultation?.vitalSigns;

  // Vital signs state
  const [vitals, setVitals] = useState<VitalSigns>({
    systolicBP: previousVitals ? previousVitals.systolicBP : 120,
    diastolicBP: previousVitals ? previousVitals.diastolicBP : 80,
    heartRate: previousVitals ? previousVitals.heartRate : 72,
    respiratoryRate: 16,
    temperature: 36.5,
    oxygenSaturation: 98,
    weightKg: previousVitals ? previousVitals.weightKg : 70,
    heightCm: previousVitals ? previousVitals.heightCm : 170,
    calculatedBMI: previousVitals ? previousVitals.calculatedBMI : 24.2,
    bmiCategory: previousVitals ? previousVitals.bmiCategory : 'Peso normal (Eutrófico)',
    capillaryBloodGlucose: undefined
  });

  // Diagnoses
  const [diagnoses, setDiagnoses] = useState<CIE10Diagnosis[]>([]);
  
  // Prescriptions
  const [treatmentPlan, setTreatmentPlan] = useState<PrescriptionItem[]>([]);
  const [generalIndications, setGeneralIndications] = useState('');
  const [nextAppointmentDate, setNextAppointmentDate] = useState('');
  const [doctorStamp, setDoctorStamp] = useState('Dra. Elena Santillán - MN 114.892');
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Template dropdown
  const [showTemplatesModal, setShowTemplatesModal] = useState(false);

  // CIE-10 search state
  const [cieSearch, setCieSearch] = useState('');
  const [cieResults, setCieResults] = useState<CIE10Item[]>([]);
  const [showCieDropdown, setShowCieDropdown] = useState(false);

  // New Rx item inputs
  const [newMedName, setNewMedName] = useState('');
  const [newMedPresentation, setNewMedPresentation] = useState('');
  const [newMedDosage, setNewMedDosage] = useState('');
  const [newMedRoute, setNewMedRoute] = useState<PrescriptionItem['route']>('Oral');
  const [newMedFreq, setNewMedFreq] = useState('');
  const [newMedDuration, setNewMedDuration] = useState('');

  // Live BMI calculation
  useEffect(() => {
    if (vitals.weightKg > 0 && vitals.heightCm > 0) {
      const { bmi, category } = calculateBMI(vitals.weightKg, vitals.heightCm);
      setVitals(prev => ({
        ...prev,
        calculatedBMI: bmi,
        bmiCategory: category
      }));
    }
  }, [vitals.weightKg, vitals.heightCm]);

  // CIE-10 search
  useEffect(() => {
    if (cieSearch.trim().length > 0) {
      setCieResults(searchCIE10(cieSearch));
      setShowCieDropdown(true);
    } else {
      setCieResults([]);
      setShowCieDropdown(false);
    }
  }, [cieSearch]);

  // Function to pull / drag previous diagnoses from earlier consultations
  const pullPreviousDiagnoses = () => {
    let prevList: CIE10Diagnosis[] = [];
    if (patient.subsequentConsultations.length > 0) {
      prevList = patient.subsequentConsultations[patient.subsequentConsultations.length - 1].diagnoses;
    } else if (patient.firstConsultation) {
      prevList = patient.firstConsultation.diagnoses;
    }

    if (prevList && prevList.length > 0) {
      setDiagnoses([...prevList]);
    }
  };

  // Function to pull previous prescription
  const pullPreviousPrescription = () => {
    let prevRx: PrescriptionItem[] = [];
    if (patient.subsequentConsultations.length > 0) {
      prevRx = patient.subsequentConsultations[patient.subsequentConsultations.length - 1].treatmentPlan;
    } else if (patient.firstConsultation) {
      prevRx = patient.firstConsultation.treatmentPlan;
    }

    if (prevRx && prevRx.length > 0) {
      setTreatmentPlan([...prevRx]);
    }
  };

  // Apply clinical template
  const applyTemplate = (template: ClinicalTemplate) => {
    if (template.soap) {
      setSoapSubjective(template.soap.s);
      setSoapObjective(template.soap.o);
      setSoapAssessment(template.soap.a);
      setSoapPlan(template.soap.p);
    }
    if (template.freeText) {
      setFreeNote(template.freeText);
    }
    if (template.recommendations) {
      setGeneralIndications(template.recommendations);
    }
    setShowTemplatesModal(false);
  };

  // Fast next appointment presets (+7d, +15d, +1m, +3m)
  const setNextDateOffset = (days: number) => {
    const d = new Date();
    d.setDate(d.getDate() + days);
    setNextAppointmentDate(d.toISOString().split('T')[0]);
  };

  const addCieDiagnosis = (item: CIE10Item) => {
    if (diagnoses.some(d => d.code === item.code)) return;
    const isFirst = diagnoses.length === 0;
    setDiagnoses(prev => [
      ...prev,
      {
        code: item.code,
        name: item.name,
        type: isFirst ? 'Principal' : 'Secundario',
        condition: 'Definitivo'
      }
    ]);
    setCieSearch('');
    setShowCieDropdown(false);
  };

  const removeCieDiagnosis = (code: string) => {
    setDiagnoses(prev => prev.filter(d => d.code !== code));
  };

  const addMedication = () => {
    if (!newMedName.trim()) return;
    const item: PrescriptionItem = {
      id: `rx-${Date.now()}`,
      medication: newMedName.trim(),
      presentation: newMedPresentation.trim() || 'Comprimidos',
      dosage: newMedDosage.trim() || '1 toma',
      route: newMedRoute,
      frequency: newMedFreq.trim() || 'Cada 24 horas',
      duration: newMedDuration.trim() || 'Continuo'
    };
    setTreatmentPlan(prev => [...prev, item]);
    setNewMedName('');
    setNewMedPresentation('');
    setNewMedDosage('');
    setNewMedFreq('');
    setNewMedDuration('');
  };

  const removeMedication = (id: string) => {
    setTreatmentPlan(prev => prev.filter(m => m.id !== id));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const payload: SubsequentConsultation = {
      id: `sub-${Date.now()}`,
      patientId: patient.id,
      date: new Date().toISOString(),
      doctorName: 'Dra. Elena Santillán',
      doctorSpecialty: 'Medicina Interna',
      doctorLicense: 'MN 114.892',
      mode,
      soap: mode === 'soap' ? {
        subjective: soapSubjective,
        objective: soapObjective,
        assessment: soapAssessment,
        plan: soapPlan
      } : undefined,
      freeEvolutionNote: mode === 'free' ? freeNote : undefined,
      vitalSigns: vitals,
      diagnoses,
      treatmentPlan,
      generalIndications,
      nextAppointmentDate: nextAppointmentDate || undefined,
      doctorSignatureStamp: doctorStamp
    };

    onSave(payload);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const weightDelta = previousVitals ? Math.round((vitals.weightKg - previousVitals.weightKg) * 10) / 10 : 0;
  const bpStatus = evaluateBloodPressure(vitals.systolicBP, vitals.diastolicBP);

  return (
    <form onSubmit={handleSave} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Controls: Mode Switcher & Quick Tools */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-2xs">
        
        {/* Mode Selector (SOAP vs Libre) */}
        <div>
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
            Modo de Registro de Consulta Subsecuente:
          </div>
          <div className="inline-flex rounded-xl bg-slate-100 p-1 border border-slate-200">
            <button
              type="button"
              onClick={() => setMode('soap')}
              className={`flex items-center space-x-1.5 px-4 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                mode === 'soap'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Modelo SOAP (S - O - A - P)</span>
            </button>
            <button
              type="button"
              onClick={() => setMode('free')}
              className={`flex items-center space-x-1.5 px-4 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                mode === 'free'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Evolución Libre (Texto Continuo)</span>
            </button>
          </div>
        </div>

        {/* Quick Acceleration Actions */}
        <div className="flex flex-wrap items-center gap-2">
          
          {/* Quick template button */}
          <button
            type="button"
            onClick={() => setShowTemplatesModal(true)}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 rounded-lg text-xs font-semibold transition"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>Plantillas Rápidas</span>
          </button>

          {/* Pull Diagnoses */}
          <button
            type="button"
            onClick={pullPreviousDiagnoses}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-semibold transition"
            title="Copiar diagnósticos de la última cita para no escribir de nuevo"
          >
            <ArrowDownCircle className="w-3.5 h-3.5" />
            <span>Arrastrar Diagnósticos Previos</span>
          </button>

          {/* Pull Prescriptions */}
          <button
            type="button"
            onClick={pullPreviousPrescription}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-semibold transition"
            title="Copiar medicación previa para ajuste"
          >
            <ArrowDownCircle className="w-3.5 h-3.5" />
            <span>Arrastrar Medicación Previa</span>
          </button>

          {/* Save Button */}
          <button
            type="submit"
            className="flex items-center space-x-1.5 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs sm:text-sm rounded-lg shadow-xs transition"
          >
            {saveSuccess ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
            <span>{saveSuccess ? 'Guardada' : 'Guardar Evolución'}</span>
          </button>
        </div>
      </div>

      {/* SIGNOS VITALES CON CÁLCULO DE IMC Y DELTA CON VISITA ANTERIOR */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
          <div className="flex items-center space-x-2">
            <Activity className="w-5 h-5 text-rose-600" />
            <h3 className="text-sm font-bold text-slate-900">Signos Vitales de la Visita Actual</h3>
          </div>
          {previousVitals && (
            <div className="text-xs text-slate-500 flex items-center space-x-2">
              <span>Peso anterior: <strong>{previousVitals.weightKg} kg</strong></span>
              <span className={`font-bold px-1.5 py-0.2 rounded text-[11px] ${
                weightDelta < 0 ? 'bg-emerald-100 text-emerald-800' : weightDelta > 0 ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-700'
              }`}>
                {weightDelta > 0 ? `+${weightDelta} kg` : `${weightDelta} kg`}
              </span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">TA Sistólica</label>
            <div className="relative">
              <input
                type="number"
                value={vitals.systolicBP || ''}
                onChange={e => setVitals(prev => ({ ...prev, systolicBP: parseInt(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono font-bold text-slate-800 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-slate-400">mmHg</span>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">TA Diastólica</label>
            <div className="relative">
              <input
                type="number"
                value={vitals.diastolicBP || ''}
                onChange={e => setVitals(prev => ({ ...prev, diastolicBP: parseInt(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono font-bold text-slate-800 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-slate-400">mmHg</span>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Frec. Cardíaca</label>
            <div className="relative">
              <input
                type="number"
                value={vitals.heartRate || ''}
                onChange={e => setVitals(prev => ({ ...prev, heartRate: parseInt(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-slate-400">lpm</span>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Frec. Respiratoria</label>
            <div className="relative">
              <input
                type="number"
                value={vitals.respiratoryRate || ''}
                onChange={e => setVitals(prev => ({ ...prev, respiratoryRate: parseInt(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-slate-400">rpm</span>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Temperatura</label>
            <div className="relative">
              <input
                type="number"
                step="0.1"
                value={vitals.temperature || ''}
                onChange={e => setVitals(prev => ({ ...prev, temperature: parseFloat(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-slate-400">°C</span>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Sat. Oxígeno</label>
            <div className="relative">
              <input
                type="number"
                value={vitals.oxygenSaturation || ''}
                onChange={e => setVitals(prev => ({ ...prev, oxygenSaturation: parseInt(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-slate-400">%</span>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-teal-800 mb-1">Peso Actual</label>
            <div className="relative">
              <input
                type="number"
                step="0.1"
                required
                value={vitals.weightKg || ''}
                onChange={e => setVitals(prev => ({ ...prev, weightKg: parseFloat(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono font-bold text-teal-900 bg-teal-50/50 border border-teal-300 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-teal-600 font-semibold">kg</span>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-teal-800 mb-1">Talla</label>
            <div className="relative">
              <input
                type="number"
                step="0.5"
                required
                value={vitals.heightCm || ''}
                onChange={e => setVitals(prev => ({ ...prev, heightCm: parseFloat(e.target.value) || 0 }))}
                className="w-full px-2.5 py-1.5 text-xs font-mono font-bold text-teal-900 bg-teal-50/50 border border-teal-300 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <span className="absolute right-2 top-2 text-[10px] text-teal-600 font-semibold">cm</span>
            </div>
          </div>

        </div>

        {/* Live calculated IMC badge bar */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-2 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
            <span className="text-slate-500">IMC Actual Calculado:</span>
            <span className="font-mono font-extrabold text-sm text-slate-900">
              {vitals.calculatedBMI} kg/m²
            </span>
            <span className={`px-2 py-0.5 rounded-full font-bold text-[11px] border ${
              vitals.calculatedBMI >= 30 
                ? 'bg-rose-50 text-rose-700 border-rose-200' 
                : vitals.calculatedBMI >= 25 
                ? 'bg-orange-50 text-orange-700 border-orange-200' 
                : 'bg-emerald-50 text-emerald-700 border-emerald-200'
            }`}>
              {vitals.bmiCategory}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-slate-500">Evaluación TA:</span>
            <span className={`px-2 py-0.5 rounded text-xs ${bpStatus.badgeClass}`}>
              {bpStatus.label} ({vitals.systolicBP}/{vitals.diastolicBP} mmHg)
            </span>
          </div>
        </div>
      </div>

      {/* EVOLUCIÓN: MODELO SOAP O EVOLUCIÓN LIBRE */}
      {mode === 'soap' ? (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6 space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
            <FileText className="w-5 h-5 text-purple-600" />
            <h3 className="text-sm font-bold text-slate-900">
              Evolución Clínica - Modelo SOAP (Subjetivo, Objetivo, Análisis, Plan)
            </h3>
          </div>

          <div className="space-y-4">
            
            {/* S: Subjetivo */}
            <div className="p-3.5 rounded-xl border border-blue-200 bg-blue-50/30">
              <label className="block text-xs font-bold text-blue-900 mb-1 flex items-center space-x-1.5">
                <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[11px] font-bold">S</span>
                <span>Subjetivo (Lo que refiere el paciente, síntomas, evolución, tolerancia al tratamiento)</span>
              </label>
              <textarea
                rows={3}
                required
                value={soapSubjective}
                onChange={e => setSoapSubjective(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-blue-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                placeholder="Paciente refiere sentirse asintomático / refiere dolor leve... adecuada adherencia farmacológica..."
              />
            </div>

            {/* O: Objetivo */}
            <div className="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/30">
              <label className="block text-xs font-bold text-emerald-900 mb-1 flex items-center space-x-1.5">
                <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[11px] font-bold">O</span>
                <span>Objetivo (Hallazgos físicos relevantes, examen clínico focalizado, resultados de nuevos estudios)</span>
              </label>
              <textarea
                rows={3}
                required
                value={soapObjective}
                onChange={e => setSoapObjective(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-emerald-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                placeholder="Buen estado general. Ruidos cardíacos rítmicos normofonéticos. Pulmones limpios. Sin edemas periféricos..."
              />
            </div>

            {/* A: Análisis */}
            <div className="p-3.5 rounded-xl border border-amber-200 bg-amber-50/30">
              <label className="block text-xs font-bold text-amber-900 mb-1 flex items-center space-x-1.5">
                <span className="w-5 h-5 rounded-full bg-amber-600 text-white flex items-center justify-center text-[11px] font-bold">A</span>
                <span>Análisis / Evaluación (Juicio clínico médico, control de la patología, mejoría, resolución)</span>
              </label>
              <textarea
                rows={2}
                required
                value={soapAssessment}
                onChange={e => setSoapAssessment(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-amber-200 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                placeholder="Hipertensión arterial esencial controlada en metas. Buen control glucémico..."
              />
            </div>

            {/* P: Plan */}
            <div className="p-3.5 rounded-xl border border-purple-200 bg-purple-50/30">
              <label className="block text-xs font-bold text-purple-900 mb-1 flex items-center space-x-1.5">
                <span className="w-5 h-5 rounded-full bg-purple-600 text-white flex items-center justify-center text-[11px] font-bold">P</span>
                <span>Plan (Conducta terapéutica, ajustes de dosis, nuevos estudios solicitados, pautas)</span>
              </label>
              <textarea
                rows={3}
                required
                value={soapPlan}
                onChange={e => setSoapPlan(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
                placeholder="1. Continuar esquema farmacológico habitual. 2. Control de laboratorio en 3 meses..."
              />
            </div>

          </div>
        </div>
      ) : (
        /* EVOLUCIÓN LIBRE */
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6 space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
            <Activity className="w-5 h-5 text-purple-600" />
            <h3 className="text-sm font-bold text-slate-900">
              Evolución Médica Libre (Nota Continua Tradicional)
            </h3>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nota de Evolución Médica <span className="text-rose-500">*</span>
            </label>
            <textarea
              rows={8}
              required
              value={freeNote}
              onChange={e => setFreeNote(e.target.value)}
              className="w-full px-3 py-2.5 text-xs sm:text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none font-sans"
              placeholder="Paciente masculino/femenino que acude a control subsecuente... Refiere adecuada evolución... Al examen físico:... Diagnósticos:... Conducta y plan:..."
            />
          </div>
        </div>
      )}

      {/* DIAGNÓSTICOS CIE-10 (Mantener, Arrastrar o Agregar Nuevos) */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900">Diagnósticos de la Visita (CIE-10)</h3>
          </div>
          <button
            type="button"
            onClick={pullPreviousDiagnoses}
            className="flex items-center space-x-1 text-xs text-indigo-700 font-semibold hover:underline"
          >
            <ArrowDownCircle className="w-3.5 h-3.5" />
            <span>Arrastrar de cita anterior</span>
          </button>
        </div>

        {/* Existing Diagnoses */}
        <div className="space-y-2">
          {diagnoses.length > 0 ? (
            diagnoses.map(diag => (
              <div key={diag.code} className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="flex items-center space-x-2">
                  <span className="font-mono font-bold text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded">
                    {diag.code}
                  </span>
                  <span className="text-xs sm:text-sm font-semibold text-slate-900">{diag.name}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs px-2 py-0.5 rounded bg-slate-200 text-slate-700 font-medium">
                    {diag.type}
                  </span>
                  <button
                    type="button"
                    onClick={() => removeCieDiagnosis(diag.code)}
                    className="p-1 text-slate-400 hover:text-rose-600 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="p-3 bg-slate-50 rounded-lg border border-dashed border-slate-200 text-center">
              <p className="text-xs text-slate-500 mb-2">No se han registrado diagnósticos para esta visita.</p>
              <button
                type="button"
                onClick={pullPreviousDiagnoses}
                className="px-3 py-1.5 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200 rounded-lg text-xs font-semibold"
              >
                Cargar diagnósticos de la consulta anterior
              </button>
            </div>
          )}
        </div>

        {/* Search CIE-10 */}
        <div className="relative">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={cieSearch}
              onChange={e => setCieSearch(e.target.value)}
              placeholder="Buscar y añadir otro diagnóstico CIE-10 (ej. I10, diabetes, artrosis)..."
              className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
            />
          </div>

          {showCieDropdown && cieResults.length > 0 && (
            <div className="absolute z-20 w-full mt-1 bg-white border border-slate-200 rounded-xl shadow-lg max-h-56 overflow-y-auto divide-y divide-slate-100">
              {cieResults.map(item => (
                <button
                  key={item.code}
                  type="button"
                  onClick={() => addCieDiagnosis(item)}
                  className="w-full text-left px-4 py-2 hover:bg-teal-50 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center space-x-2">
                    <span className="font-mono font-bold text-xs bg-slate-100 text-slate-800 px-1.5 py-0.5 rounded">
                      {item.code}
                    </span>
                    <span className="font-medium text-slate-900">{item.name}</span>
                  </div>
                  <span className="text-[10px] text-slate-400">{item.category}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* TRATAMIENTO, RECETA Y PRÓXIMA CITA */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2">
            <Heart className="w-5 h-5 text-emerald-600" />
            <h3 className="text-sm font-bold text-slate-900">Tratamiento Actualizado & Prescripciones</h3>
          </div>
          <button
            type="button"
            onClick={pullPreviousPrescription}
            className="text-xs text-emerald-800 font-semibold hover:underline flex items-center space-x-1"
          >
            <ArrowDownCircle className="w-3.5 h-3.5" />
            <span>Copiar receta anterior</span>
          </button>
        </div>

        {/* Existing Prescriptions */}
        <div className="space-y-2">
          {treatmentPlan.map((rx, idx) => (
            <div key={rx.id} className="flex items-center justify-between p-2.5 bg-emerald-50/50 border border-emerald-200 rounded-lg text-xs">
              <div className="flex items-center space-x-2">
                <span className="font-bold text-emerald-900">{idx + 1}. {rx.medication}</span>
                <span className="text-slate-600 font-mono">({rx.presentation})</span>
                <span className="text-slate-700">· {rx.dosage} · {rx.frequency} · {rx.duration}</span>
              </div>
              <button
                type="button"
                onClick={() => removeMedication(rx.id)}
                className="text-slate-400 hover:text-rose-600 p-1"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

        {/* Add Medication mini form */}
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
            <input
              type="text"
              placeholder="Fármaco (ej. Enalapril)"
              value={newMedName}
              onChange={e => setNewMedName(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg"
            />
            <input
              type="text"
              placeholder="Presentación (ej. Comp 10mg)"
              value={newMedPresentation}
              onChange={e => setNewMedPresentation(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg"
            />
            <input
              type="text"
              placeholder="Frecuencia (ej. c/12h)"
              value={newMedFreq}
              onChange={e => setNewMedFreq(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg"
            />
            <button
              type="button"
              onClick={addMedication}
              className="flex items-center justify-center space-x-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Añadir Fármaco</span>
            </button>
          </div>
        </div>

        {/* General indications */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Indicaciones y Recomendaciones Generales</label>
          <input
            type="text"
            value={generalIndications}
            onChange={e => setGeneralIndications(e.target.value)}
            className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500"
            placeholder="ej. Mantener dieta hiposódica, registro tensional 2 veces por semana..."
          />
        </div>

        {/* Próxima Cita con atajos rápidos */}
        <div className="pt-2 border-t border-slate-100">
          <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center space-x-1.5">
            <Calendar className="w-4 h-4 text-purple-600" />
            <span>Programar Próxima Cita de Control (Opcional)</span>
          </label>
          <div className="flex flex-wrap items-center gap-2">
            <input
              type="date"
              value={nextAppointmentDate}
              onChange={e => setNextAppointmentDate(e.target.value)}
              className="px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-purple-500"
            />
            <div className="flex items-center space-x-1 text-xs">
              <span className="text-slate-400 mr-1">Atajos:</span>
              <button
                type="button"
                onClick={() => setNextDateOffset(7)}
                className="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-medium"
              >
                +7 días
              </button>
              <button
                type="button"
                onClick={() => setNextDateOffset(15)}
                className="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-medium"
              >
                +15 días
              </button>
              <button
                type="button"
                onClick={() => setNextDateOffset(30)}
                className="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-medium"
              >
                +1 mes
              </button>
              <button
                type="button"
                onClick={() => setNextDateOffset(90)}
                className="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-medium"
              >
                +3 meses
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Save Footer */}
      <div className="flex items-center justify-between p-4 bg-white rounded-xl border border-slate-200 shadow-md">
        <div className="text-xs text-slate-500">
          Fecha y hora de registro: {new Date().toLocaleDateString('es-ES')} - Firma: {doctorStamp}
        </div>
        <button
          type="submit"
          className="flex items-center space-x-2 px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-sm rounded-lg shadow-sm transition"
        >
          {saveSuccess ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          <span>{saveSuccess ? '¡Evolución Registrada con Éxito!' : 'Registrar Evolución Médica'}</span>
        </button>
      </div>

      {/* QUICK TEMPLATES MODAL */}
      {showTemplatesModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2">
                <Sparkles className="w-5 h-5 text-amber-500" />
                <h3 className="text-base font-bold text-slate-900">Plantillas y Frases Clínicas Rápidas</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowTemplatesModal(false)}
                className="text-slate-400 hover:text-slate-700 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Haga clic en una plantilla para precargar automáticamente la estructura de la evolución médica y ahorrar tiempo en el consultorio:
            </p>

            <div className="space-y-2.5 max-h-96 overflow-y-auto">
              {CLINICAL_TEMPLATES.map(tpl => (
                <button
                  key={tpl.id}
                  type="button"
                  onClick={() => applyTemplate(tpl)}
                  className="w-full text-left p-3 rounded-xl border border-slate-200 hover:border-teal-500 hover:bg-teal-50/50 transition flex items-center justify-between group"
                >
                  <div>
                    <div className="font-bold text-sm text-slate-900 group-hover:text-teal-900">
                      {tpl.title}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Categoría: {tpl.category} · {tpl.soap ? 'Compatible con SOAP' : 'Texto libre'}
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-teal-600" />
                </button>
              ))}
            </div>

            <div className="pt-2 border-t border-slate-100 text-right">
              <button
                type="button"
                onClick={() => setShowTemplatesModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

    </form>
  );
};
