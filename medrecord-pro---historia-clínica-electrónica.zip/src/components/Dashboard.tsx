import React from 'react';
import { 
  Users, 
  Clock, 
  Calendar, 
  CheckCircle2, 
  AlertTriangle, 
  PlusCircle, 
  Search, 
  BookOpen, 
  ArrowRight, 
  Activity, 
  Heart, 
  Droplet,
  ShieldAlert,
  FileText
} from 'lucide-react';
import { Patient } from '../types/medical';
import { calculateAge } from '../utils/medicalCalculators';

interface DashboardProps {
  patients: Patient[];
  onSelectPatient: (patientId: string, initialTab?: any) => void;
  onOpenNewPatient: () => void;
  onOpenSearch: () => void;
  onOpenSpec: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  patients,
  onSelectPatient,
  onOpenNewPatient,
  onOpenSearch,
  onOpenSpec
}) => {
  const waitingPatients = patients.filter(p => p.status === 'En espera');
  const inConsultation = patients.filter(p => p.status === 'En consulta');
  const activeCount = patients.length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="flex items-center space-x-2 text-teal-400 text-xs font-bold uppercase tracking-widest mb-1.5">
            <Activity className="w-4 h-4" />
            <span>Consultorio Médico Activo · Dra. Elena Santillán</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Plataforma de Historia Clínica Electrónica (HCE)
          </h1>
          <p className="text-slate-300 text-xs sm:text-sm mt-2 leading-relaxed">
            Gestión clínica ultrarrápida diseñada exclusivamente para el flujo real de la consulta médica: mínimo número de clics, cálculo automático de IMC, modelo SOAP y evoluciones libres.
          </p>

          <div className="flex flex-wrap items-center gap-3 mt-5">
            <button
              onClick={onOpenNewPatient}
              className="flex items-center space-x-2 px-4 py-2.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs sm:text-sm rounded-xl transition shadow-md"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Nuevo Paciente</span>
            </button>

            <button
              onClick={onOpenSearch}
              className="flex items-center space-x-2 px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-medium text-xs sm:text-sm rounded-xl transition backdrop-blur-xs border border-white/10"
            >
              <Search className="w-4 h-4 text-teal-300" />
              <span>Buscar en Fichero Clínico</span>
            </button>

            <button
              onClick={onOpenSpec}
              className="flex items-center space-x-2 px-4 py-2.5 bg-indigo-600/90 hover:bg-indigo-600 text-white font-semibold text-xs sm:text-sm rounded-xl transition shadow-sm border border-indigo-400/30"
            >
              <BookOpen className="w-4 h-4" />
              <span>Ver Especificación Técnica & Arquitectura</span>
            </button>
          </div>
        </div>

        {/* Decorative background grid subtle */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10 pointer-events-none flex items-center justify-center">
          <Activity className="w-96 h-96 text-white" />
        </div>
      </div>

      {/* KPI METRICS ROW */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Pacientes en Fichero</span>
            <Users className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono">{activeCount}</div>
          <div className="text-[11px] text-teal-700 font-medium mt-1">100% historias digitalizadas</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Sala de Espera Hoy</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold text-amber-900 mt-2 font-mono">{waitingPatients.length}</div>
          <div className="text-[11px] text-amber-700 font-medium mt-1">Tiempo medio: 8 min</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Consultas Completadas</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-emerald-900 mt-2 font-mono">
            {patients.reduce((acc, p) => acc + (p.firstConsultation ? 1 : 0) + p.subsequentConsultations.length, 0)}
          </div>
          <div className="text-[11px] text-emerald-700 font-medium mt-1">Con recetas firmadas</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Alertas de Alergias</span>
            <ShieldAlert className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-bold text-rose-900 mt-2 font-mono">
            {patients.reduce((acc, p) => acc + p.filiation.allergies.length, 0)}
          </div>
          <div className="text-[11px] text-rose-700 font-medium mt-1">Protección activa en receta</div>
        </div>

      </div>

      {/* TODAY'S AGENDA & PATIENT ROSTER */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-teal-600" />
            <h2 className="text-base font-bold text-slate-900">Agenda Médica del Día & Fichero de Pacientes</h2>
          </div>
          <span className="text-xs text-slate-500">Haga clic en cualquier paciente para acceder a su Historia Clínica</span>
        </div>

        <div className="divide-y divide-slate-100">
          {patients.map(patient => {
            const age = calculateAge(patient.filiation.birthDate);
            const hasAllergies = patient.filiation.allergies.length > 0;
            const hasFirst = !!patient.firstConsultation;
            const subCount = patient.subsequentConsultations.length;

            return (
              <div
                key={patient.id}
                className="p-4 sm:p-5 hover:bg-slate-50/80 transition flex flex-col md:flex-row md:items-center justify-between gap-4 group"
              >
                
                {/* Left Patient Info */}
                <div className="flex items-start space-x-3.5">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 shadow-2xs ${
                    patient.filiation.gender === 'Femenino'
                      ? 'bg-rose-50 text-rose-600 border border-rose-200'
                      : 'bg-teal-50 text-teal-700 border border-teal-200'
                  }`}>
                    {patient.filiation.bloodType}
                  </div>

                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-bold text-slate-900 text-sm sm:text-base group-hover:text-teal-700 transition">
                        {patient.filiation.fullName}
                      </h3>
                      <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-semibold">
                        {patient.recordNumber}
                      </span>
                      <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                        patient.status === 'En espera'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {patient.status}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1 text-xs text-slate-500">
                      <span>{age.text} ({patient.filiation.gender})</span>
                      <span>•</span>
                      <span>{patient.filiation.documentType}: {patient.filiation.documentNumber}</span>
                      <span>•</span>
                      <span>{patient.filiation.insuranceName || 'Particular'}</span>
                    </div>

                    {/* Allergies tag banner */}
                    {hasAllergies && (
                      <div className="mt-1.5 flex items-center space-x-1.5 text-[11px] font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200 w-fit">
                        <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
                        <span>Alergias: {patient.filiation.allergies.map(a => a.allergen).join(', ')}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Right Action Buttons */}
                <div className="flex items-center space-x-2 shrink-0">
                  
                  {/* If no first consultation yet, highlight it */}
                  {!hasFirst ? (
                    <button
                      onClick={() => onSelectPatient(patient.id, 'first-consultation')}
                      className="flex items-center space-x-1.5 px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-xs transition"
                    >
                      <Activity className="w-3.5 h-3.5" />
                      <span>Registrar Primera Consulta</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => onSelectPatient(patient.id, 'subsequent')}
                      className="flex items-center space-x-1.5 px-3 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-bold shadow-xs transition"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>Nueva Evolución (SOAP)</span>
                    </button>
                  )}

                  <button
                    onClick={() => onSelectPatient(patient.id, 'filiation')}
                    className="flex items-center space-x-1 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition"
                  >
                    <span>Ficha Completa</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                </div>

              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
