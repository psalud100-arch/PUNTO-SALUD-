import { Patient } from '../types/medical';

export const INITIAL_PATIENTS: Patient[] = [
  {
    id: 'pat-001',
    recordNumber: 'HC-2026-0042',
    createdAt: '2026-01-15T09:30:00Z',
    updatedAt: '2026-04-10T11:20:00Z',
    status: 'Activo',
    filiation: {
      fullName: 'Carlos Alberto Méndez Rivera',
      birthDate: '1971-08-22',
      gender: 'Masculino',
      civilStatus: 'Casado/a',
      occupation: 'Ingeniero Civil / Contratista',
      educationLevel: 'Universitario',
      documentType: 'DNI',
      documentNumber: '32.845.910',
      address: 'Av. Libertador 4820, Piso 6 Depto B',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      phone: '+54 11 4782-9901',
      mobile: '+54 9 11 5821-3344',
      email: 'carlos.mendez@constructoramendez.com',
      emergencyContactName: 'Mariana López de Méndez',
      emergencyContactRelation: 'Esposa',
      emergencyContactPhone: '+54 9 11 5821-3345',
      insuranceType: 'Obra Social / Seguro Privado',
      insuranceName: 'OSDE 410',
      policyNumber: '410-884920-01',
      payerResponsible: 'Titular directo',
      bloodType: 'O+',
      organDonor: true,
      allergies: [
        {
          id: 'alg-01',
          allergen: 'Penicilina / Betalactámicos',
          category: 'Medicamento',
          severity: 'Severa / Anafilaxia',
          reaction: 'Edema de glotis y rash urticariforme generalizado en 2018'
        },
        {
          id: 'alg-02',
          allergen: 'Mariscos / Camarones',
          category: 'Alimento',
          severity: 'Moderada',
          reaction: 'Angioedema labial leve y prurito'
        }
      ],
      hereditary: {
        diabetes: true,
        diabetesDetail: 'Padre finado a los 72 años por complicaciones de DM2',
        hypertension: true,
        hypertensionDetail: 'Madre viva (78 años) hipertensa diagnosticada a los 50',
        cardiopathy: true,
        cardiopathyDetail: 'Hermano mayor con IAM a los 58 años con colocación de stent',
        cancer: false,
        nephropathy: false,
        stroke: false,
        others: 'Tía materna con hipotiroidismo primario'
      },
      pathological: {
        chronicDiseases: 'Hipertensión arterial esencial diagnosticada hace 5 años. Diabetes Mellitus tipo 2 diagnosticada hace 3 años en tratamiento.',
        infectiousDiseases: 'COVID-19 leve en 2022 sin secuelas pulmonares. Varicela en la infancia.',
        previousHospitalizations: 'Apendicectomía a los 24 años. Sin otras admisiones.',
        currentMedications: 'Losartán 50mg cada 12h, Metformina 850mg con cena, Ácido Acetilsalicílico 100mg/día.'
      },
      nonPathological: {
        immunizationsComplete: true,
        immunizationsDetail: 'Esquema completo de vacunación adulta. Refuerzo antigripal y COVID actualizados.',
        housingType: 'Urbana de mampostería, cuenta con todos los servicios sanitarios y agua potable.',
        petsZoonosis: 'Un perro caniche, desparasitado y vacunado.'
      },
      surgical: {
        surgeries: 'Apendicectomía laparoscópica en 1995 sin complicaciones anestésicas.',
        traumaFractures: 'Fractura cerrada de radio distal izquierdo a los 16 años por práctica deportiva.',
        transfusions: false
      },
      habits: {
        smoking: 'Ex-fumador',
        smokingPacksPerYear: 8,
        alcoholConsumption: 'Ocasional / Social',
        drugsRecreational: 'Niega consumo de sustancias ilícitas',
        physicalActivity: '1-2 días/semana',
        dietQuality: 'Dieta mediterránea moderada, tendencia a transgresiones en eventos sociales.'
      }
    },
    firstConsultation: {
      id: 'cons-first-001',
      patientId: 'pat-001',
      date: '2026-01-15T10:00:00Z',
      doctorName: 'Dra. Elena Santillán',
      doctorSpecialty: 'Medicina Interna / Cardiología Clínica',
      doctorLicense: 'MN 114.892 / MP 45.210',
      reasonForConsultation: 'Control integral de salud, fatiga vespertina y ajuste de esquema antihipertensivo.',
      presentIllnessHistory: 'Paciente masculino de 54 años con antecedentes de HTA y DM2 que consulta para chequeo clínico periódico. Refiere cefaleas occipitales pulsátiles esporádicas al final de la jornada laboral desde hace 3 semanas, asociadas a sensación de fatiga vespertina. Niega dolor precordial, disnea de esfuerzo o palpitaciones. Niega episodios sincopales. Trae mediciones domiciliarias de TA con valores oscilantes entre 145/92 y 155/98 mmHg.',
      systemsReview: {
        cardiovascular: { normal: false, notes: 'Cefalea occipital leve relacionada a registros tensionales elevados. Sin disnea ni dolor precordial.' },
        respiratory: { normal: true, notes: 'Sin tos, expectoración ni disnea.' },
        digestive: { normal: true, notes: 'Apetito conservado, ritmo evacuatorio regular sin pirosis.' },
        genitourinary: { normal: true, notes: 'Micción conservada, niega disuria o nicturia.' },
        nervous: { normal: true, notes: 'Sueño no reparador ocasional. Sin déficit motor ni sensitivo.' },
        musculoskeletal: { normal: true, notes: 'Sin artralgias ni limitaciones funcionales.' },
        endocrine: { normal: true, notes: 'Sin poliuria ni polidipsia manifiesta.' },
        integumentary: { normal: true, notes: 'Piel normocoloreada sin lesiones activas.' }
      },
      physicalExamination: {
        generalState: 'Paciente en buen estado general, lúcido, ubicado en tiempo y espacio. Facies no característica. Marcha normal.',
        headAndNeck: 'Normocéfalo. Faringe limpia. Cuello cilíndrico sin ingurgitación yugular a 45°. No se palpan adenopatías ni bocio tiroideo.',
        thoraxAndLungs: 'Tórax simétrico. Murmullo vesicular bien ventilado en ambos campos pulmonares sin ruidos agregados. Ruidos cardíacos rítmicos normofonéticos en 4 focos auscultatorios, R1 y R2 presentes, sin R3 ni R4, sin soplos.',
        abdomen: 'Globoso a expensas de panículo adiposo, blando, depresible, indoloro. Ruidos hidroaéreos conservados. Hígado a 1 cm bajo reborde costal, consistencia elástica borde romo.',
        extremities: 'Simétricas, sin edemas maleolares periféricos. Pulsos femorales, poplíteos y pedios bilaterales presentes de buena amplitud. Llenado capilar < 2 seg.',
        neurological: 'Sin signos meníngeos. Pares craneales conservados. Reflejos osteotendinosos simétricos ++/++++.'
      },
      vitalSigns: {
        systolicBP: 148,
        diastolicBP: 94,
        heartRate: 76,
        respiratoryRate: 16,
        temperature: 36.6,
        oxygenSaturation: 98,
        weightKg: 87.5,
        heightCm: 175,
        calculatedBMI: 28.6,
        bmiCategory: 'Sobrepeso (Pre-obesidad)',
        capillaryBloodGlucose: 128
      },
      priorStudies: 'Laboratorio de 3 meses atrás: Glucemia basal 124 mg/dL, HbA1c 6.9%, Colesterol total 215 mg/dL, LDL 135 mg/dL, Triglicéridos 180 mg/dL, Creatinina 0.98 mg/dL, Microalbuminuria negativa.',
      diagnoses: [
        { code: 'I10', name: 'Hipertensión esencial (primaria)', type: 'Principal', condition: 'Definitivo' },
        { code: 'E11.9', name: 'Diabetes mellitus tipo 2 sin mención de complicación', type: 'Secundario', condition: 'Definitivo' },
        { code: 'E78.2', name: 'Hiperlipidemia mixta', type: 'Secundario', condition: 'Definitivo' },
        { code: 'E66.0', name: 'Obesidad debida a exceso de calorías / Sobrepeso', type: 'Secundario', condition: 'Definitivo' }
      ],
      treatmentPlan: [
        {
          id: 'rx-01',
          medication: 'Losartán Potásico / Hidroclorotiazida',
          presentation: 'Comprimidos recubiertos 50mg / 12.5mg',
          dosage: '1 comprimido',
          route: 'Oral',
          frequency: 'Cada mañana en ayunas',
          duration: 'Tratamiento continuo x 90 días',
          indications: 'Tomar con un vaso de agua en horario fijo.'
        },
        {
          id: 'rx-02',
          medication: 'Metformina Clorhidrato de liberación prolongada (XR)',
          presentation: 'Comprimidos 850mg',
          dosage: '1 comprimido',
          route: 'Oral',
          frequency: 'Cada 24 horas junto con la cena',
          duration: 'Continuo x 90 días',
          indications: 'No partir ni masticar el comprimido.'
        },
        {
          id: 'rx-03',
          medication: 'Atorvastatina Cálcica',
          presentation: 'Comprimidos 20mg',
          dosage: '1 comprimido',
          route: 'Oral',
          frequency: 'Cada noche antes de dormir',
          duration: 'Continuo x 90 días',
          indications: 'Control de perfil lipídico.'
        }
      ],
      recommendations: 'Plan alimentario hiposódico estricto. Reducción de harinas refinadas y carbohidratos simples. Caminata a paso ligero 45 minutos al menos 4 veces por semana. Registro tensional diario durante 1 semana. Evitar consumo de AINEs por riesgo de elevación tensional e interacción.',
      prognosis: 'Favorable',
      doctorSignatureStamp: 'Dra. Elena Santillán - Matrícula Nacional 114.892 - Especialista en Medicina Interna'
    },
    subsequentConsultations: [
      {
        id: 'sub-001',
        patientId: 'pat-001',
        date: '2026-02-20T10:30:00Z',
        doctorName: 'Dra. Elena Santillán',
        doctorSpecialty: 'Medicina Interna',
        doctorLicense: 'MN 114.892',
        mode: 'soap',
        soap: {
          subjective: 'Paciente acude a control al mes de optimizar tratamiento antihipertensivo. Refiere desaparición completa de los episodios de cefalea occipital. Buena tolerancia gástrica al esquema terapéutico con Losartán/HCTZ y Atorvastatina. Comenzó plan de caminatas 3 veces por semana. Cumple dieta baja en sal.',
          objective: 'Paciente en excelente estado general, sonriente y eupneico. Auscultación cardíaca rítmica regular, silencios libres. Auscultación pulmonar sin ruidos patológicos. Abdomen blando indoloro. Miembros inferiores sin edemas. Cifras de TA normalizadas.',
          assessment: 'Hipertensión arterial esencial estadio 1 ahora controlada y compensada en rango óptimo (<130/80 mmHg). Diabetes tipo 2 estable sin signos clínicos de descompensación ni hipoglucemias.',
          plan: '1. Mantener esquema terapéutico actual sin modificaciones.\n2. Continuar con plan de ejercicio aeróbico regular.\n3. Solicitar perfil bioquímico de control (HbA1c, función renal e ionograma) previo a próxima consulta.\n4. Cita de seguimiento en 2 meses.'
        },
        vitalSigns: {
          systolicBP: 124,
          diastolicBP: 78,
          heartRate: 72,
          respiratoryRate: 15,
          temperature: 36.5,
          oxygenSaturation: 99,
          weightKg: 86.2,
          heightCm: 175,
          calculatedBMI: 28.1,
          bmiCategory: 'Sobrepeso (Pre-obesidad)',
          capillaryBloodGlucose: 112
        },
        diagnoses: [
          { code: 'I10', name: 'Hipertensión esencial (primaria)', type: 'Principal', condition: 'Definitivo' },
          { code: 'E11.9', name: 'Diabetes mellitus tipo 2 sin mención de complicación', type: 'Secundario', condition: 'Definitivo' }
        ],
        treatmentPlan: [
          {
            id: 'rx-sub-01',
            medication: 'Losartán 50mg / HCTZ 12.5mg',
            presentation: 'Comprimidos',
            dosage: '1 comprimido',
            route: 'Oral',
            frequency: 'Cada mañana',
            duration: 'Continuo',
            indications: 'Mantener toma diaria.'
          }
        ],
        generalIndications: 'Mantener hidratación y plan de caminatas.',
        nextAppointmentDate: '2026-04-20',
        doctorSignatureStamp: 'Dra. Elena Santillán - MN 114.892'
      },
      {
        id: 'sub-002',
        patientId: 'pat-001',
        date: '2026-04-10T11:00:00Z',
        doctorName: 'Dra. Elena Santillán',
        doctorSpecialty: 'Medicina Interna',
        doctorLicense: 'MN 114.892',
        mode: 'free',
        freeEvolutionNote: 'Control periódico bimestral de enfermedades crónicas. Paciente asintomático, refiere excelente apego a la medicación y actividad física sostenida (camina 4 veces por semana). Trae analítica de control: Glucemia en ayunas 108 mg/dL, HbA1c descendió a 6.4% (meta lograda), Colesterol total 174 mg/dL, LDL 96 mg/dL, HDL 48 mg/dL, Creatinina 0.91 mg/dL, Ionograma normal. Se constata descenso ponderal de 1.4 kg adicionales respecto a febrero. Al examen físico: vigil, hidratado, normofonético, sin edemas periféricos. TA 122/76 mmHg. Conclusión: Paciente con excelente respuesta terapéutica, metas cardiovasculares y glucémicas alcanzadas. Se renuevan recetas para 90 días y se agenda próximo control en julio.',
        vitalSigns: {
          systolicBP: 122,
          diastolicBP: 76,
          heartRate: 70,
          respiratoryRate: 14,
          temperature: 36.4,
          oxygenSaturation: 99,
          weightKg: 84.8,
          heightCm: 175,
          calculatedBMI: 27.7,
          bmiCategory: 'Sobrepeso (Pre-obesidad)',
          capillaryBloodGlucose: 106
        },
        diagnoses: [
          { code: 'I10', name: 'Hipertensión esencial (primaria)', type: 'Principal', condition: 'Definitivo' },
          { code: 'E11.9', name: 'Diabetes mellitus tipo 2 sin mención de complicación', type: 'Secundario', condition: 'Definitivo' },
          { code: 'E78.2', name: 'Hiperlipidemia mixta (en metas)', type: 'Secundario', condition: 'Definitivo' }
        ],
        treatmentPlan: [
          {
            id: 'rx-sub-02',
            medication: 'Losartán 50mg / HCTZ 12.5mg',
            presentation: 'Comprimidos',
            dosage: '1 comp/día',
            route: 'Oral',
            frequency: 'Matutino',
            duration: '90 días'
          },
          {
            id: 'rx-sub-03',
            medication: 'Metformina XR 850mg',
            presentation: 'Comprimidos de liberación prolongada',
            dosage: '1 comp/noche',
            route: 'Oral',
            frequency: 'Nocturno',
            duration: '90 días'
          },
          {
            id: 'rx-sub-04',
            medication: 'Atorvastatina 20mg',
            presentation: 'Comprimidos',
            dosage: '1 comp/noche',
            route: 'Oral',
            frequency: 'Nocturno',
            duration: '90 días'
          }
        ],
        generalIndications: 'Continuar con el estilo de vida actual. Excelente evolución metabólica y ponderal.',
        nextAppointmentDate: '2026-07-15',
        doctorSignatureStamp: 'Dra. Elena Santillán - MN 114.892'
      }
    ],
    attachments: [
      {
        id: 'att-01',
        patientId: 'pat-001',
        fileName: 'Laboratorio_Perfil_Lipidico_HbA1c_Abril2026.pdf',
        fileType: 'Laboratorio',
        uploadDate: '2026-04-10T10:45:00Z',
        fileSize: '1.2 MB',
        notes: 'Analítica completa de control bimestral. HbA1c 6.4%, Colesterol total 174 mg/dL.'
      },
      {
        id: 'att-02',
        patientId: 'pat-001',
        fileName: 'Electrocardiograma_12_Derivaciones_Enero2026.pdf',
        fileType: 'Imagen / RX / ECO',
        uploadDate: '2026-01-15T11:00:00Z',
        fileSize: '2.8 MB',
        notes: 'Ritmo sinusal regular 75 lpm, eje QRS normal (+45°), sin signos de hipertrofia ventricular izquierda ni isquemia aguda.'
      }
    ]
  },
  {
    id: 'pat-002',
    recordNumber: 'HC-2026-0043',
    createdAt: '2026-02-10T14:15:00Z',
    updatedAt: '2026-02-10T15:00:00Z',
    status: 'Activo',
    filiation: {
      fullName: 'Valentina Sofía Gómez Ortiz',
      birthDate: '1997-04-14',
      gender: 'Femenino',
      civilStatus: 'Soltero/a',
      occupation: 'Diseñadora UX / Docente Universitaria',
      educationLevel: 'Posgrado',
      documentType: 'Cédula de Identidad',
      documentNumber: '40.119.382',
      address: 'Calle Las Heras 1240, 3° A',
      city: 'Córdoba',
      stateProvince: 'Córdoba',
      phone: '+54 351 462-1100',
      mobile: '+54 9 351 773-4411',
      email: 'valen.gomez.ux@gmail.com',
      emergencyContactName: 'Esteban Gómez',
      emergencyContactRelation: 'Padre',
      emergencyContactPhone: '+54 9 351 882-9900',
      insuranceType: 'Obra Social / Seguro Privado',
      insuranceName: 'Swiss Medical Black',
      policyNumber: 'SM-994821-2',
      payerResponsible: 'Titular directo',
      bloodType: 'A-',
      organDonor: true,
      allergies: [
        {
          id: 'alg-03',
          allergen: 'AINEs (Ibuprofeno, Diclofenac, Ketorolac)',
          category: 'Medicamento',
          severity: 'Severa / Anafilaxia',
          reaction: 'Broncoespasmo agudo y urticaria severa con Ibuprofeno 600mg'
        }
      ],
      hereditary: {
        diabetes: false,
        hypertension: false,
        cardiopathy: false,
        cancer: true,
        cancerDetail: 'Abuela materna con cáncer de mama a los 64 años',
        nephropathy: false,
        stroke: false,
        others: 'Madre con asma bronquial de inicio en la adultez'
      },
      pathological: {
        chronicDiseases: 'Rinitis alérgica estacional. Asma leve intermitente.',
        infectiousDiseases: 'Niega patologías infectocontagiosas crónicas.',
        previousHospitalizations: 'Niega internaciones previas.',
        currentMedications: 'Fluticasona spray nasal 50mcg en épocas de polinización. Paracetamol si requiere analgésicos.'
      },
      nonPathological: {
        immunizationsComplete: true,
        immunizationsDetail: 'Calendario completo con vacuna VPH (3 dosis) y hepatitis B.',
        housingType: 'Departamento urbano con ventilación adecuada y todos los servicios.',
        petsZoonosis: 'Un gato doméstico.'
      },
      surgical: {
        surgeries: 'Amigdalectomía a los 8 años por cuadros recurrentes sin complicaciones.',
        traumaFractures: 'Niega traumatismos óseos mayores.',
        transfusions: false
      },
      gynecological: {
        menarcheAge: 12,
        lastMenstrualPeriod: '2026-03-28',
        cycleRhythm: '28 x 4 días, eumenorrea regular',
        pregnancies: 0,
        births: 0,
        abortions: 0,
        cesareans: 0,
        contraceptiveMethod: 'Anticonceptivos orales combinados (Drospirenona/Etinilestradiol)',
        lastPapSmearDate: '2025-09-12',
        lastMammogramDate: 'No aplica por edad (ecografía mamaria 2025 normal)'
      },
      habits: {
        smoking: 'No fumador',
        alcoholConsumption: 'Ocasional / Social',
        drugsRecreational: 'Niega',
        physicalActivity: '3-5 días/semana',
        dietQuality: 'Dieta ovo-lacto-vegetariana equilibrada, alta ingesta de frutas y legumbres.'
      }
    },
    firstConsultation: {
      id: 'cons-first-002',
      patientId: 'pat-002',
      date: '2026-02-10T14:30:00Z',
      doctorName: 'Dr. Lucas Benavídez',
      doctorSpecialty: 'Medicina General y Familiar',
      doctorLicense: 'MN 128.450',
      reasonForConsultation: 'Congestión nasal severa, estornudos en salvas y tos seca nocturna.',
      presentIllnessHistory: 'Paciente femenina de 29 años con antecedentes de rinitis alérgica que consulta por cuadro de 5 días de evolución caracterizado por rinorrea hialina abundante, prurito nasal y ocular intenso, estornudos en salva y tos seca irritativa predominantemente nocturna tras mudanza de domicilio a ambiente con polvo. Niega fiebre, dolor torácico o disnea.',
      systemsReview: {
        cardiovascular: { normal: true, notes: 'Sin palpitaciones ni mareos.' },
        respiratory: { normal: false, notes: 'Prurito nasofaríngeo, tos seca nocturna espasmódica leve.' },
        digestive: { normal: true, notes: 'Sin sintomatología digestiva.' },
        genitourinary: { normal: true, notes: 'Sin particularidades.' },
        nervous: { normal: true, notes: 'Cefalea frontal leve por congestión.' },
        musculoskeletal: { normal: true, notes: 'Sin mialgias.' },
        endocrine: { normal: true, notes: 'Sin particularidades.' },
        integumentary: { normal: true, notes: 'Sin lesiones exantemáticas activas.' }
      },
      physicalExamination: {
        generalState: 'Paciente vigil, orientada, facie alérgica con leve edema periorbitario y ojeras alérgicas.',
        headAndNeck: 'Rinoscopia anterior: mucosa nasal violácea pálida edematosa con secreción serosa abundante, cornetes inferiores hipertróficos. Orofaringe sin placas bacterianas, empedrado faríngeo posterior leve.',
        thoraxAndLungs: 'Tórax simétrico. Murmullo vesicular conservado bilateralmente, sibilancias espiratorias muy escasas tele-espiratorias que barren con maniobra tusígena. Sin tiraje intercostal. SatO2 99%.',
        abdomen: 'Blando, depresible, no doloroso.',
        extremities: 'Simétricas, sin edemas.',
        neurological: 'Sin alteraciones motoras ni sensitivas.'
      },
      vitalSigns: {
        systolicBP: 110,
        diastolicBP: 70,
        heartRate: 68,
        respiratoryRate: 15,
        temperature: 36.3,
        oxygenSaturation: 99,
        weightKg: 58.0,
        heightCm: 167,
        calculatedBMI: 20.8,
        bmiCategory: 'Peso normal (Eutrófico)'
      },
      priorStudies: 'Ecografía mamaria y PAP de control 2025: ambos dentro de parámetros normales.',
      diagnoses: [
        { code: 'J30.4', name: 'Rinitis alérgica, no especificada', type: 'Principal', condition: 'Definitivo' },
        { code: 'J45.9', name: 'Asma, no especificada (leve intermitente exacerbada)', type: 'Secundario', condition: 'Definitivo' }
      ],
      treatmentPlan: [
        {
          id: 'rx-v1',
          medication: 'Fexofenadina Clorhidrato',
          presentation: 'Comprimidos 120mg',
          dosage: '1 comprimido',
          route: 'Oral',
          frequency: 'Cada 24 horas por la mañana',
          duration: 'Por 14 días',
          indications: 'No produce sedación.'
        },
        {
          id: 'rx-v2',
          medication: 'Budesonida Spray Nasal',
          presentation: 'Suspensión para pulverización nasal 64 mcg/dosis',
          dosage: '1 aplicación en cada fosa nasal',
          route: 'Inhalatoria',
          frequency: 'Cada 12 horas',
          duration: 'Por 3 semanas',
          indications: 'Sonar la nariz suavemente antes de aplicar.'
        },
        {
          id: 'rx-v3',
          medication: 'Salbutamol Inhalador de dosis medida (MDI)',
          presentation: 'Aerosol 100 mcg/disparo',
          dosage: '2 disparos con aerocámara',
          route: 'Inhalatoria',
          frequency: 'Solo rescate si presenta opresión torácica o sibilancias',
          duration: 'A demanda',
          indications: 'IMPORTANTE: Paciente es ALÉRGICA A AINES. Prohibido indicar Ibuprofeno, Diclofenac ni Aspirina. Si requiere analgésico, usar únicamente Paracetamol.'
        }
      ],
      recommendations: 'Control ambiental estricto: forrar almohadas y colchón con fundas antiácaros, ventilar habitación en horas centrales del día, aspirado con filtro HEPA, evitar alfombras y peluches. Hidratación nasal con solución salina.',
      prognosis: 'Favorable',
      doctorSignatureStamp: 'Dr. Lucas Benavídez - Matrícula Nacional 128.450'
    },
    subsequentConsultations: [],
    attachments: [
      {
        id: 'att-03',
        patientId: 'pat-002',
        fileName: 'Informe_PAP_Colposcopia_2025.pdf',
        fileType: 'Informe externo',
        uploadDate: '2026-02-10T14:40:00Z',
        fileSize: '850 KB',
        notes: 'Informe de Papanicolaou negativo para lesión intraepitelial o malignidad.'
      }
    ]
  },
  {
    id: 'pat-003',
    recordNumber: 'HC-2026-0044',
    createdAt: '2026-03-01T08:00:00Z',
    updatedAt: '2026-03-01T08:15:00Z',
    status: 'En espera',
    filiation: {
      fullName: 'Martín Ezequiel Morales Herrera',
      birthDate: '1988-11-05',
      gender: 'Masculino',
      civilStatus: 'Unión libre',
      occupation: 'Desarrollador de Software',
      educationLevel: 'Universitario',
      documentType: 'DNI',
      documentNumber: '34.209.811',
      address: 'Calle San Martín 820, Piso 2',
      city: 'Rosario',
      stateProvince: 'Santa Fe',
      phone: '+54 341 422-5566',
      mobile: '+54 9 341 690-3322',
      email: 'martin.morales@techdev.io',
      emergencyContactName: 'Laura Domínguez',
      emergencyContactRelation: 'Pareja',
      emergencyContactPhone: '+54 9 341 690-3323',
      insuranceType: 'Particular',
      insuranceName: 'Particular / Sin prepaga',
      policyNumber: 'PART-0044',
      payerResponsible: 'Paciente directo',
      bloodType: 'B+',
      organDonor: true,
      allergies: [],
      hereditary: {
        diabetes: false,
        hypertension: true,
        hypertensionDetail: 'Padre hipertenso',
        cardiopathy: false,
        cancer: false,
        nephropathy: false,
        stroke: false
      },
      pathological: {
        chronicDiseases: 'Niega enfermedades crónicas conocidas.',
        infectiousDiseases: 'Sin antecedentes relevantes.',
        previousHospitalizations: 'Niega.',
        currentMedications: 'Ninguna medicación habitual.'
      },
      nonPathological: {
        immunizationsComplete: true,
        housingType: 'Urbana con todos los servicios.',
        petsZoonosis: 'Ninguna.'
      },
      surgical: {
        surgeries: 'Sin cirugías previas.',
        traumaFractures: 'Esguince de tobillo derecho en 2021.',
        transfusions: false
      },
      habits: {
        smoking: 'No fumador',
        alcoholConsumption: 'Ocasional / Social',
        drugsRecreational: 'Niega',
        physicalActivity: 'Sedentario',
        dietQuality: 'Comida rápida frecuente por trabajo en oficina.'
      }
    },
    // No first consultation yet: Perfect for the doctor to create their first consultation!
    firstConsultation: undefined,
    subsequentConsultations: [],
    attachments: []
  }
];
