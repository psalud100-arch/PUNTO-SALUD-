/**
 * MedRecord Pro - Plataforma Profesional de Historia Clínica Electrónica (HCE / EMR)
 * Diseñada exclusivamente para profesionales médicos.
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { PatientHeader } from './components/PatientHeader';
import { FiliationForm } from './components/FiliationForm';
import { FirstConsultationForm } from './components/FirstConsultationForm';
import { SubsequentConsultationForm } from './components/SubsequentConsultationForm';
import { TimelineView } from './components/TimelineView';
import { PrintableDocuments } from './components/PrintableDocuments';
import { AttachmentsModule } from './components/AttachmentsModule';
import { PatientSearchModal } from './components/PatientSearchModal';
import { NewPatientModal } from './components/NewPatientModal';
import { SpecificationModal } from './components/SpecificationModal';
import { INITIAL_PATIENTS } from './data/mockPatients';
import { Patient, PatientFiliation, FirstConsultation, SubsequentConsultation, ClinicalAttachment } from './types/medical';

export default function App() {
  const [patients, setPatients] = useState<Patient[]>(() => {
    const saved = localStorage.getItem('medrecord_patients_data');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_PATIENTS;
      }
    }
    return INITIAL_PATIENTS;
  });

  const [activePatientId, setActivePatientId] = useState<string>('pat-001');
  const [currentView, setCurrentView] = useState<'dashboard' | 'patient'>('patient');
  const [activeTab, setActiveTab] = useState<'filiation' | 'first-consultation' | 'subsequent' | 'timeline' | 'documents' | 'attachments'>('filiation');

  // Modals
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNewPatientOpen, setIsNewPatientOpen] = useState(false);
  const [isSpecOpen, setIsSpecOpen] = useState(false);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('medrecord_patients_data', JSON.stringify(patients));
  }, [patients]);

  // Global keyboard shortcuts (Ctrl+K or Cmd+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const activePatient = patients.find(p => p.id === activePatientId) || patients[0];

  const handleSelectPatient = (patientId: string, initialTab: any = 'filiation') => {
    setActivePatientId(patientId);
    setActiveTab(initialTab);
    setCurrentView('patient');
  };

  const handleSaveFiliation = (updatedFiliation: PatientFiliation) => {
    setPatients(prev =>
      prev.map(p =>
        p.id === activePatient.id
          ? {
              ...p,
              filiation: updatedFiliation,
              updatedAt: new Date().toISOString()
            }
          : p
      )
    );
  };

  const handleSaveFirstConsultation = (consultation: FirstConsultation) => {
    setPatients(prev =>
      prev.map(p =>
        p.id === activePatient.id
          ? {
              ...p,
              firstConsultation: consultation,
              status: 'Activo',
              updatedAt: new Date().toISOString()
            }
          : p
      )
    );
  };

  const handleSaveSubsequentConsultation = (consultation: SubsequentConsultation) => {
    setPatients(prev =>
      prev.map(p =>
        p.id === activePatient.id
          ? {
              ...p,
              subsequentConsultations: [consultation, ...p.subsequentConsultations],
              status: 'Activo',
              updatedAt: new Date().toISOString()
            }
          : p
      )
    );
    // Switch to timeline to see the record
    setActiveTab('timeline');
  };

  const handleAddAttachment = (attachment: ClinicalAttachment) => {
    setPatients(prev =>
      prev.map(p =>
        p.id === activePatient.id
          ? {
              ...p,
              attachments: [attachment, ...p.attachments],
              updatedAt: new Date().toISOString()
            }
          : p
      )
    );
  };

  const handleDeleteAttachment = (attachmentId: string) => {
    setPatients(prev =>
      prev.map(p =>
        p.id === activePatient.id
          ? {
              ...p,
              attachments: p.attachments.filter(a => a.id !== attachmentId),
              updatedAt: new Date().toISOString()
            }
          : p
      )
    );
  };

  const handleCreateNewPatient = (newPatient: Patient) => {
    setPatients(prev => [newPatient, ...prev]);
    setActivePatientId(newPatient.id);
    setActiveTab('first-consultation'); // Go directly to their first consultation
    setCurrentView('patient');
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans">
      
      {/* Top Navigation */}
      <Navbar
        activePatient={currentView === 'patient' ? activePatient : null}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenNewPatient={() => setIsNewPatientOpen(true)}
        onOpenSpec={() => setIsSpecOpen(true)}
        onGoToDashboard={() => setCurrentView('dashboard')}
        currentView={currentView}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        
        {/* VIEW 1: DASHBOARD */}
        {currentView === 'dashboard' && (
          <Dashboard
            patients={patients}
            onSelectPatient={handleSelectPatient}
            onOpenNewPatient={() => setIsNewPatientOpen(true)}
            onOpenSearch={() => setIsSearchOpen(true)}
            onOpenSpec={() => setIsSpecOpen(true)}
          />
        )}

        {/* VIEW 2: ACTIVE PATIENT WORKSPACE */}
        {currentView === 'patient' && activePatient && (
          <div>
            {/* Persistent Patient Header with Allergy Banner and Tab Bar */}
            <PatientHeader
              patient={activePatient}
              activeTab={activeTab}
              onTabChange={setActiveTab}
            />

            {/* Tab 1: Datos de Filiación */}
            {activeTab === 'filiation' && (
              <FiliationForm
                initialFiliation={activePatient.filiation}
                onSave={handleSaveFiliation}
              />
            )}

            {/* Tab 2: Primera Consulta */}
            {activeTab === 'first-consultation' && (
              <FirstConsultationForm
                patient={activePatient}
                existingConsultation={activePatient.firstConsultation}
                onSave={handleSaveFirstConsultation}
              />
            )}

            {/* Tab 3: Consultas Subsecuentes (Evoluciones) */}
            {activeTab === 'subsequent' && (
              <SubsequentConsultationForm
                patient={activePatient}
                onSave={handleSaveSubsequentConsultation}
                onViewHistory={() => setActiveTab('timeline')}
              />
            )}

            {/* Tab 4: Línea de Tiempo */}
            {activeTab === 'timeline' && (
              <TimelineView
                patient={activePatient}
                onSelectPrintConsultation={() => setActiveTab('documents')}
              />
            )}

            {/* Tab 5: Recetas & Documentos Imprimibles */}
            {activeTab === 'documents' && (
              <PrintableDocuments
                patient={activePatient}
              />
            )}

            {/* Tab 6: Archivos & Gabinete */}
            {activeTab === 'attachments' && (
              <AttachmentsModule
                patient={activePatient}
                onAddAttachment={handleAddAttachment}
                onDeleteAttachment={handleDeleteAttachment}
              />
            )}
          </div>
        )}

      </main>

      {/* MODAL 1: BÚSQUEDA RÁPIDA (Ctrl+K) */}
      <PatientSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        patients={patients}
        onSelectPatient={handleSelectPatient}
      />

      {/* MODAL 2: NUEVO PACIENTE */}
      <NewPatientModal
        isOpen={isNewPatientOpen}
        onClose={() => setIsNewPatientOpen(false)}
        onSavePatient={handleCreateNewPatient}
      />

      {/* MODAL 3: ESPECIFICACIÓN TÉCNICA COMPLETA & ARQUITECTURA */}
      <SpecificationModal
        isOpen={isSpecOpen}
        onClose={() => setIsSpecOpen(false)}
      />

    </div>
  );
}
