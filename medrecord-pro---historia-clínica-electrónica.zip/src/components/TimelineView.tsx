import React, { useState } from 'react';
import { 
  Clock, 
  Calendar, 
  Stethoscope, 
  FileText, 
  Activity, 
  Pill, 
  CheckCircle, 
  TrendingDown, 
  TrendingUp, 
  Printer, 
  ChevronDown, 
  ChevronUp, 
  AlertCircle,
  Eye
} from 'lucide-react';
import { Patient, SubsequentConsultation, FirstConsultation } from '../types/medical';
import { formatDateTime, formatDate } from '../utils/medicalCalculators';

interface TimelineViewProps {
  patient: Patient;
  onSelectPrintConsultation?: (consultationId: string) => void;
}

export const TimelineView: React.FC<TimelineViewProps> = ({
  patient,
  onSelectPrintConsultation
}) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    setExpandedId(prev => (prev === id ? null : id));
  };

  // Compile all clinical encounters chronologically
  const encounters: Array<{
    id: string;
    type: 'first' | 'subsequent_soap' | 'subsequent_free';
    date: string;
    doctor: string;
    specialty: string;
    diagnoses: any[];
    vitals: any;
    data: FirstConsultation | SubsequentConsultation;
  }> = [];

  if (patient.firstConsultation) {
    encounters.push({
      id: patient.firstConsultation.id,
      type: 'first',
      date: patient.firstConsultation.date,
      doctor: patient.firstConsultation.doctorName,
      specialty: patient.firstConsultation.doctorSpecialty,
      diagnoses: patient.firstConsultation.diagnoses,
      vitals: patient.firstConsultation.vitalSigns,
      data: patient.firstConsultation
    });
  }

  patient.subsequentConsultations.forEach(sub => {
    encounters.push({
      id: sub.id,
      type: sub.mode === 'soap' ? 'subsequent_soap' : 'subsequent_free',
      date: sub.date,
      doctor: sub.doctorName,
      specialty: sub.doctorSpecialty,
      diagnoses: sub.diagnoses,
      vitals: sub.vitalSigns,
      data: sub
    });
  });

  // Sort descending by date (most recent first)
  encounters.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  // Collect vital history for trend comparison
  const vitalsHistory = [...encounters].reverse().map(e => ({
    date: formatDate(e.date),
    bp: `${e.vitals?.systolicBP || '-'}/${e.vitals?.diastolicBP || '-'}`,
    weight: e.vitals?.weightKg || '-',
    bmi: e.vitals?.calculatedBMI || '-',
    bmiCat: e.vitals?.bmiCategory || '-'
  }));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
            <Clock className="w-5 h-5 text-amber-600" />
            <span>Línea de Tiempo Clínica Integral</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Historial cronológico de atenciones, hojas de consulta, notas de evolución y trayectoria de signos vitales.
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <div className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg">
            <span className="text-slate-500">Total de Consultas:</span>{' '}
            <strong className="text-slate-900">{encounters.length}</strong>
          </div>
          <div className="px-3 py-1.5 bg-teal-50 border border-teal-200 rounded-lg text-teal-800 font-semibold">
            Primera Vez: {patient.firstConsultation ? 'Registrada' : 'Pendiente'}
          </div>
        </div>
      </div>

      {/* VITAL SIGNS TRAJECTORY TABLE */}
      {vitalsHistory.length > 1 && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
          <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center space-x-2">
            <Activity className="w-4 h-4 text-teal-600" />
            <span>Evolución Histórica de Somatometría & Presión Arterial</span>
          </h3>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 text-xs">
              <thead className="bg-slate-50 text-slate-700 font-semibold">
                <tr>
                  <th className="px-4 py-2.5 text-left">Fecha de Visita</th>
                  <th className="px-4 py-2.5 text-left">Presión Arterial (mmHg)</th>
                  <th className="px-4 py-2.5 text-left">Peso Corporal</th>
                  <th className="px-4 py-2.5 text-left">IMC</th>
                  <th className="px-4 py-2.5 text-left">Categoría Nutricional</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {vitalsHistory.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="px-4 py-2 font-semibold text-slate-900">{row.date}</td>
                    <td className="px-4 py-2 font-mono text-slate-800">{row.bp}</td>
                    <td className="px-4 py-2 font-mono text-slate-800">{row.weight} kg</td>
                    <td className="px-4 py-2 font-mono font-bold text-teal-700">{row.bmi} kg/m²</td>
                    <td className="px-4 py-2">
                      <span className="px-2 py-0.5 rounded-full text-[11px] bg-slate-100 text-slate-700">
                        {row.bmiCat}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* CHRONOLOGICAL TIMELINE STREAM */}
      <div className="relative pl-6 sm:pl-8 border-l-2 border-slate-200 space-y-6">
        {encounters.length > 0 ? (
          encounters.map(item => {
            const isFirst = item.type === 'first';
            const isSoap = item.type === 'subsequent_soap';
            const isExpanded = expandedId === item.id;
            const subData = item.data as SubsequentConsultation;
            const firstData = item.data as FirstConsultation;

            return (
              <div key={item.id} className="relative group">
                
                {/* Timeline Circle Bullet */}
                <div className={`absolute -left-[31px] sm:-left-[39px] top-1.5 w-6 h-6 rounded-full border-2 bg-white flex items-center justify-center shadow-xs ${
                  isFirst
                    ? 'border-blue-600 text-blue-600'
                    : isSoap
                    ? 'border-purple-600 text-purple-600'
                    : 'border-amber-600 text-amber-600'
                }`}>
                  {isFirst ? (
                    <Stethoscope className="w-3 h-3" />
                  ) : (
                    <FileText className="w-3 h-3" />
                  )}
                </div>

                {/* Consultation Card */}
                <div className="bg-white rounded-xl border border-slate-200 shadow-2xs hover:border-slate-300 transition overflow-hidden">
                  
                  {/* Card Header */}
                  <div 
                    onClick={() => toggleExpand(item.id)}
                    className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer hover:bg-slate-50/60 transition"
                  >
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                          isFirst
                            ? 'bg-blue-100 text-blue-800'
                            : isSoap
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {isFirst ? 'Primera Consulta (Externa)' : isSoap ? 'Evolución SOAP' : 'Evolución Libre'}
                        </span>

                        <span className="text-xs text-slate-500 font-medium">
                          {formatDateTime(item.date)}
                        </span>
                      </div>

                      <h4 className="text-sm sm:text-base font-bold text-slate-900 mt-1.5">
                        {isFirst 
                          ? `Motivo: ${firstData.reasonForConsultation}` 
                          : isSoap && subData.soap
                          ? `Evolución: ${subData.soap.assessment.slice(0, 100)}...`
                          : subData.freeEvolutionNote 
                          ? subData.freeEvolutionNote.slice(0, 120) + '...'
                          : 'Consulta de Seguimiento'}
                      </h4>

                      <div className="text-xs text-slate-500 mt-1">
                        Atendido por: <strong className="text-slate-700">{item.doctor}</strong> ({item.specialty})
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 shrink-0">
                      {/* Vitals summary chip */}
                      {item.vitals && (
                        <div className="text-right text-xs bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
                          <div className="font-mono font-bold text-slate-800">
                            {item.vitals.systolicBP}/{item.vitals.diastolicBP} mmHg · {item.vitals.weightKg} kg
                          </div>
                          <div className="text-[11px] text-slate-500">
                            IMC: {item.vitals.calculatedBMI} ({item.vitals.bmiCategory})
                          </div>
                        </div>
                      )}

                      <button
                        type="button"
                        className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
                      >
                        {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                      </button>
                    </div>
                  </div>

                  {/* Diagnoses Pills Bar */}
                  {item.diagnoses && item.diagnoses.length > 0 && (
                    <div className="px-4 sm:px-5 py-2 bg-slate-50/70 border-t border-slate-100 flex flex-wrap items-center gap-1.5">
                      <span className="text-[11px] font-semibold text-slate-500 mr-1">Diagnósticos:</span>
                      {item.diagnoses.map(d => (
                        <span key={d.code} className="inline-flex items-center text-xs px-2 py-0.5 rounded bg-blue-50 text-blue-900 border border-blue-200">
                          <strong className="font-mono mr-1">{d.code}</strong> {d.name}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Expanded Content Details */}
                  {isExpanded && (
                    <div className="p-4 sm:p-5 border-t border-slate-200 bg-white space-y-4 text-xs sm:text-sm">
                      
                      {/* If First Consultation */}
                      {isFirst && (
                        <div className="space-y-3">
                          <div>
                            <div className="font-bold text-slate-900 text-xs uppercase tracking-wider text-teal-800">Historia de la Enfermedad Actual:</div>
                            <p className="text-slate-700 mt-1 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-200">
                              {firstData.presentIllnessHistory}
                            </p>
                          </div>

                          <div>
                            <div className="font-bold text-slate-900 text-xs uppercase tracking-wider text-teal-800">Exploración Física:</div>
                            <div className="mt-1 text-slate-700 bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1 text-xs">
                              <p><strong>General:</strong> {firstData.physicalExamination.generalState}</p>
                              <p><strong>Cabeza/Cuello:</strong> {firstData.physicalExamination.headAndNeck}</p>
                              <p><strong>Tórax/Lungs/Corazón:</strong> {firstData.physicalExamination.thoraxAndLungs}</p>
                              <p><strong>Abdomen:</strong> {firstData.physicalExamination.abdomen}</p>
                              <p><strong>Extremidades:</strong> {firstData.physicalExamination.extremities}</p>
                            </div>
                          </div>

                          {firstData.treatmentPlan && firstData.treatmentPlan.length > 0 && (
                            <div>
                              <div className="font-bold text-slate-900 text-xs uppercase tracking-wider text-emerald-800">Prescripción / Tratamiento:</div>
                              <ul className="mt-1 space-y-1 bg-emerald-50/50 p-3 rounded-lg border border-emerald-200 text-xs">
                                {firstData.treatmentPlan.map((rx, i) => (
                                  <li key={i} className="text-slate-800">
                                    • <strong>{rx.medication}</strong> ({rx.presentation}) - {rx.dosage}, {rx.frequency}, {rx.duration}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {firstData.recommendations && (
                            <div>
                              <div className="font-bold text-slate-900 text-xs uppercase tracking-wider text-slate-700">Indicaciones Generales:</div>
                              <p className="text-slate-700 mt-0.5">{firstData.recommendations}</p>
                            </div>
                          )}
                        </div>
                      )}

                      {/* If Subsequent SOAP */}
                      {isSoap && subData.soap && (
                        <div className="space-y-3">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div className="p-3 rounded-lg bg-blue-50/50 border border-blue-200">
                              <div className="font-bold text-blue-900 text-xs mb-1">S - Subjetivo</div>
                              <p className="text-slate-800 text-xs leading-relaxed">{subData.soap.subjective}</p>
                            </div>
                            <div className="p-3 rounded-lg bg-emerald-50/50 border border-emerald-200">
                              <div className="font-bold text-emerald-900 text-xs mb-1">O - Objetivo</div>
                              <p className="text-slate-800 text-xs leading-relaxed">{subData.soap.objective}</p>
                            </div>
                            <div className="p-3 rounded-lg bg-amber-50/50 border border-amber-200">
                              <div className="font-bold text-amber-900 text-xs mb-1">A - Análisis / Juicio Clínico</div>
                              <p className="text-slate-800 text-xs leading-relaxed">{subData.soap.assessment}</p>
                            </div>
                            <div className="p-3 rounded-lg bg-purple-50/50 border border-purple-200">
                              <div className="font-bold text-purple-900 text-xs mb-1">P - Plan de Manejo</div>
                              <p className="text-slate-800 text-xs leading-relaxed whitespace-pre-line">{subData.soap.plan}</p>
                            </div>
                          </div>

                          {subData.treatmentPlan && subData.treatmentPlan.length > 0 && (
                            <div>
                              <div className="font-bold text-xs uppercase text-emerald-800 mb-1">Receta Actualizada:</div>
                              <div className="bg-emerald-50/50 p-2.5 rounded-lg border border-emerald-200 text-xs space-y-1">
                                {subData.treatmentPlan.map((rx, idx) => (
                                  <div key={idx}>
                                    • <strong>{rx.medication}</strong> - {rx.dosage} {rx.frequency} ({rx.duration})
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {subData.nextAppointmentDate && (
                            <div className="text-xs text-purple-800 font-semibold bg-purple-50 px-3 py-1.5 rounded-lg border border-purple-200 inline-block">
                              Próxima cita de control programada: {formatDate(subData.nextAppointmentDate)}
                            </div>
                          )}
                        </div>
                      )}

                      {/* If Subsequent Free Evolution */}
                      {!isFirst && !isSoap && subData.freeEvolutionNote && (
                        <div className="space-y-3">
                          <div>
                            <div className="font-bold text-xs uppercase text-slate-700 mb-1">Nota de Evolución Completa:</div>
                            <p className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-slate-800 text-xs leading-relaxed whitespace-pre-line">
                              {subData.freeEvolutionNote}
                            </p>
                          </div>

                          {subData.treatmentPlan && subData.treatmentPlan.length > 0 && (
                            <div className="bg-emerald-50/50 p-2.5 rounded-lg border border-emerald-200 text-xs space-y-1">
                              <div className="font-bold text-emerald-900">Tratamiento prescrito:</div>
                              {subData.treatmentPlan.map((rx, idx) => (
                                <div key={idx}>
                                  • <strong>{rx.medication}</strong> {rx.dosage} ({rx.frequency})
                                </div>
                              ))}
                            </div>
                          )}

                          {subData.nextAppointmentDate && (
                            <div className="text-xs text-purple-800 font-semibold bg-purple-50 px-3 py-1.5 rounded-lg border border-purple-200 inline-block">
                              Próxima cita de control: {formatDate(subData.nextAppointmentDate)}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Card Footer Stamp */}
                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                        <span>Firma legal: {item.doctor} · {item.specialty}</span>
                        {onSelectPrintConsultation && (
                          <button
                            type="button"
                            onClick={() => onSelectPrintConsultation(item.id)}
                            className="flex items-center space-x-1 text-teal-700 hover:text-teal-900 font-semibold"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>Imprimir Resumen / Receta</span>
                          </button>
                        )}
                      </div>

                    </div>
                  )}

                </div>
              </div>
            );
          })
        ) : (
          <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
            <Calendar className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <h4 className="font-bold text-slate-800 text-sm">Sin consultas registradas aún</h4>
            <p className="text-xs text-slate-500 mt-1">
              Registre la Primera Consulta o una Evolución Subsecuente para ver la línea de tiempo.
            </p>
          </div>
        )}
      </div>

    </div>
  );
};
