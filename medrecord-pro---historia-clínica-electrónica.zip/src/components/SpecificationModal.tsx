import React, { useState } from 'react';
import { 
  X, 
  BookOpen, 
  Download, 
  Copy, 
  Check, 
  Server, 
  Database, 
  Layout, 
  CheckSquare, 
  Cpu, 
  ShieldCheck, 
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { SPECIFICATION_DOCUMENT, SpecSection } from '../data/specificationContent';

interface SpecificationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SpecificationModal: React.FC<SpecificationModalProps> = ({
  isOpen,
  onClose
}) => {
  const [activeSectionId, setActiveSectionId] = useState<string>('arquitectura');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const activeSection = SPECIFICATION_DOCUMENT.find(s => s.id === activeSectionId) || SPECIFICATION_DOCUMENT[0];

  const handleCopyCurrentSection = () => {
    navigator.clipboard.writeText(activeSection.contentMarkdown);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFullMarkdown = () => {
    const fullDoc = `# ESPECIFICACIÓN TÉCNICA Y ARQUITECTURA DE HISTORIA CLÍNICA ELECTRÓNICA (HCE / EMR)
Fecha: ${new Date().toLocaleDateString('es-ES')}
Plataforma: MedRecord Pro EMR
Autor: Equipo de Ingeniería y Arquitectura Clínica

---

${SPECIFICATION_DOCUMENT.map(s => `## ${s.title}\n*${s.subtitle}*\n\n${s.contentMarkdown}\n\n---\n`).join('\n')}
`;

    const blob = new Blob([fullDoc], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Especificacion_Tecnica_HCE_MedRecord_Pro.md';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getIcon = (name: string) => {
    switch (name) {
      case 'Server': return <Server className="w-4 h-4" />;
      case 'Database': return <Database className="w-4 h-4" />;
      case 'Layout': return <Layout className="w-4 h-4" />;
      case 'CheckSquare': return <CheckSquare className="w-4 h-4" />;
      case 'Cpu': return <Cpu className="w-4 h-4" />;
      case 'ShieldCheck': return <ShieldCheck className="w-4 h-4" />;
      case 'Sparkles': return <Sparkles className="w-4 h-4" />;
      default: return <BookOpen className="w-4 h-4" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white rounded-2xl max-w-6xl w-full h-[90vh] shadow-2xl border border-slate-200 flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-teal-500 text-slate-950 flex items-center justify-center font-bold">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base sm:text-lg font-bold tracking-tight">
                  Especificación de Arquitectura e Ingeniería (HCE / EMR)
                </h2>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-teal-500/20 text-teal-300 border border-teal-500/30">
                  SRS v2.4
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Documento técnico exhaustivo listo para desarrollo, auditoría clínica y certificación normativa.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleDownloadFullMarkdown}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
              title="Descargar especificación completa en archivo Markdown (.md)"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Descargar .MD</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body: Sidebar + Markdown View */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          
          {/* Deliverables Navigation Sidebar */}
          <div className="w-full md:w-80 bg-slate-50 border-r border-slate-200 p-3 sm:p-4 overflow-y-auto shrink-0 space-y-1">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-2 py-1 mb-1">
              Los 7 Entregables Solicitados
            </div>

            {SPECIFICATION_DOCUMENT.map(sec => {
              const isActive = sec.id === activeSectionId;
              return (
                <button
                  key={sec.id}
                  onClick={() => setActiveSectionId(sec.id)}
                  className={`w-full text-left p-3 rounded-xl transition flex items-start space-x-2.5 cursor-pointer ${
                    isActive
                      ? 'bg-teal-700 text-white shadow-xs font-semibold'
                      : 'text-slate-700 hover:bg-slate-200/70 hover:text-slate-900'
                  }`}
                >
                  <div className={`mt-0.5 shrink-0 ${isActive ? 'text-teal-200' : 'text-slate-500'}`}>
                    {getIcon(sec.iconName)}
                  </div>
                  <div>
                    <div className="text-xs font-bold leading-tight">{sec.title}</div>
                    <div className={`text-[10px] mt-0.5 line-clamp-1 ${isActive ? 'text-teal-100' : 'text-slate-500'}`}>
                      {sec.subtitle}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto p-6 sm:p-8 bg-white">
            
            {/* Header of Section */}
            <div className="border-b border-slate-200 pb-4 mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  {activeSection.title}
                </h1>
                <p className="text-xs sm:text-sm text-slate-500 mt-1 font-medium">
                  {activeSection.subtitle}
                </p>
              </div>

              <button
                onClick={handleCopyCurrentSection}
                className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition shrink-0 cursor-pointer"
                title="Copiar texto de esta sección"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? '¡Copiado!' : 'Copiar Sección'}</span>
              </button>
            </div>

            {/* Markdown rendered view */}
            <div className="prose prose-slate max-w-none text-xs sm:text-sm leading-relaxed space-y-4">
              {activeSection.contentMarkdown.split('\n\n').map((paragraph, idx) => {
                // If it's a code block
                if (paragraph.startsWith('```')) {
                  const cleanedCode = paragraph.replace(/```[a-z]*\n?/g, '').replace(/```/g, '');
                  return (
                    <div key={idx} className="my-4 rounded-xl overflow-hidden border border-slate-800 bg-slate-950 text-slate-100 font-mono text-xs p-4 overflow-x-auto shadow-inner">
                      <pre className="m-0 leading-relaxed">{cleanedCode}</pre>
                    </div>
                  );
                }

                // If it's a table
                if (paragraph.includes('|')) {
                  const lines = paragraph.split('\n').filter(l => l.trim().length > 0);
                  const headers = lines[0]?.split('|').map(c => c.trim()).filter(Boolean) || [];
                  const rows = lines.slice(2).map(l => l.split('|').map(c => c.trim()).filter(Boolean));

                  return (
                    <div key={idx} className="my-4 overflow-x-auto rounded-xl border border-slate-200">
                      <table className="min-w-full divide-y divide-slate-200 text-xs">
                        <thead className="bg-slate-100 text-slate-800 font-bold">
                          <tr>
                            {headers.map((h, i) => (
                              <th key={i} className="px-3 py-2 text-left">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 font-medium">
                          {rows.map((row, rIdx) => (
                            <tr key={rIdx} className="hover:bg-slate-50">
                              {row.map((cell, cIdx) => (
                                <td key={cIdx} className="px-3 py-2 text-slate-700">{cell}</td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  );
                }

                // If it's a subheader
                if (paragraph.startsWith('### ')) {
                  return (
                    <h3 key={idx} className="text-base font-bold text-slate-900 mt-6 pt-2 border-t border-slate-100 flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-teal-600 inline-block" />
                      <span>{paragraph.replace('### ', '')}</span>
                    </h3>
                  );
                }

                if (paragraph.startsWith('#### ')) {
                  return (
                    <h4 key={idx} className="text-sm font-bold text-teal-900 mt-4">
                      {paragraph.replace('#### ', '')}
                    </h4>
                  );
                }

                // Plain paragraph or list
                return (
                  <p key={idx} className="text-slate-700 leading-relaxed whitespace-pre-line">
                    {paragraph}
                  </p>
                );
              })}
            </div>

          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-100 border-t border-slate-200 flex items-center justify-between text-xs text-slate-600 px-6 shrink-0">
          <div>
            Especificación oficial para ingenieros de software, comités bioéticos y arquitectos de salud.
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg text-xs transition"
          >
            Cerrar Especificación
          </button>
        </div>

      </div>
    </div>
  );
};
