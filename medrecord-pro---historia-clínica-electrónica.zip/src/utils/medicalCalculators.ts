/**
 * Medical utility calculators and formatting functions
 */

export function calculateAge(birthDateString: string): { years: number; months: number; text: string } {
  if (!birthDateString) return { years: 0, months: 0, text: 'No especificada' };
  
  const birthDate = new Date(birthDateString);
  const today = new Date();
  
  if (isNaN(birthDate.getTime())) return { years: 0, months: 0, text: 'Fecha inválida' };

  let years = today.getFullYear() - birthDate.getFullYear();
  let months = today.getMonth() - birthDate.getMonth();
  
  if (today.getDate() < birthDate.getDate()) {
    months--;
  }
  
  if (months < 0) {
    years--;
    months += 12;
  }
  
  if (years < 0) return { years: 0, months: 0, text: 'Fecha futura inválida' };
  
  if (years === 0) {
    return { years: 0, months, text: `${months} ${months === 1 ? 'mes' : 'meses'}` };
  }
  
  return { 
    years, 
    months, 
    text: `${years} ${years === 1 ? 'año' : 'años'}${months > 0 ? ` y ${months} m.` : ''}` 
  };
}

export function calculateBMI(weightKg: number, heightCm: number): {
  bmi: number;
  category: string;
  badgeClass: string;
  colorHex: string;
} {
  if (!weightKg || !heightCm || heightCm <= 0 || weightKg <= 0) {
    return {
      bmi: 0,
      category: 'No calculado',
      badgeClass: 'bg-slate-100 text-slate-600 border-slate-200',
      colorHex: '#64748b'
    };
  }

  const heightMeters = heightCm / 100;
  const rawBMI = weightKg / (heightMeters * heightMeters);
  const bmi = Math.round(rawBMI * 10) / 10;

  if (bmi < 18.5) {
    return {
      bmi,
      category: 'Bajo peso',
      badgeClass: 'bg-amber-50 text-amber-700 border-amber-200',
      colorHex: '#d97706'
    };
  } else if (bmi < 25.0) {
    return {
      bmi,
      category: 'Peso normal (Eutrófico)',
      badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      colorHex: '#059669'
    };
  } else if (bmi < 30.0) {
    return {
      bmi,
      category: 'Sobrepeso (Pre-obesidad)',
      badgeClass: 'bg-orange-50 text-orange-700 border-orange-200',
      colorHex: '#ea580c'
    };
  } else if (bmi < 35.0) {
    return {
      bmi,
      category: 'Obesidad Grado I',
      badgeClass: 'bg-rose-50 text-rose-700 border-rose-200',
      colorHex: '#e11d48'
    };
  } else if (bmi < 40.0) {
    return {
      bmi,
      category: 'Obesidad Grado II',
      badgeClass: 'bg-red-50 text-red-800 border-red-300 font-semibold',
      colorHex: '#b91c1c'
    };
  } else {
    return {
      bmi,
      category: 'Obesidad Grado III (Mórbida)',
      badgeClass: 'bg-purple-50 text-purple-800 border-purple-300 font-bold',
      colorHex: '#7e22ce'
    };
  }
}

export function evaluateBloodPressure(systolic: number, diastolic: number): {
  label: string;
  isAlert: boolean;
  alertLevel: 'normal' | 'elevated' | 'stage1' | 'stage2' | 'crisis';
  badgeClass: string;
} {
  if (!systolic || !diastolic) {
    return { label: 'Sin registro', isAlert: false, alertLevel: 'normal', badgeClass: 'bg-slate-100 text-slate-600' };
  }

  if (systolic >= 180 || diastolic >= 120) {
    return {
      label: 'Crisis Hipertensiva (Urgencia)',
      isAlert: true,
      alertLevel: 'crisis',
      badgeClass: 'bg-red-100 text-red-800 border border-red-300 animate-pulse font-bold'
    };
  } else if (systolic >= 140 || diastolic >= 90) {
    return {
      label: 'HTA Grado 2',
      isAlert: true,
      alertLevel: 'stage2',
      badgeClass: 'bg-rose-50 text-rose-700 border border-rose-200 font-semibold'
    };
  } else if (systolic >= 130 || diastolic >= 80) {
    return {
      label: 'HTA Grado 1',
      isAlert: true,
      alertLevel: 'stage1',
      badgeClass: 'bg-amber-50 text-amber-700 border border-amber-200'
    };
  } else if (systolic >= 120 && diastolic < 80) {
    return {
      label: 'Presión Elevada',
      isAlert: false,
      alertLevel: 'elevated',
      badgeClass: 'bg-yellow-50 text-yellow-700 border border-yellow-200'
    };
  } else {
    return {
      label: 'Normotensión',
      isAlert: false,
      alertLevel: 'normal',
      badgeClass: 'bg-emerald-50 text-emerald-700 border border-emerald-200'
    };
  }
}

export function formatDate(isoDate: string): string {
  if (!isoDate) return 'N/A';
  try {
    const d = new Date(isoDate);
    return d.toLocaleDateString('es-ES', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  } catch {
    return isoDate;
  }
}

export function formatDateTime(isoDate: string): string {
  if (!isoDate) return 'N/A';
  try {
    const d = new Date(isoDate);
    return d.toLocaleDateString('es-ES', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch {
    return isoDate;
  }
}
