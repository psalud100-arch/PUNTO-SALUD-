import React from 'react';
import { 
  User, 
  AlertTriangle, 
  Droplet, 
  CreditCard, 
  Calendar, 
  Phone, 
  ShieldAlert, 
  ClipboardList, 
  Stethoscope, 
  FileText, 
  Clock, 
  Printer, 
  Paperclip,
  CheckCircle2
} from 'lucide-react';
import { Patient } from '../types/medical';
import { calculateAge } from '../utils/medicalCalculators';

interface PatientHeaderProps {
  patient: Patient;
  activeTab: 'filiation' | 'first-consultation' | 'subsequent' | 'timeline' | 'documents' | 'attachments';
  onTabChange: (tab: 'filiation' | 'first-consultation' | 'subsequent' | 'timeline' | 'documents' | 'attachments') => void;
}

export const PatientHeader: React.FC<PatientHeaderProps> = ({
  patient,
  activeTab,
  onTabChange
}) => {
  const age = calculateAge(patient.filiation.birthDate);
  const allergies = patient.filiation.allergies || [];
  const hasSevereAllergy = allergies.some(a => a.severity.includes('Severa') || a.severity.includes('Anafilaxia'));

  return (
    <div className="bg-white border-b border-slate-200 shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 pb-2">
        
        {/* Main Patient Info Bar */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          
          {/* Identity & Badges */}
          <div className="flex items-start space-x-3.5">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-lg shadow-xs ${
              patient.filiation.gender === 'Femenino' 
                ? 'bg-rose-50 text-rose-600 border border-rose-200' 
                : 'bg-teal-50 text-teal-700 border border-teal-200'
            }`}>
              <User className="w-6 h-6" />
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                  {patient.filiation.fullName}
                </h1>
                
                {/* Record Number */}
                <span className="font-mono text-xs px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-semibold border border-slate-200">
                  {patient.recordNumber}
                </span>

                {/* Status */}
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                  patient.status === 'En consulta' 
                    ? 'bg-emerald-100 text-emerald-800 animate-pulse'
                    : patient.status === 'En espera'
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-slate-100 text-slate-700'
                }`}>
                  {patient.status}
                </span>
              </div>

              {/* Demographic metadata */}
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1 text-xs sm:text-sm text-slate-600">
                <span className="font-semibold text-slate-800">
                  {age.text}
                </span>
                <span className="text-slate-300">|</span>
                <span>
                  {patient.filiation.gender} · {patient.filiation.civilStatus}
                </span>
                <span className="text-slate-300">|</span>
                <span>
                  <strong className="text-slate-700">{patient.filiation.documentType}:</strong> {patient.filiation.documentNumber}
                </span>
                <span className="text-slate-300">|</span>
                <span className="flex items-center text-rose-700 font-semibold bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  <Droplet className="w-3.5 h-3.5 mr-1 text-rose-600 fill-rose-600" />
                  Grupo {patient.filiation.bloodType}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Contact & Insurance Badge */}
          <div className="flex flex-wrap items-center gap-2 lg:gap-3 text-xs">
            <div className="flex items-center space-x-1 px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-700">
              <CreditCard className="w-3.5 h-3.5 text-slate-400" />
              <span className="font-medium">{patient.filiation.insuranceName || 'Particular'}</span>
              {patient.filiation.policyNumber && (
                <span className="text-slate-400 font-mono">({patient.filiation.policyNumber})</span>
              )}
            </div>

            <div className="flex items-center space-x-1 px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-700">
              <Phone className="w-3.5 h-3.5 text-slate-400" />
              <span>{patient.filiation.mobile || patient.filiation.phone}</span>
            </div>
          </div>
        </div>

        {/* CRITICAL ALLERGY ALERT BANNER */}
        <div className="mt-3">
          {allergies.length > 0 ? (
            <div className={`flex items-start sm:items-center justify-between p-2.5 rounded-xl border text-xs sm:text-sm ${
              hasSevereAllergy
                ? 'bg-rose-50 border-rose-300 text-rose-900 shadow-2xs'
                : 'bg-amber-50 border-amber-300 text-amber-900'
            }`}>
              <div className="flex items-center space-x-2">
                <ShieldAlert className={`w-5 h-5 shrink-0 ${hasSevereAllergy ? 'text-rose-600 animate-bounce' : 'text-amber-600'}`} />
                <div>
                  <span className="font-bold uppercase tracking-wider text-[11px] mr-1.5 px-1.5 py-0.5 rounded bg-white border border-rose-200 text-rose-700">
                    ¡ALERTA DE ALERGIAS!
                  </span>
                  <span className="font-semibold">
                    {allergies.map(a => `${a.allergen} (${a.severity})`).join(' · ')}
                  </span>
                </div>
              </div>
              <span className="hidden md:inline-block text-[11px] text-slate-500 bg-white/70 px-2 py-0.5 rounded">
                Revisar antes de prescribir
              </span>
            </div>
          ) : (
            <div className="flex items-center space-x-1.5 px-3 py-1 text-xs text-emerald-800 bg-emerald-50 rounded-lg border border-emerald-200 w-fit">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Sin alergias medicamentosas o alimentarias reportadas</span>
            </div>
          )}
        </div>

        {/* Clinical Navigation Tabs */}
        <div className="flex overflow-x-auto space-x-1 sm:space-x-2 mt-4 pt-1 border-t border-slate-100 no-scrollbar">
          
          <button
            onClick={() => onTabChange('filiation')}
            className={`flex items-center space-x-1.5 px-3.5 py-2.5 text-xs sm:text-sm font-semibold rounded-t-lg border-b-2 transition whitespace-nowrap ${
              activeTab === 'filiation'
                ? 'border-teal-600 text-teal-800 bg-teal-50/60'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <ClipboardList className="w-4 h-4 text-teal-600" />
            <span>1. Datos de Filiación</span>
          </button>

          <button
            onClick={() => onTabChange('first-consultation')}
            className={`flex items-center space-x-1.5 px-3.5 py-2.5 text-xs sm:text-sm font-semibold rounded-t-lg border-b-2 transition whitespace-nowrap ${
              activeTab === 'first-consultation'
                ? 'border-teal-600 text-teal-800 bg-teal-50/60'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Stethoscope className="w-4 h-4 text-blue-600" />
            <span>2. Primera Consulta</span>
            {patient.firstConsultation && (
              <span className="w-2 h-2 rounded-full bg-emerald-500" title="Completada" />
            )}
          </button>

          <button
            onClick={() => onTabChange('subsequent')}
            className={`flex items-center space-x-1.5 px-3.5 py-2.5 text-xs sm:text-sm font-semibold rounded-t-lg border-b-2 transition whitespace-nowrap ${
              activeTab === 'subsequent'
                ? 'border-teal-600 text-teal-800 bg-teal-50/60'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <FileText className="w-4 h-4 text-purple-600" />
            <span>3. Nueva Evolución (SOAP / Libre)</span>
            {patient.subsequentConsultations.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-700 text-[10px] font-bold">
                {patient.subsequentConsultations.length}
              </span>
            )}
          </button>

          <button
            onClick={() => onTabChange('timeline')}
            className={`flex items-center space-x-1.5 px-3.5 py-2.5 text-xs sm:text-sm font-semibold rounded-t-lg border-b-2 transition whitespace-nowrap ${
              activeTab === 'timeline'
                ? 'border-teal-600 text-teal-800 bg-teal-50/60'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Clock className="w-4 h-4 text-amber-600" />
            <span>Línea de Tiempo</span>
          </button>

          <button
            onClick={() => onTabChange('documents')}
            className={`flex items-center space-x-1.5 px-3.5 py-2.5 text-xs sm:text-sm font-semibold rounded-t-lg border-b-2 transition whitespace-nowrap ${
              activeTab === 'documents'
                ? 'border-teal-600 text-teal-800 bg-teal-50/60'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Printer className="w-4 h-4 text-emerald-600" />
            <span>Recetas & Resúmenes</span>
          </button>

          <button
            onClick={() => onTabChange('attachments')}
            className={`flex items-center space-x-1.5 px-3.5 py-2.5 text-xs sm:text-sm font-semibold rounded-t-lg border-b-2 transition whitespace-nowrap ${
              activeTab === 'attachments'
                ? 'border-teal-600 text-teal-800 bg-teal-50/60'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Paperclip className="w-4 h-4 text-slate-600" />
            <span>Adjuntos & Laboratorio</span>
            {patient.attachments.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-700 text-[10px] font-bold">
                {patient.attachments.length}
              </span>
            )}
          </button>

        </div>

      </div>
    </div>
  );
};
