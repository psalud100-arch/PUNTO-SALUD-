import React, { useState, useEffect } from 'react';
import { Search, X, User, Phone, CreditCard, ShieldAlert, ChevronRight, Activity } from 'lucide-react';
import { Patient } from '../types/medical';
import { calculateAge } from '../utils/medicalCalculators';

interface PatientSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  patients: Patient[];
  onSelectPatient: (patientId: string) => void;
}

export const PatientSearchModal: React.FC<PatientSearchModalProps> = ({
  isOpen,
  onClose,
  patients,
  onSelectPatient
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filtered = patients.filter(p => {
    const q = searchTerm.toLowerCase().trim();
    if (!q) return true;
    return (
      p.filiation.fullName.toLowerCase().includes(q) ||
      p.filiation.documentNumber.toLowerCase().includes(q) ||
      p.recordNumber.toLowerCase().includes(q) ||
      p.filiation.phone.toLowerCase().includes(q) ||
      p.filiation.mobile.toLowerCase().includes(q) ||
      p.filiation.insuranceName.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-start justify-center pt-16 sm:pt-24 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-100 flex items-center space-x-3 bg-slate-50/50">
          <Search className="w-5 h-5 text-teal-600 shrink-0" />
          <input
            type="text"
            autoFocus
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Buscar por Nombre, DNI/Cédula, Teléfono o N° de Historia..."
            className="w-full text-sm sm:text-base font-medium bg-transparent border-none focus:outline-none placeholder-slate-400"
          />
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto divide-y divide-slate-100 p-2">
          {filtered.length > 0 ? (
            filtered.map(patient => {
              const age = calculateAge(patient.filiation.birthDate);
              const allergies = patient.filiation.allergies;

              return (
                <button
                  key={patient.id}
                  onClick={() => {
                    onSelectPatient(patient.id);
                    onClose();
                  }}
                  className="w-full text-left p-3.5 rounded-xl hover:bg-teal-50/60 transition flex items-center justify-between group cursor-pointer"
                >
                  <div className="flex items-start space-x-3">
                    <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-800 font-bold flex items-center justify-center text-xs shrink-0 group-hover:bg-teal-600 group-hover:text-white transition">
                      {patient.filiation.bloodType}
                    </div>

                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-sm text-slate-900 group-hover:text-teal-900">
                          {patient.filiation.fullName}
                        </span>
                        <span className="font-mono text-xs px-1.5 py-0.2 rounded bg-slate-100 text-slate-700">
                          {patient.recordNumber}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500 mt-1">
                        <span>{age.text}</span>
                        <span>•</span>
                        <span>{patient.filiation.documentType}: {patient.filiation.documentNumber}</span>
                        <span>•</span>
                        <span>{patient.filiation.mobile || patient.filiation.phone}</span>
                      </div>

                      {allergies.length > 0 && (
                        <div className="mt-1 flex items-center space-x-1 text-[11px] font-semibold text-rose-700">
                          <ShieldAlert className="w-3 h-3 text-rose-600" />
                          <span>Alergias: {allergies.map(a => a.allergen).join(', ')}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-teal-600 transition shrink-0" />
                </button>
              );
            })
          ) : (
            <div className="p-8 text-center text-slate-500">
              <Search className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-semibold">No se encontraron pacientes</p>
              <p className="text-xs text-slate-400 mt-0.5">Pruebe buscando por otro término de identificación</p>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 px-4">
          <span>{filtered.length} paciente(s) encontrado(s)</span>
          <span className="font-mono">Presione ESC para cerrar</span>
        </div>

      </div>
    </div>
  );
};
